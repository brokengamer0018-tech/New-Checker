from __future__ import annotations
import os
import json

# ══════════════════════════════════════════════════════════════════════════════
#  ▸ TELEGRAM API CREDENTIALS
# ══════════════════════════════════════════════════════════════════════════════
API_ID    = int(os.environ.get('33204200',    ''))
API_HASH  =     os.environ.get('b04f5697317e142a2af1b95bb1f1057d',  '')
BOT_TOKEN =     os.environ.get('8809074654:AAGX9NZTdG7DJIEGi27EmOukE-HnKkUCBt0', '')
TG_API    = f"https://api.telegram.org/bot{BOT_TOKEN}"

# ══════════════════════════════════════════════════════════════════════════════
#  ▸ BOT BRANDING
# ══════════════════════════════════════════════════════════════════════════════
BOT_BRAND      = '𝗛𝗬𝗣𝗘𝗥 𝗫 𝗖𝗛𝗞'
BOT_NAME       = '𝗛𝗬𝗣𝗘𝗥 𝗫 𝗖𝗛𝗞'
OWNER_NAME     = '𝗕𝗥𝗢𝗞𝗘𝗡'
OWNER_USERNAME = 'TgknownBroken'
OWNER_ID       = 8703047687
DEV_LINE       = f'🤖 𝐁𝐨𝐭 𝐃𝐞𝐯 ➜ @Hypercheckingbot'

# ══════════════════════════════════════════════════════════════════════════════
#  ▸ MASS CHECK — STABLE TUNING
# ══════════════════════════════════════════════════════════════════════════════
# WORKERS: 8 = stable, 12 = balanced, 20 = aggressive (more errors)
MASS_WORKERS = int(os.environ.get("MASS_WORKERS", "100"))   # was probably 100
# Timeout per card (seconds) — full checkout can take 60-120s
CARD_TIMEOUT = int(os.environ.get('CARD_TIMEOUT', '30'))

# Max retries per card on network error
MAX_RETRIES = int(os.environ.get('MAX_RETRIES', '20'))

# Rate limit window (seconds) — time between two checks on same card
CHECK_COOLDOWN = 0


# ══════════════════════════════════════════════════════════════════════════════
# Delay between requests (seconds) — higher = safer, lower = faster
REQUEST_DELAY_MIN = 0.0
REQUEST_DELAY_MAX = 0.0

# Same site gap (seconds) — prevent hitting same site too fast
SITE_PROXY_GAP_S = 0.0

# ══════════════════════════════════════════════════════════════════════════════
#  ▸ LOG CHANNEL
# ══════════════════════════════════════════════════════════════════════════════
LOG_CHANNEL_ID = -1004435848592
# ══════════════════════════════════════════════════════════════════════════════
#  ▸ ADMIN MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════
_ADMIN_FILE     = os.path.join(os.path.dirname(__file__), 'admin.json')
_DEFAULT_ADMINS = (
    {int(x.strip()) for x in os.environ.get('ADMIN_ID', '').split(',') if x.strip().isdigit()}
    | ({OWNER_ID} if OWNER_ID else set())
)


def _load_admin_ids() -> set:
    try:
        with open(_ADMIN_FILE) as f:
            data = json.load(f)
            ids  = data.get('admin_ids', [])
            return set(ids) | _DEFAULT_ADMINS if ids else _DEFAULT_ADMINS
    except Exception:
        return _DEFAULT_ADMINS


def _save_admin_ids(ids: set):
    try:
        with open(_ADMIN_FILE) as f:
            data = json.load(f)
    except Exception:
        data = {}
    data['admin_ids'] = list(ids)
    with open(_ADMIN_FILE, 'w') as f:
        json.dump(data, f)


ADMIN_IDS = _load_admin_ids()
ADMIN_ID  = OWNER_ID

# ══════════════════════════════════════════════════════════════════════════════
#  ▸ FILES
# ══════════════════════════════════════════════════════════════════════════════
PREMIUM_FILE    = 'premium.txt'
SITES_FILE      = 'sites.txt'
PROXY_FILE      = 'proxy.txt'
USER_PROXY_FILE = 'user_proxies.json'
USER_POOL_FILE  = 'user_pool.json'
BANNED_FILE     = 'banned.txt'
KEYS_FILE       = 'keys.txt'
LIMITS_FILE     = 'limits.json'
VIDEOS_FILE     = 'videos.txt'
GIFS_FILE       = 'gifs.txt'
WELCOME_FILE    = 'welcome.txt'
LOG_FILE        = 'log_group.txt'

# ══════════════════════════════════════════════════════════════════════════════
#  ▸ LIMITS
# ══════════════════════════════════════════════════════════════════════════════
LIMITS = {
    "admin":   999999999999,
    "premium": 10000,
}


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ PER-USER DIVISION (simple, no queue)
# ══════════════════════════════════════════════════════════════════════════════
PROXIES_PER_USER   = int(os.environ.get('PROXIES_PER_USER',   '15'))    # random from pool
SITES_PER_USER     = int(os.environ.get('SITES_PER_USER',     '0'))     # 0 = all sites


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ MULTI-USER SAFETY
# ══════════════════════════════════════════════════════════════════════════════
MAX_USERS_CONCURRENT = int(os.environ.get('MAX_USERS_CONCURRENT', '3'))


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ GLOBAL LOAD BALANCING (multi-user safety)
# ══════════════════════════════════════════════════════════════════════════════
GLOBAL_MAX_WORKERS    = int(os.environ.get('GLOBAL_MAX_WORKERS',    '250'))
MAX_CONCURRENT_CHECKS = int(os.environ.get('MAX_CONCURRENT_CHECKS', '3'))
LIGHT_LOAD_WORKERS    = int(os.environ.get('LIGHT_LOAD_WORKERS',    '100'))
MEDIUM_LOAD_WORKERS   = int(os.environ.get('MEDIUM_LOAD_WORKERS',   '70'))
HEAVY_LOAD_WORKERS    = int(os.environ.get('HEAVY_LOAD_WORKERS',    '50'))


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ POOL SETTINGS
# ══════════════════════════════════════════════════════════════════════════════
POOL_ENABLED_FILE = 'pool_enabled.txt'   # "1" = ON, "0" = OFF
AUTO_CHECK_INTERVAL = 7200                # 2 hours in seconds

# Force-join channels (2 required)
FORCE_JOIN_CHANNELS = [
    {"id": -1004415311631, "name": "Updates", "url": "https://t.me/+5rHff81b22M3Yjg1"},
    {"id": -1004395765824, "name": "Main",    "url": "https://t.me/+IMnfMgXUylIyZThl"},
]

# Feedback channel (approved feedback posts here)
FEEDBACK_CHANNEL_ID = -1004415311631

# Feedback approvers (empty = use ADMIN_IDS)
FEEDBACK_ADMIN_IDS = []
